(function (root) {
  const norm = (s) => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();

  // Venda casada do balcão: quem leva a peça da esquerda quase sempre precisa da direita.
  const JUNTO = [
    { se: /\b(kit )?relacao\b|\bcorrente\b|\bcoroa\b|\bpinhao\b/, busca: 'lubrificante corrente', label: 'Lubrificante de corrente' },
    { se: /\bpastilha\b|\blona\b|\bsapata\b/, busca: 'fluido freio', label: 'Fluido de freio' },
    { se: /\bfiltro (de )?oleo\b/, busca: 'oleo 10w30', label: 'Óleo do motor' },
    { se: /\boleo\b(?!.*\bfiltro\b)/, busca: 'filtro oleo', label: 'Filtro de óleo' },
    { se: /\boleo\b/, busca: 'anel bujao', label: 'Anel do bujão' },
    { se: /\bpneu\b/, busca: 'camara ar', label: 'Câmara de ar' },
    { se: /\bvela\b/, busca: 'filtro ar', label: 'Filtro de ar' },
    { se: /\bcabo (de )?embreagem\b/, busca: 'manete embreagem', label: 'Manete de embreagem' },
  ];

  // Tipo de peça para contar pares: "KIT RELACAO TIT 160 44Z" → "kit relacao"; "PASTILHA FREIO DIANT" → "pastilha".
  // Radicais que o catálogo trunca (AMORTEC, EMBREAG) viram a mesma chave.
  const COMPOSTO = new Set(['kit', 'jogo', 'jg', 'cj', 'conjunto', 'cabo', 'filtro', 'anel', 'bucha', 'capa', 'par', 'rolamento', 'oleo', 'lampada',
    'manete', 'pedal', 'eixo', 'tampa', 'borracha', 'protetor', 'suporte', 'junta', 'mangueira', 'disco', 'tubo', 'chave', 'bomba', 'fluido']);
  const LIGA = new Set(['de', 'da', 'do', 'das', 'dos', 'p', 'c', 'para', 'pra', 'com']);
  function tipoPeca(desc) {
    const ws = norm(desc).split(/[^a-z0-9]+/).filter((w) => /^[a-z]{2,}$/.test(w) && !LIGA.has(w));
    if (!ws.length || ws[0].length < 3) return '';
    const corta = (w) => RADICAIS.find((r) => w.startsWith(r)) || w;
    return COMPOSTO.has(ws[0]) && ws[1] && ws[1].length >= 3 ? `${corta(ws[0])} ${corta(ws[1])}` : corta(ws[0]);
  }

  // Pares que saem juntos nos pedidos concluídos. `pedidos` é lista de listas de tipos.
  // Só vale o par visto em `minSup` pedidos, em pelo menos `minConf` dos pedidos com A, e bem acima do comum (lift).
  function aprenderJunto(pedidos, { minSup = 3, minConf = 0.15, minLift = 1.5 } = {}) {
    const n = pedidos.length;
    const cont = new Map();
    const par = new Map();
    pedidos.forEach((lista) => {
      const tipos = [...new Set(lista.filter(Boolean))];
      tipos.forEach((a) => {
        cont.set(a, (cont.get(a) || 0) + 1);
        tipos.forEach((b) => { if (a !== b) { const k = `${a}|${b}`; par.set(k, (par.get(k) || 0) + 1); } });
      });
    });
    const out = {};
    par.forEach((sup, k) => {
      if (sup < minSup) return;
      const [a, b] = k.split('|');
      const conf = sup / cont.get(a);
      const lift = conf / (cont.get(b) / n);
      if (conf < minConf || lift < minLift) return;
      (out[a] = out[a] || []).push({ b, sup, conf: Math.round(conf * 100) / 100 });
    });
    Object.values(out).forEach((l) => l.sort((x, y) => y.conf - x.conf || y.sup - x.sup));
    return out;
  }

  const rotulo = (tipo) => tipo.charAt(0).toUpperCase() + tipo.slice(1);

  function leveJunto(items, aprendido = null) {
    const descs = (items || []).map((i) => norm(i.desc)).filter(Boolean);
    if (!descs.length) return [];
    const has = (term) => { const words = norm(term).split(/\s+/); return descs.some((d) => words.every((w) => d.includes(w))); };
    const out = [];
    if (aprendido) {
      const noCarrinho = new Set(descs.map(tipoPeca));
      const cands = [];
      descs.forEach((d) => (aprendido[tipoPeca(d)] || []).forEach((x) => {
        if (!noCarrinho.has(x.b) && !has(x.b)) cands.push({ busca: x.b, label: rotulo(x.b), de: d, conf: x.conf, sup: x.sup });
      }));
      cands.sort((x, y) => y.conf - x.conf || y.sup - x.sup)
        .forEach((x) => { if (!out.some((o) => o.busca === x.busca)) out.push(x); });
    }
    JUNTO.forEach((r) => {
      if (descs.some((d) => r.se.test(d)) && !has(r.busca) && !out.some((o) => norm(r.busca).startsWith(o.busca))) out.push({ busca: r.busca, label: r.label });
    });
    return out.slice(0, 3);
  }

  const STOP = new Set(['para', 'pra', 'com', 'sem', 'das', 'dos', 'de', 'da', 'do', 'e', 'a', 'o', 'kit', 'jogo', 'peca']);

  // "Coroa CG 160" casa com "COROA 43D CG 160 TITAN": todas as palavras relevantes do pedido aparecem na descrição.
  function casaPeca(peca, descricao) {
    const d = norm(descricao);
    const words = norm(peca).split(/[^a-z0-9]+/).filter((w) => w.length >= 2 && !STOP.has(w));
    return words.length > 0 && words.every((w) => new RegExp(`(^|[^a-z0-9])${w}`).test(d));
  }

  const noEstoque = (peca, produtos) => (produtos || []).find((x) => Number(x.estoque) > 0 && casaPeca(peca, x.descricao)) || null;

  function vendasMes(lista, now = Date.now()) {
    const d = new Date(now);
    const key = (y, m) => `${String(m + 1).padStart(2, '0')}/${y}`;
    const prev = new Date(d.getFullYear(), d.getMonth() - 1, 1);
    const val = (k) => ((lista || []).find((x) => x.mes === k) || {}).valor || 0;
    const atual = val(key(d.getFullYear(), d.getMonth()));
    const anterior = val(key(prev.getFullYear(), prev.getMonth()));
    return { atual, anterior, variacao: anterior ? Math.round(((atual - anterior) / anterior) * 100) : null };
  }

  // Palavras de conversa que não descrevem a peça: "boa tarde, tem coroa da titan 160?" vira "coroa titan 160".
  const FALA = new Set(['oi', 'ola', 'bom', 'boa', 'dia', 'tarde', 'noite', 'tudo', 'bem', 'amigo', 'amiga', 'irmao', 'mano', 'chefe', 'patrao', 'tem', 'teria', 'tens',
    'voce', 'vc', 'vcs', 'voces', 'ai', 'aqui', 'quanto', 'quanta', 'custa', 'fica', 'sai', 'preco', 'valor', 'qual', 'quais', 'me', 'manda', 'mande', 'passa', 'passar',
    'queria', 'quero', 'preciso', 'precisava', 'gostaria', 'saber', 'se', 'por', 'favor', 'pf', 'pfv', 'obrigado', 'obg', 'um', 'uma', 'uns', 'umas', 'no', 'na', 'nos', 'nas',
    'estoque', 'ainda', 'ja', 'pra', 'para', 'de', 'da', 'do', 'das', 'dos', 'e', 'a', 'o', 'as', 'os', 'com', 'que', 'moto', 'minha', 'meu', 'orcamento', 'disponivel', 'certo']);

  function termoBusca(texto) {
    const words = norm(texto).replace(/[^a-z0-9/.-]+/g, ' ').split(' ').map((w) => w.replace(/^[.-]+|[.-]+$/g, '')).filter((w) => w && !FALA.has(w));
    return words.slice(0, 5).join(' ');
  }

  // A busca da API exige todas as palavras; tirando do fim, "coroa titan 160 2019" ainda acha "coroa titan 160".
  function afrouxar(termo) {
    const w = String(termo || '').trim().split(/\s+/);
    const out = [];
    // O catálogo trunca ("LIBERT", "AMORTEC") e a API só casa prefixo: encurta as palavras longas antes de largar alguma.
    const curto = w.filter((x) => !/^\d$/.test(x)).map((x) => (/^[a-z]{7,}$/.test(x) ? x.slice(0, 5) : x)).join(' ');
    if (w.length > 1 && curto !== w.join(' ')) out.push(curto);
    for (let n = w.length - 1, k = 0; n >= 1 && k < 2; n--, k++) out.push(w.slice(0, n).join(' '));
    return out.filter((t) => t.length >= 3);
  }

  // Pedido e fechamento, não peça: "se tiver coloca 1 e pode finalizar" não vira item.
  const PEDIDO = new Set(['coloca', 'colocar', 'coloque', 'pode', 'finalizar', 'finaliza', 'fechar', 'fecha', 'tiver', 'separa', 'separar', 'envia', 'enviar',
    'pix', 'obrigada', 'blz', 'beleza', 'ok', 'sim', 'nao', 'isso', 'dela', 'dele', 'desse', 'dessa', 'deste', 'desta', 'disso', 'mesmo', 'mesma', 'tbm', 'tambem',
    'retira', 'retirar', 'entrega', 'entregar', 'frete', 'encaminhada', 'mais', 'outro', 'outra', 'tb', 'pode', 'mandar', 'confirma', 'confirmar', 'aguardo', 'vou', 'vai']);
  const REF = new Set(['dela', 'dele', 'desse', 'dessa', 'deste', 'desta', 'nela', 'nele', 'mesma', 'mesmo']);
  const UNIDADE = { par: 'par', pares: 'par', pc: 'pc', pcs: 'pc', pç: 'pc', pçs: 'pc', peca: 'pc', pecas: 'pc', un: 'un', und: 'un', unid: 'un', unidade: 'un', unidades: 'un', jg: 'jg', cx: 'cx', caixa: 'cx', caixas: 'cx' };

  // Começo do nome das peças que o balcão vende: separa "capa azul da bros" de "recebi msg dizendo…".
  const PECAS = ['oleo', 'filtro', 'pastilha', 'lona', 'kit', 'relacao', 'tracao', 'corrente', 'coroa', 'pinhao', 'pneu', 'camara', 'retrovisor', 'espelho',
    'guidao', 'guidon', 'guidom', 'manete', 'maneta', 'cabo', 'lampada', 'farol', 'lanterna', 'pisca', 'viseira', 'botao', 'capa', 'banco', 'amortec', 'bengala',
    'retentor', 'rolamento', 'bucha', 'junta', 'vela', 'bobina', 'carbur', 'embreag', 'disco', 'plato', 'manopla', 'pedal', 'pedaleira', 'escapamento', 'silencioso',
    'bateria', 'rele', 'regulador', 'estator', 'chicote', 'chave', 'ignicao', 'tanque', 'tampa', 'paralama', 'carenagem', 'protetor', 'suporte', 'parafuso', 'porca',
    'raio', 'aro', 'cubo', 'eixo', 'balanca', 'coxim', 'bomba', 'valvula', 'pistao', 'anel', 'cilindro', 'biela', 'virabrequim', 'comando', 'tensor', 'sapata',
    'capacete', 'antena', 'trava', 'cadeado', 'graxa', 'fluido', 'velocimetro', 'painel', 'sensor', 'interruptor', 'buzina', 'bagageiro', 'rabeta', 'spray', 'camera',
    'cavalete', 'descanso', 'mola', 'engrenagem', 'acelerador', 'afogador', 'mangueira', 'torneira', 'paralam', 'setas', 'seta', 'lente', 'bloco', 'motor', 'roda', 'freio'];
  // Prefixo só nos radicais que o catálogo trunca; nos outros, "juntar" não é "junta".
  const RADICAIS = ['amortec', 'embreag', 'carbur', 'paralam'];
  const ehPeca = (w) => RADICAIS.some((r) => w.startsWith(r)) || PECAS.some((p) => w === p || w === `${p}s` || w === `${p}es`);

  // "[21:23, 25/09/2026] Fada Dani: " → milissegundos (hora local).
  function horaMsg(pre) {
    const m = String(pre || '').match(/(\d{1,2}):(\d{2}),\s*(\d{1,2})\/(\d{1,2})\/(\d{4})/);
    return m ? new Date(+m[5], +m[4] - 1, +m[3], +m[1], +m[2]).getTime() : null;
  }

  // Mensagens seguidas do cliente viram um bloco: mensagem do vendedor ou pausa longa fecham o bloco.
  // Foto sem legenda do cliente (hora null) não quebra. Devolve os índices das mensagens com texto.
  function blocos(seq, pausaMin = 30) {
    const out = [];
    let cur = []; let ult = null;
    const fecha = () => { if (cur.length) out.push(cur); cur = []; ult = null; };
    seq.forEach((m, i) => {
      if (m.meu) { fecha(); return; }
      if (!m.texto) return;
      if (ult != null && m.hora != null && m.hora - ult > pausaMin * 60000) fecha();
      cur.push(i);
      if (m.hora != null) ult = m.hora;
    });
    fecha();
    return out;
  }

  // "pode finalizar", "fecha o pedido", "manda o pix": o cliente quer fechar. "pode fazer por 50?" e "pode mandar a foto" não contam.
  const FECHAR = [
    /\bpode(?:m)? (?:ja )?(?:finalizar|fechar|faturar|separar|mandar separar)\b/,
    /\b(?:fecha|fechar|finaliza|finalizar|faz|fazer|tira|tirar|lanca|lancar|passa|passar|monta|montar) (?:o |meu |nosso )?pedido\b/,
    /\b(?:manda|mande|me manda|passa|envia|qual)(?: o| a| ai| a sua| sua)? (?:chave )?pix\b/,
    /\bvou (?:querer|levar|ficar com) (?:tudo|todos|todas|esse|essa|esses|essas|os dois|as duas)\b/,
    /^(?:fechado|fechou|pode mandar|manda ai|pode enviar|pode separar)$/,
  ];
  function querFechar(texto) {
    const t = norm(texto).replace(/[!?.,;:]+/g, ' ').replace(/\s+/g, ' ').trim();
    return FECHAR.some((re) => {
      const m = t.match(re);
      return m && !/\b(?:nao|n|nem)\s+(?:\w+\s+)?$/.test(t.slice(0, m.index));
    });
  }

  // "5 par botao new liberty 3" → 5 par de "botao new liberty 3"; linhas de conversa ficam de fora.
  function parseLista(texto) {
    const out = [];
    String(texto || '').split(/\n|;|,(?=\s*\d)/).forEach((bruta) => {
      const l = norm(bruta).replace(/\b\d{1,2}:\d{2}\b/g, ' ').replace(/[?!]+/g, ' ').replace(/\s+/g, ' ').trim();
      const ws = l.split(/[^a-z0-9/.-]+/).filter(Boolean);
      while (ws.length && (FALA.has(ws[0]) || PEDIDO.has(ws[0]))) ws.shift();
      let qtd = null; let unidade = '';
      const q0 = ws.length > 1 && ws[0].match(/^(\d{1,4})x?$/);
      if (q0) {
        qtd = Number(q0[1]); ws.shift();
        if (ws[0] === 'x') ws.shift();
        if (UNIDADE[ws[0]] && ws.length > 1) { unidade = UNIDADE[ws.shift()]; if (/^d[eoa]$/.test(ws[0])) ws.shift(); }
      } else if (ws.length > 2) {
        const [a2, a1] = ws.slice(-2);
        let m;
        if (UNIDADE[a1] && /^\d{1,4}$/.test(a2)) { qtd = Number(a2); unidade = UNIDADE[a1]; ws.splice(-2); }
        else if ((m = a1.match(/^x(\d{1,4})$/))) { qtd = Number(m[1]); ws.pop(); }
        else if (/^\d{1,4}$/.test(a1) && (a2 === 'x' || a2 === '-')) { qtd = Number(a1); ws.splice(-2); }
      }
      // "e retrovisor dela?": a peça é da moto de que se falou antes; o painel completa.
      const ref = ws.find((w) => REF.has(w)) || '';
      const palavras = ws.map((w) => w.replace(/^[.-]+|[.-]+$/g, '')).filter((w) => w && !FALA.has(w) && !PEDIDO.has(w));
      if (!palavras.some((w) => /[a-z]{3,}/.test(w))) return;
      out.push({ linha: bruta.trim(), qtd: qtd || 1, unidade, termo: palavras.slice(0, 6).join(' '), ref, qtdDita: qtd != null, certo: qtd != null || (ws.length <= 10 && palavras.some(ehPeca)) });
    });
    return out;
  }

  const api = { norm, leveJunto, tipoPeca, aprenderJunto, casaPeca, noEstoque, vendasMes, termoBusca, afrouxar, parseLista, horaMsg, blocos, querFechar };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else (root.MZ = root.MZ || {}).dicas = api;
})(globalThis);

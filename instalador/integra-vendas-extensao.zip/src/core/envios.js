(function (root) {
  const KINDS = {
    preco: 'Preço', orcamento: 'Orçamento', pedido: 'Pedido', followup: 'Follow-up',
    resposta: 'Resposta pronta', manutencao: 'Manutenção', aviso: 'Aviso de peça', outro: 'Mensagem',
  };
  const MAX = 100;
  const PENDING_MS = 2 * 3600e3;

  // O WhatsApp renderiza *negrito*/_itálico_ sem os marcadores e pode trocar quebras de linha.
  const normMsg = (s) => String(s || '').replace(/[*_~`]/g, '').replace(/\s+/g, ' ').trim().toLowerCase();

  function countMatches(bubbles, text) {
    const want = normMsg(text).slice(0, 80);
    if (!want) return 0;
    return (bubbles || []).filter((b) => normMsg(b).startsWith(want)).length;
  }

  function logInsert(c, { kind, label, text, baseline, now = Date.now() }) {
    c.enviados = c.enviados || [];
    const e = { id: `${now.toString(36)}${Math.random().toString(36).slice(2, 6)}`, at: now, kind: KINDS[kind] ? kind : 'outro', label: label || '', text, status: 'inserido', baseline: baseline || 0 };
    c.enviados.push(e);
    if (c.enviados.length > MAX) c.enviados.splice(0, c.enviados.length - MAX);
    return e;
  }

  // Confirma só quando surge na conversa uma bolha nova com o mesmo texto (reenviar o mesmo preço não confunde).
  // Devolve null se nada mudou; senão a lista (talvez vazia) do que acabou de ser enviado.
  function confirmSent(c, bubbles, now = Date.now()) {
    let changed = false;
    const sent = [];
    (c.enviados || []).forEach((e) => {
      if (e.status !== 'inserido') return;
      if (now - e.at > PENDING_MS) { e.status = 'nao-enviado'; changed = true; return; }
      if (countMatches(bubbles, e.text) > e.baseline) { e.status = 'enviado'; e.sentAt = now; changed = true; sent.push(e); }
    });
    return changed ? sent : null;
  }

  // Quem pergunta preço e some costuma comprar se o vendedor volta no dia seguinte.
  function precoFollowup(c, e, now = Date.now()) {
    if (!e || e.kind !== 'preco') return null;
    if ((c.followups || []).some((f) => f.status === 'pendente' && (f.kind === 'preco' || f.kind === 'cadencia'))) return null;
    const peca = e.label ? (e.label.includes(' + ') ? 'das peças' : `da ${e.label.split(' ').slice(0, 4).join(' ').toLowerCase()}`) : '';
    return { id: `p${now.toString(36)}`, kind: 'preco', label: 'Retorno do preço', due: now + 864e5, status: 'pendente',
      text: `Oi {nome}! Conseguiu ver o preço ${peca}? Se quiser, já separo pra você.`.replace(' ?', '?') };
  }

  const hasPending = (c) => !!(c && (c.enviados || []).some((e) => e.status === 'inserido'));

  // Um WhatsApp pode comprar por várias razões sociais; guarda por quais já se vendeu, a mais usada primeiro.
  function noteCliente(c, cli, now = Date.now()) {
    if (!cli || !cli.clienteId) return;
    c.ivClientes = c.ivClientes || [];
    let r = c.ivClientes.find((x) => x.clienteId === cli.clienteId);
    if (!r) { r = { clienteId: cli.clienteId, pedidos: 0 }; c.ivClientes.push(r); }
    Object.assign(r, { nome: cli.nome, razao: cli.razao || r.razao || '', cnpj: cli.cnpj || '', cidade: cli.cidade || '', telefone: cli.telefone || '', lastAt: now });
    return r;
  }

  function razoes(c) {
    const list = (c.ivClientes || []).map((r) => ({ ...r }));
    // Pedidos antigos não guardavam o cliente: contam para o vínculo atual.
    const cur = c.iv && c.iv.clienteId;
    list.forEach((r) => {
      r.pedidos = (c.pedidos || []).filter((p) => !p.cancelado && (p.clienteId ? p.clienteId === r.clienteId : r.clienteId === cur)).length;
    });
    return list.sort((a, b) => b.pedidos - a.pedidos || (b.lastAt || 0) - (a.lastAt || 0));
  }

  const api = { KINDS, MAX, PENDING_MS, normMsg, countMatches, logInsert, confirmSent, precoFollowup, hasPending, noteCliente, razoes };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else (root.MZ = root.MZ || {}).envios = api;
})(globalThis);

(function (root) {
  const F = typeof module !== 'undefined' && module.exports ? require('./format.js') : root.MZ.format;
  const DEFAULT_URL = 'https://vendas.integra-vendas.com/';

  function baseUrl(u) {
    let s = String(u || '').trim();
    if (!s) return DEFAULT_URL;
    if (!/^https?:\/\//i.test(s)) s = `https://${s}`;
    return s.replace(/\/+$/, '') + '/';
  }

  function originPattern(u) {
    const url = new URL(baseUrl(u));
    return `${url.protocol}//${url.host}/*`;
  }

  // Só lê as claims para mostrar na tela; quem valida a assinatura é a API.
  function decodeJwt(token) {
    try {
      const part = String(token).split('.')[1].replace(/-/g, '+').replace(/_/g, '/');
      const json = decodeURIComponent(Array.from(atob(part), (c) => `%${c.charCodeAt(0).toString(16).padStart(2, '0')}`).join(''));
      return JSON.parse(json);
    } catch (_) {
      return null;
    }
  }

  function userFromClaims(c) {
    if (!c) return null;
    return {
      id: c.id, nome: c.nome, email: c.email, admin: !!c.administrador,
      empresa: c.empresa_nome || '',
      descontoMax: Number(c.desconto_maximo) || 0,
      acrescimoMax: Number(c.acrescimo_maximo) || 0,
      exp: Number(c.exp) || 0,
    };
  }

  const digits = (s) => String(s || '').replace(/\D/g, '');

  // O cadastro do ERP guarda o telefone formatado de vários jeitos; os 8 últimos dígitos são o que sobrevive a todos.
  function phoneTail(phone) {
    const d = digits(phone);
    return d.length >= 8 ? d.slice(-8) : '';
  }

  // Número antigo sem o 9, com DDI, com 0 de longa distância: tudo vira { ddd, num } com os 8 dígitos finais.
  function parsePhone(d) {
    if ((d.length === 12 || d.length === 13) && d.startsWith('55')) d = d.slice(2);
    else if ((d.length === 11 || d.length === 12) && d.startsWith('0')) d = d.slice(1);
    if (d.length < 8 || d.length > 11) return null;
    const ddd = d.length >= 10 ? d.slice(0, 2) : '';
    return { ddd, num: d.slice(-8), local: d.length - (ddd ? 2 : 0) };
  }

  // Um campo pode trazer mais de um número: "85 3333-4444 / 85 9 9000-0001".
  function phoneList(s) {
    const out = [];
    String(s || '').split(/[/,;|\n]|\s+(?:e|ou)\s+/i).forEach((part) => {
      const d = digits(part);
      if (d.length <= 13) { const p = parsePhone(d); if (p) out.push(p); return; }
      (part.match(/(?:\+?55[\s.-]*)?(?:\(?0?\d{2}\)?[\s.-]*)?(?:9[\s.-]*)?\d{4}[\s.-]?\d{4}/g) || [])
        .forEach((m) => { const p = parsePhone(digits(m)); if (p) out.push(p); });
    });
    return out;
  }

  // O 9 a mais (ou a menos) não muda o número; o DDD só conta quando os dois lados têm.
  function samePhone(a, b) {
    const lb = phoneList(b);
    return phoneList(a).some((x) => lb.some((y) => x.num === y.num && (!x.ddd || !y.ddd || x.ddd === y.ddd)));
  }

  // Celular (começa com 6–9) gravado com DDD mas só 8 dígitos: é o formato de antes do nono dígito.
  function sem9(cadastro, phone) {
    const lp = phoneList(phone);
    return phoneList(cadastro).some((x) => x.ddd && x.local === 8 && /^[6-9]/.test(x.num) && lp.some((y) => y.num === x.num && (!y.ddd || y.ddd === x.ddd)));
  }

  const com9 = (phone) => { const p = phoneList(phone)[0]; return p && p.ddd ? `(${p.ddd}) 9${p.num.slice(0, 4)}-${p.num.slice(4)}` : fmtPhone(phone); };

  // A busca da API é ILIKE com espaço virando %: "9000 0001" acha 9000-0001, 9000.0001, 99000 0001…
  function phoneQueries(phone) {
    const p = phoneList(phone)[0];
    if (!p) return [];
    return [`${p.num.slice(0, 4)} ${p.num.slice(4)}`, p.num.split('').join(' ')];
  }

  const looksPhone = (s) => /^[+\d\s().-]+$/.test(String(s || '').trim()) && digits(s).length >= 8 && digits(s).length <= 13 && !/^\d{3}\.\d{3}\.\d{3}-\d{2}$/.test(String(s).trim());

  function fmtPhone(phone) {
    let d = digits(phone);
    if (!d) return '';
    const ddi = d.length > 11 && d.startsWith('55') ? '+55 ' : '';
    if (ddi) d = d.slice(2);
    if (d.length < 10) return `${ddi}${d}`;
    const ddd = d.slice(0, 2);
    const num = d.slice(2);
    return `${ddi}(${ddd}) ${num.slice(0, num.length - 4)}-${num.slice(-4)}`;
  }

  // Não há rota na API para alterar cadastro: o pedido vai para o setor de cadastro, que atualiza no ERP.
  function cadastroMsg(cli, phone, vendedor, motivo) {
    return [
      '*Atualização de cadastro*',
      `Cliente: ${cli.nome}${cli.razao && cli.razao !== cli.nome ? ` (${cli.razao})` : ''}`,
      `Código no sistema: ${cli.clienteId}${cli.cnpj ? ` · CNPJ/CPF: ${cli.cnpj}` : ''}`,
      `Telefone no cadastro: ${cli.telefone ? fmtPhone(cli.telefone) || cli.telefone : '(vazio)'}`,
      motivo === 'sem9' ? `Corrigir para: ${com9(phone)} (celular sem o 9 no cadastro)` : `Incluir o WhatsApp: ${fmtPhone(phone)}`,
      vendedor ? `Pedido por: ${vendedor}` : '',
    ].filter(Boolean).join('\n');
  }

  function maisComprados(list, n = 8) {
    return (list || []).filter((p) => p && p.id && p.codigo).slice(0, n)
      .map((p) => ({ id: p.id, codigo: String(p.codigo).trim(), descricao: String(p.descricao || '').trim(), qtd: Number(p.qtd_comprado) || 0 }));
  }

  function clienteLabel(c) {
    return (c.nome_fantasia || c.razao_social || c.fantasia || '').trim() || `Cliente ${c.id || c.cliente_id}`;
  }

  function productToItem(p) {
    const mult = Number(p.multiplo) > 0 ? Number(p.multiplo) : 1;
    return {
      desc: p.descricao || '', codigo: p.codigo || '', marca: '', tipo: '',
      qtd: mult, preco: Number(p.preco_tabela) || 0,
      iv: { id: p.id, tabela: Number(p.preco_tabela) || 0, minimo: Number(p.preco_minimo) || 0, multiplo: mult, estoque: Number(p.estoque) || 0, unidade: p.unidade || '', imagem: p.imagem || '' },
      ult: ultimoPedido(p),
    };
  }

  // ultimo_pedido.valor é o preço de tabela da época; o que o cliente pagou só vem do pedido.
  function ultimoPedido(p) {
    const u = p && p.ultimo_pedido;
    if (!u || !u.numero || !u.id) return undefined;
    return { id: u.id, numero: u.numero, data: dataBr(u.data), qtd: Number(u.quantidade) || 0 };
  }

  function dataBr(s) {
    const m = String(s || '').match(/^(\d{4})-(\d{2})-(\d{2})/);
    return m ? `${m[3]}/${m[2]}/${m[1]}` : String(s || '').replace(/-/g, '/');
  }

  function pagoNoPedido(full, produtoId) {
    const it = ((full && full.itens) || []).find((x) => x.produto_id === produtoId);
    const q = it && Number(it.quantidade);
    if (!q) return null;
    return { qtd: q, unit: Math.round((Number(it.preco_liquido) / q) * 100) / 100, desconto: Number(it.desconto) || 0, acrescimo: Number(it.acrescimo) || 0, tabela: Number(it.valor_unitario) || 0 };
  }

  const round2 = (n) => Math.round(n * 100) / 100;
  const pctBr = (n) => `${String(n).replace('.', ',')}%`;

  const POLITICAS = [
    { tipo: 'prazo', label: 'A prazo', pct: 0 },
    { tipo: 'av5', label: 'À vista 5%', pct: 5 },
    { tipo: 'av3', label: 'À vista 3%', pct: 3 },
    { tipo: 'pers', label: 'Personalizado' },
  ];
  const polBase = (pol) => POLITICAS.find((x) => x.tipo === (pol && pol.tipo)) || POLITICAS[0];
  function polPct(pol) {
    const b = polBase(pol);
    return b.tipo === 'pers' ? Math.max(0, Math.min(100, Number(pol.pct) || 0)) : b.pct;
  }
  const polKey = (pol) => `${polBase(pol).tipo}:${polPct(pol)}`;
  function polLabel(pol) {
    const b = polBase(pol);
    return b.tipo === 'pers' ? `Personalizado ${pctBr(polPct(pol))}` : b.label;
  }

  const precoPol = (tabela, pct) => F.liquido(tabela, pct, 1);

  // O percentual é o que vai para a API; o preço unitário só o reflete. Preço digitado vira percentual de 2 casas.
  function fixaPct(it, pct) {
    it.pct = round2(Math.max(-100, Math.min(100, Number(pct) || 0)));
    it.preco = precoPol(it.iv.tabela, it.pct);
  }
  const pctDoPreco = (it, preco) => round2((1 - (Number(preco) || 0) / it.iv.tabela) * 100);

  // Item novo (sem `pol`) recebe a política; o que foi negociado à mão só é convertido para percentual.
  function aplicaPolitica(quote, pol, forcar = false) {
    const key = polKey(pol);
    const pct = polPct(pol);
    let n = 0;
    (quote.items || []).forEach((it) => {
      if (!it.iv || !(it.iv.tabela > 0)) return;
      if (!forcar && it.pol !== undefined) {
        if (typeof it.pct !== 'number') fixaPct(it, it.pol === key ? pct : pctDoPreco(it, it.preco));
        return;
      }
      if (!forcar && Number(it.preco) !== it.iv.tabela) { it.pol = 'manual'; fixaPct(it, pctDoPreco(it, it.preco)); return; }
      if (it.pct !== pct || it.pol !== key) n++;
      fixaPct(it, pct);
      it.pol = key;
    });
    return n;
  }

  // Quanto o cliente deixa de pagar em relação à tabela, só nos itens do sistema.
  function economia(quote) {
    let tab = 0;
    let neg = 0;
    (quote.items || []).forEach((it) => {
      if (!it.iv || !(it.iv.tabela > 0)) return;
      const q = Number(it.qtd) || 0;
      tab += F.liquido(it.iv.tabela, 0, q);
      neg += F.linha(it);
    });
    const valor = round2(tab - neg);
    return { tabela: round2(tab), valor: valor > 0 ? valor : 0, pct: tab > 0 && valor > 0 ? round2((valor / tab) * 100) : 0 };
  }

  function isMultiple(qtd, mult) {
    if (!(mult > 0)) return true;
    const r = qtd / mult;
    return Math.abs(r - Math.round(r)) < 1e-6;
  }

  // A API recalcula o preço a partir da tabela; o que o vendedor mexeu no orçamento vira desconto/acréscimo percentual.
  // O desconto global em R$ é espalhado proporcionalmente, para o total do sistema bater com o que o cliente viu.
  function buildItems(quote, user) {
    const items = (quote.items || []).filter((i) => i.desc || i.iv);
    const errors = [];
    const sub = items.reduce((s, i) => s + (Number(i.qtd) || 0) * (Number(i.preco) || 0), 0);
    const glob = sub > 0 ? Math.min(1, (Number(quote.desconto) || 0) / sub) : 0;
    const out = [];
    items.forEach((i, idx) => {
      const n = idx + 1;
      if (!i.iv || !i.iv.id) { errors.push(`Item ${n} (${i.desc || 'sem nome'}) não veio do sistema — busque pelo estoque.`); return; }
      const qtd = Number(i.qtd) || 0;
      if (qtd <= 0) { errors.push(`Item ${n}: quantidade zerada.`); return; }
      if (!isMultiple(qtd, i.iv.multiplo)) { errors.push(`Item ${n}: quantidade precisa ser múltiplo de ${i.iv.multiplo}.`); return; }
      const tabela = i.iv.tabela;
      const final = (Number(i.preco) || 0) * (1 - glob);
      let desconto = 0;
      let acrescimo = 0;
      if (tabela > 0) {
        const pct = !glob && typeof i.pct === 'number' ? i.pct : round2((1 - final / tabela) * 100);
        if (pct > 0) desconto = pct;
        else if (pct < 0) acrescimo = -pct;
      }
      if (user && desconto > user.descontoMax + 1e-9) errors.push(`Item ${n}: desconto de ${pctBr(desconto)} passa do seu limite (${pctBr(user.descontoMax)}).`);
      if (user && acrescimo > user.acrescimoMax + 1e-9) errors.push(`Item ${n}: acréscimo de ${pctBr(acrescimo)} passa do seu limite (${pctBr(user.acrescimoMax)}).`);
      out.push({ produto_id: i.iv.id, quantidade: qtd, desconto, acrescimo });
    });
    if (!out.length && !errors.length) errors.push('Orçamento sem itens.');
    return { items: out, errors };
  }

  function detalhesPayload(d) {
    const o = {};
    if (d.formaPagamentoId) o.forma_pagamento_id = Number(d.formaPagamentoId);
    if (d.transportadoraId) o.transportadora_id = Number(d.transportadoraId);
    if (d.tipoFrete) o.tipo_frete = d.tipoFrete;
    if (d.frete != null && d.frete !== '') o.valor_frete = Number(d.frete) || 0;
    if (d.observacao) o.observacao = String(d.observacao);
    return o;
  }

  function checkRequired(params, d) {
    const errs = [];
    if (params && params.forma_pagamento_obrigatoria && !d.formaPagamentoId) errs.push('A empresa exige forma de pagamento.');
    if (params && params.transportadora_obrigatoria && !d.transportadoraId) errs.push('A empresa exige transportadora.');
    return errs;
  }

  // Itens entram um por vez: a API recusa com 429 dois "adiciona-item" simultâneos no mesmo pedido.
  // Com pedidoId, sincroniza o pedido já criado com o orçamento (salvar de novo não duplica pedido).
  async function createOrder(call, { pedidoId, clienteId, items, detalhes, finalizar }, onStep = () => {}) {
    let id = pedidoId;
    let numero;
    let existing = [];
    if (id) {
      const cur = await call('GET', `pedidos/${id}`);
      if (cur.finalizado) throw new Error(`O pedido nº ${cur.pedido_numero} já foi finalizado; ele não pode mais ser alterado.`);
      numero = cur.pedido_numero;
      existing = (cur.itens || []).filter((i) => !i.excluido);
    } else {
      onStep('Criando pedido…');
      const pedido = await call('POST', `pedidos/create?cliente=${encodeURIComponent(clienteId)}`);
      id = pedido.pedido_id;
      numero = pedido.pedido_numero;
    }
    const result = { id, numero, finalizado: false, errors: [] };
    try {
      const byProduct = new Map(existing.map((i) => [i.produto_id, i]));
      for (let k = 0; k < items.length; k++) {
        const it = items[k];
        const old = byProduct.get(it.produto_id);
        onStep(`Item ${k + 1}/${items.length}…`);
        if (old) {
          byProduct.delete(it.produto_id);
          if (old.quantidade !== it.quantidade || old.desconto !== it.desconto || old.acrescimo !== it.acrescimo) {
            await call('PUT', `pedidos/atualizar-item/${id}`, { item_id: old.item_id, quantidade: it.quantidade, desconto: it.desconto, acrescimo: it.acrescimo });
          }
        } else {
          await call('POST', `pedidos/adiciona-item/${id}`, it);
        }
      }
      for (const gone of byProduct.values()) await call('DELETE', `pedidos/deletar-item/${id}/${gone.item_id}`);
      if (detalhes && Object.keys(detalhes).length) {
        onStep('Salvando pagamento e frete…');
        await call('PUT', `pedidos/atualizar-detalhes/${id}`, detalhes);
      }
      if (finalizar) {
        onStep('Finalizando…');
        await call('PUT', `pedidos/finalizar/${id}`);
        result.finalizado = true;
      }
    } catch (e) {
      result.errors.push(e.message || String(e));
    }
    try {
      const full = await call('GET', `pedidos/${id}`);
      result.total = full.valor_total;
      result.status = full.status_pedido;
      result.finalizado = !!full.finalizado || result.finalizado;
      result.itens = (full.itens || []).filter((i) => !i.excluido);
    } catch (_) { /* o pedido já existe; o resumo é só conveniência */ }
    return result;
  }

  function formatPedido(r, ctx = {}) {
    const out = [`*Pedido nº ${r.numero}${ctx.loja ? ` – ${ctx.loja}` : ''}*`, ''];
    (r.itens || []).filter((i) => !i.excluido).forEach((i, idx) => {
      out.push(`${idx + 1}) ${i.descricao}${i.codigo ? ` (cód. ${i.codigo})` : ''}`);
      const unit = i.quantidade ? i.preco_liquido / i.quantidade : 0;
      out.push(`   ${i.quantidade} x ${brl(unit)} = *${brl(i.preco_liquido)}*`);
    });
    out.push('');
    out.push(`*Total: ${brl(r.total)}*`);
    if (ctx.pix && !r.finalizado) out.push(`Pix: ${ctx.pix}`);
    out.push(r.finalizado ? '_Pedido confirmado e enviado para separação._' : '_Orçamento registrado; confirmo assim que você aprovar._');
    return out.join('\n');
  }

  const brl = (n) => (Number(n) || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

  // Não expõe a quantidade em estoque ao cliente: só se tem ou não.
  function precoMsg(p) {
    const un = p.unidade ? ` / ${String(p.unidade).toLowerCase()}` : '';
    const out = [`*${p.descricao}*`, `Cód. ${p.codigo}`, `*${brl(p.preco_tabela)}*${un}`];
    if (Number(p.multiplo) > 1) out.push(`Vendido de ${p.multiplo} em ${p.multiplo}.`);
    out.push(Number(p.estoque) > 0 ? 'Pronta entrega.' : 'Sem estoque no momento; posso encomendar pra você.');
    return out.join('\n');
  }

  // Acréscimo sobre a tabela não aparece para o cliente; estoque nunca revela a quantidade.
  function itemMsg(it) {
    const qtd = Number(it.qtd) || 0;
    const preco = Number(it.preco) || 0;
    const tabela = it.iv ? Number(it.iv.tabela) || 0 : 0;
    const un = it.iv && it.iv.unidade ? ` ${String(it.iv.unidade).toLowerCase()}` : '';
    const pct = typeof it.pct === 'number' ? it.pct : tabela > preco ? round2((1 - preco / tabela) * 100) : 0;
    const out = [`*${it.desc}*`];
    if (it.codigo) out.push(`Cód. ${it.codigo}`);
    out.push(`Qtd: ${String(qtd).replace('.', ',')}${un}`);
    out.push(pct > 0 && tabela > 0 ? `Unitário: ~${brl(tabela)}~ *${brl(preco)}* (${pctBr(pct)} de desconto)` : `Unitário: *${brl(preco)}*`);
    out.push(`Total: *${brl(F.linha(it))}*`);
    const est = it.iv ? Number(it.iv.estoque) || 0 : 0;
    if (it.iv) out.push(est >= qtd ? 'Pronta entrega.' : est > 0 ? 'Parte a pronta entrega; o restante sob encomenda.' : 'Sob encomenda.');
    return out.join('\n');
  }

  // Item de pedido já feito: o que o cliente levou, com o número e a data do pedido.
  function itemPedidoMsg(x, ped) {
    const qtd = Number(x.quantidade) || 0;
    const tabela = Number(x.valor_unitario) || 0;
    const liq = Number(x.preco_liquido) || 0;
    const unit = qtd ? round2(liq / qtd) : 0;
    const desc = round2(Number(x.desconto) || 0);
    const acr = round2(Number(x.acrescimo) || 0);
    const un = x.unidade ? ` ${String(x.unidade).toLowerCase()}` : '';
    const out = [`*${x.descricao}*`];
    if (x.codigo) out.push(`Cód. ${x.codigo}`);
    out.push(`Pedido nº ${ped.numero}${ped.data ? ` de ${dataBr(ped.data)}` : ''}`);
    out.push(`Qtd: ${String(qtd).replace('.', ',')}${un}`);
    out.push(desc > 0 && tabela > unit ? `Unitário: ~${brl(tabela)}~ *${brl(unit)}* (${pctBr(desc)} de desconto)`
      : acr > 0 ? `Unitário: *${brl(unit)}* (${pctBr(acr)} de acréscimo)` : `Unitário: *${brl(unit)}*`);
    out.push(`Total: *${brl(liq)}*`);
    return out.join('\n');
  }

  function precosMsg(prods) {
    if (prods.length === 1) return precoMsg(prods[0]);
    const out = ['*Cotação*', ''];
    prods.forEach((p, i) => {
      const un = p.unidade ? ` / ${String(p.unidade).toLowerCase()}` : '';
      out.push(`${i + 1}) *${p.descricao}*`);
      out.push(`   Cód. ${p.codigo} · *${brl(p.preco_tabela)}*${un}${Number(p.multiplo) > 1 ? ` · de ${p.multiplo} em ${p.multiplo}` : ''}`);
      out.push(`   ${Number(p.estoque) > 0 ? 'Pronta entrega' : 'Sob encomenda'}`);
    });
    return out.join('\n');
  }

  // Cotação da lista do cliente: quantidade já no múltiplo do produto; estoque só diz se tem.
  function cotacaoMsg(linhas, faltam = []) {
    const qtdBr = (q) => String(q).replace('.', ',');
    const bloco = ({ p, qtd }) => {
      const mult = Number(p.multiplo) || 1;
      const q = Math.ceil((Number(qtd) || 1) / mult - 1e-9) * mult;
      const preco = Number(p.preco_tabela) || 0;
      const est = Number(p.estoque) || 0;
      const un = p.unidade ? ` ${String(p.unidade).toLowerCase()}` : '';
      return { sub: round2(q * preco), linhas: [`*${p.descricao}*`, `Cód. ${p.codigo} · ${qtdBr(q)}${un} x ${brl(preco)} = *${brl(round2(q * preco))}*`,
        est >= q ? 'Pronta entrega' : est > 0 ? 'Parte a pronta entrega, o restante sob encomenda' : 'Sob encomenda'] };
    };
    const bs = linhas.map(bloco);
    if (bs.length === 1 && !faltam.length) return bs[0].linhas.join('\n');
    const out = ['*Cotação*', ''];
    bs.forEach((b, i) => { out.push(`${i + 1}) ${b.linhas[0]}`, ...b.linhas.slice(1).map((x) => `   ${x}`)); });
    if (bs.length > 1) out.push('', `Total: *${brl(round2(bs.reduce((a, b) => a + b.sub, 0)))}*`);
    if (faltam.length) out.push('', `Não encontrei: ${faltam.join('; ')}. Vou verificar e te retorno.`);
    return out.join('\n');
  }

  // Resposta de "tem em estoque?" da lista: nunca revela a quantidade, só tem / parte / não tem.
  function estoqueSituacao(p, qtd) {
    const mult = Number(p.multiplo) || 1;
    const q = Math.ceil((Number(qtd) || 1) / mult - 1e-9) * mult;
    const est = Number(p.estoque) || 0;
    return { q, sit: est >= q ? 'tem' : est > 0 ? 'parte' : 'falta' };
  }
  function estoqueMsg(linhas, faltam = []) {
    const grupos = { tem: [], parte: [], falta: [] };
    linhas.forEach(({ p, qtd }) => {
      const { q, sit } = estoqueSituacao(p, qtd);
      const un = p.unidade ? ` ${String(p.unidade).toLowerCase()}` : '';
      grupos[sit].push(`• ${String(q).replace('.', ',')}${un} ${p.descricao}`);
    });
    const out = [];
    const bloco = (titulo, l) => { if (!l.length) return; if (out.length) out.push(''); out.push(titulo, ...l); };
    bloco('*Tem a pronta entrega:*', grupos.tem);
    bloco('*Tem parte; o restante sob encomenda:*', grupos.parte);
    bloco('*Não tem no momento (te aviso quando chegar):*', grupos.falta);
    if (faltam.length) out.push('', `Não encontrei: ${faltam.join('; ')}. Vou verificar e te retorno.`);
    return out.join('\n');
  }

  const normNome = (s) => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').trim().toLowerCase();

  // A pesquisa da API casa por trecho do nome; aqui fica só o que é deste cliente.
  function cabecalhoPedido(p) {
    return {
      id: p.pedido_id, numero: p.pedido_numero, data: p.data_criacao, total: Number(p.valor_total) || 0,
      status: p.status_pedido || '', finalizado: !!p.finalizado, cancelado: /cancel/i.test(p.status_pedido || ''),
      cliente: p.cliente || '', forma: p.forma_pagamento || '', b2b: p.status_b2b || '',
    };
  }

  function comprasDoCliente(lista, nome) {
    const n = normNome(nome);
    return (lista || []).filter((p) => normNome(p.cliente) === n).map(cabecalhoPedido);
  }

  // Códigos do filtro "status" de GET pedidos/ (forca-vendas dao.getStatus); 0 = todos menos rascunho.
  const FILTROS_PEDIDO = [
    { id: 'todos', status: 0, label: 'Todos' },
    { id: 'orc', status: 2, label: 'Orçamento' },
    { id: 'conc', status: 5, label: 'Concluído' },
    { id: 'canc', status: 6, label: 'Cancelado' },
  ];

  function situacao(p) {
    const s = normNome(p.status);
    if (p.cancelado || s.includes('cancel')) return { label: 'cancelado', cls: 'bad', orc: false };
    if (s.includes('conclu')) return { label: 'concluído', cls: 'ok', orc: false };
    if (s.includes('orcamento')) return { label: 'em orçamento', cls: 'info', orc: true };
    if (s.includes('aberto')) return { label: 'aberto', cls: 'warn', orc: false };
    return { label: p.status || (p.finalizado ? 'finalizado' : 'aberto'), cls: p.finalizado ? 'ok' : 'info', orc: false };
  }

  // data_criacao vem DD-MM-YYYY.
  function diasDesde(data, now = Date.now()) {
    const m = String(data || '').match(/^(\d{2})[-/](\d{2})[-/](\d{4})/);
    if (!m) return null;
    const d = new Date(Number(m[3]), Number(m[2]) - 1, Number(m[1]));
    const hoje = new Date(now); hoje.setHours(0, 0, 0, 0);
    return Math.max(0, Math.round((hoje - d) / 864e5));
  }

  const idade = (dias) => (dias == null ? '' : dias === 0 ? 'hoje' : dias === 1 ? 'há 1 dia' : `há ${dias} dias`);

  function mesmoCliente(a, b) { return !!a && normNome(a) === normNome(b); }

  // A API repete o produto quando ele tem duas fotos marcadas como principal.
  function vitrine(lista) {
    const vistos = new Set();
    return (Array.isArray(lista) ? lista : []).filter((p) => p && p.id && p.ativo !== false && !vistos.has(p.id) && vistos.add(p.id));
  }

  // A foto da busca vem primeiro: produtos/{id} monta o link só pelo id e quebra a foto vinda do ERP.
  function fotosProduto(full, atual) {
    const lista = full && Array.isArray(full.imagens) ? full.imagens : [];
    const ord = lista.filter((i) => i && i.link).sort((a, b) => (b.principal ? 1 : 0) - (a.principal ? 1 : 0)).map((i) => i.link);
    return [...new Set([atual, ...ord].filter(Boolean))];
  }

  // Remonta o orçamento com o preço de hoje; o endpoint "duplicar" da API criaria um pedido novo no ERP.
  async function repetirPedido(call, pedidoId, clienteId, onStep = () => {}) {
    const ped = await call('GET', `pedidos/${pedidoId}`);
    const itens = (ped.itens || []).filter((i) => !i.excluido);
    const items = [];
    const faltando = [];
    for (let k = 0; k < itens.length; k++) {
      const old = itens[k];
      onStep(`Conferindo preço ${k + 1}/${itens.length}…`);
      let p = null;
      try {
        p = await call('GET', `pedidos/produtos/${old.produto_id}${clienteId ? `?cliente=${encodeURIComponent(clienteId)}` : ''}`);
      } catch (_) { /* produto excluído ou inativo */ }
      if (!p || !p.id || p.ativo === false) { faltando.push(old.descricao || `produto ${old.produto_id}`); continue; }
      const it = productToItem(p);
      const mult = it.iv.multiplo;
      it.qtd = Math.max(mult, Math.ceil((Number(old.quantidade) || mult) / mult) * mult);
      items.push(it);
    }
    return { numero: ped.pedido_numero, items, faltando };
  }

  function errorMessage(status, body) {
    if (status === 401) return 'Sessão expirada — entre de novo no IntegraVendas.';
    if (status === 429) return 'Muitas requisições seguidas; tente em alguns segundos.';
    if (status >= 500) return 'O servidor do IntegraVendas deu erro interno.';
    if (body && typeof body === 'object' && body.detail) return body.detail;
    if (typeof body === 'string' && body.trim()) return body.trim().slice(0, 200);
    return `Erro ${status}`;
  }

  const api = {
    DEFAULT_URL, baseUrl, originPattern, decodeJwt, userFromClaims, phoneTail, parsePhone, phoneList, samePhone, sem9, com9, phoneQueries, looksPhone, fmtPhone, cadastroMsg, maisComprados, ultimoPedido, dataBr, pagoNoPedido,
    clienteLabel, productToItem, buildItems, detalhesPayload, checkRequired, createOrder, formatPedido, errorMessage, isMultiple, pctBr, POLITICAS, polPct, polKey, polLabel, precoPol, fixaPct, pctDoPreco, aplicaPolitica, economia, precoMsg, itemMsg, itemPedidoMsg, precosMsg, cotacaoMsg, estoqueSituacao, estoqueMsg, comprasDoCliente, cabecalhoPedido, FILTROS_PEDIDO, situacao, diasDesde, idade, mesmoCliente, fotosProduto, vitrine, repetirPedido,
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else (root.MZ = root.MZ || {}).iv = api;
})(globalThis);

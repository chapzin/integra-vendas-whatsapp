(function (root) {
  const HOUR = 36e5;
  const DAY = 864e5;

  const OPEN_STAGES = ['orcamento', 'aguardando_pix'];

  const STAGES = [
    { id: 'novo', label: 'Novo' },
    { id: 'orcamento', label: 'Orçamento enviado' },
    { id: 'aguardando_pix', label: 'Aguardando Pix' },
    { id: 'pago', label: 'Pago' },
    { id: 'separando', label: 'Separando' },
    { id: 'enviado', label: 'Enviado/Retirado' },
    { id: 'pos_venda', label: 'Pós-venda' },
    { id: 'perdido', label: 'Perdido' },
  ];

  const MOTIVOS_PERDA = [
    { id: 'preco', label: 'Preço' },
    { id: 'estoque', label: 'Sem estoque' },
    { id: 'demora', label: 'Sumiu / demorou' },
    { id: 'concorrente', label: 'Comprou em outro lugar' },
    { id: 'outro', label: 'Outro' },
  ];

  // Cada toque traz algo novo (estoque, alternativa, despedida); sem novidade, melhor não mandar.
  const CADENCE = [
    { step: 1, offset: 2 * HOUR, label: '2h', text: 'Oi {nome}! Consegui separar as peças da {moto} aqui. Posso confirmar o pedido pra você?' },
    { step: 2, offset: DAY, label: 'D+1', text: 'Bom dia {nome}! O orçamento da {moto} ({total}) continua de pé e tem estoque. Quer que eu separe?' },
    { step: 3, offset: 3 * DAY, label: 'D+3', text: '{nome}, se o valor pesou, consigo uma opção paralela de boa qualidade mais em conta pra {moto}. Quer que eu mande?' },
    { step: 4, offset: 7 * DAY, label: 'D+7', text: '{nome}, vou encerrar esse orçamento pra não te incomodar. Quando precisar de peça pra {moto} é só chamar!' },
  ];

  // Referência: manual Honda CG 160 (óleo ~4.000 km ou 6 meses). Valores editáveis pela loja no futuro.
  const MAINT = [
    { id: 'oleo', label: 'troca de óleo', km: 4000, dias: 180 },
    { id: 'relacao', label: 'kit relação', km: 15000, dias: 365 },
    { id: 'pastilha', label: 'pastilha de freio', km: 10000, dias: 365 },
    { id: 'pneu', label: 'pneu traseiro', km: 12000, dias: 540 },
  ];

  const newId = () => (root.crypto && root.crypto.randomUUID ? root.crypto.randomUUID() : String(Math.random()).slice(2));

  function planCadence(start, idGen = newId) {
    return CADENCE.map((c) => ({
      id: idGen(), kind: 'cadencia', step: c.step, label: c.label, due: start + c.offset, text: c.text, status: 'pendente',
    }));
  }

  function makeTask(kind, label, text, due, idGen = newId) {
    return { id: idGen(), kind, label, due, text, status: 'pendente' };
  }

  const pending = (c) => (c.followups || []).filter((f) => f.status === 'pendente');

  function cancelCadence(contact) {
    (contact.followups || []).forEach((f) => {
      // Retorno de preço enviado também para: cliente respondeu, orçou ou comprou.
      if (f.status === 'pendente' && (f.kind === 'cadencia' || f.kind === 'preco')) f.status = 'cancelado';
    });
    return contact;
  }

  function setStage(contact, stage, now) {
    if (contact.stage === stage) return contact;
    // Histórico para as métricas; o estágio de antes entra com a data em que começou (contato anterior ao histórico).
    const log = contact.stageLog || (contact.stageLog = [{ stage: contact.stage || 'novo', at: contact.stageSince || now }]);
    log.push({ stage, at: now });
    if (log.length > 60) log.splice(0, log.length - 60);
    contact.stage = stage;
    contact.stageSince = now;
    // Cliente que volta deixa de contar como perdido; o motivo antigo não vale mais.
    if (stage !== 'perdido') delete contact.perda;
    if (!OPEN_STAGES.includes(stage)) cancelCadence(contact);
    return contact;
  }

  function dueTasks(contacts, now, horizon = 0) {
    const out = [];
    Object.values(contacts || {}).forEach((c) => {
      pending(c).forEach((f) => { if (f.due <= now + horizon) out.push({ contact: c, task: f }); });
    });
    return out.sort((a, b) => a.task.due - b.task.due);
  }

  function staleQuotes(contacts, now, days = 2) {
    return Object.values(contacts || {})
      .filter((c) => OPEN_STAGES.includes(c.stage) && c.stageSince && now - c.stageSince >= days * DAY && pending(c).length === 0)
      .sort((a, b) => a.stageSince - b.stageSince);
  }

  function nextMaintenance(rec, kmMes, rule) {
    if (!rec || !rec.date) return null;
    const byTime = rec.date + rule.dias * DAY;
    const km = Number(kmMes) || 0;
    if (km <= 0) return byTime;
    return Math.min(byTime, rec.date + (rule.km / km) * 30 * DAY);
  }

  function maintenanceDue(contacts, now, horizonDays = 7) {
    const out = [];
    Object.values(contacts || {}).forEach((c) => {
      (c.motos || []).forEach((m) => {
        MAINT.forEach((rule) => {
          const due = nextMaintenance((m.maint || {})[rule.id], m.kmMes, rule);
          if (due != null && due <= now + horizonDays * DAY) out.push({ contact: c, moto: m, rule, due });
        });
      });
    });
    return out.sort((a, b) => a.due - b.due);
  }

  function tempo(ms) {
    const m = Math.max(0, Math.floor(ms / 60e3));
    if (m < 60) return `${m || 1}min`;
    if (m < 24 * 60) return `${Math.floor(m / 60)}h`;
    return `${Math.floor(m / (24 * 60))}d`;
  }

  // O que o vendedor deve fazer agora com esse contato, e quão urgente: vermelho > âmbar > verde.
  function proximoPasso(c, now, x = {}) {
    if (!c) return null;
    const st = c.stage || 'novo';
    const desde = c.stageSince ? now - c.stageSince : 0;
    const t = c.stageSince ? tempo(desde) : '';
    const atrasado = pending(c).find((f) => f.due <= now);
    if (atrasado) return { stage: st, acao: 'Cobrar retorno', tempo: tempo(now - atrasado.due), urg: 'red' };
    if (x.chegou) return { stage: st, acao: 'Avisar: peça chegou', tempo: '', urg: 'green' };
    if (x.naoLida && st !== 'perdido') return { stage: st, acao: 'Responder', tempo: '', urg: 'amber' };
    const velho = OPEN_STAGES.includes(st) && desde >= 2 * DAY;
    const passo = {
      orcamento: 'Cobrar orçamento', aguardando_pix: 'Conferir Pix', pago: 'Separar pedido',
      separando: 'Avisar que está pronto', enviado: 'Confirmar entrega',
    }[st];
    if (!passo) return st === 'novo' ? null : { stage: st, acao: '', tempo: '', urg: '' };
    return { stage: st, acao: passo, tempo: t, urg: velho ? 'red' : '' };
  }

  function pipeline(contacts) {
    const out = {};
    STAGES.forEach((s) => { out[s.id] = { count: 0, total: 0 }; });
    Object.values(contacts || {}).forEach((c) => {
      const s = out[c.stage || 'novo'];
      if (!s) return;
      s.count += 1;
      const qs = c.quotes || [];
      const q = qs[qs.length - 1];
      if (q) s.total += Number(q.total) || 0;
    });
    return out;
  }

  // Perdidos agrupados por motivo, do maior valor ao menor; quem não tem motivo fica em "sem motivo".
  function perdas(contacts) {
    const by = new Map();
    Object.values(contacts || {}).forEach((c) => {
      if (c.stage !== 'perdido') return;
      const id = (c.perda && c.perda.motivo) || '';
      const m = MOTIVOS_PERDA.find((x) => x.id === id);
      const g = by.get(id) || { id, label: m ? m.label : 'sem motivo', count: 0, total: 0 };
      g.count += 1;
      g.total += Number(c.perda && c.perda.valor) || 0;
      by.set(id, g);
    });
    return [...by.values()].sort((a, b) => (!a.id) - (!b.id) || b.total - a.total || b.count - a.count);
  }

  const GANHOS = ['pago', 'separando', 'enviado', 'pos_venda'];
  const mediana = (xs) => {
    if (!xs.length) return null;
    const a = xs.slice().sort((x, y) => x - y);
    const m = Math.floor(a.length / 2);
    return a.length % 2 ? a[m] : (a[m - 1] + a[m]) / 2;
  };

  // Negociações que começaram (orçamento ou venda direta) nos últimos `dias`: quantas viraram venda,
  // quanto tempo cada etapa levou e quanto foi perdido. Só conta o que tem histórico de estágio.
  function metricas(contacts, now, dias = 30) {
    const ini = now - dias * DAY;
    const tempos = {};
    OPEN_STAGES.concat(GANHOS.slice(0, 3)).forEach((id) => { tempos[id] = []; });
    const ateVenda = [];
    let negs = 0; let ganhos = 0; let perdidos = 0; let valorPerdido = 0; let desde = null;
    Object.values(contacts || {}).forEach((c) => {
      const log = c.stageLog || [];
      if (log.length < 2) return;
      const t0 = log[0].at;
      if (desde == null || t0 < desde) desde = t0;
      const abre = log.findIndex((e) => e.at >= ini && (OPEN_STAGES.includes(e.stage) || GANHOS.includes(e.stage)));
      if (abre < 0) return;
      negs += 1;
      const venda = log.findIndex((e, i) => i >= abre && GANHOS.includes(e.stage));
      if (venda >= 0) { ganhos += 1; if (venda > abre) ateVenda.push(log[venda].at - log[abre].at); }
      else if (c.stage === 'perdido') { perdidos += 1; valorPerdido += Number(c.perda && c.perda.valor) || 0; }
      for (let i = abre; i < log.length - 1; i++) if (tempos[log[i].stage]) tempos[log[i].stage].push(log[i + 1].at - log[i].at);
    });
    return {
      dias, desde, negs, ganhos, perdidos, valorPerdido,
      conversao: negs ? Math.round((ganhos / negs) * 100) : null,
      ateVenda: mediana(ateVenda),
      etapas: STAGES.filter((st) => tempos[st.id] && tempos[st.id].length).map((st) => ({ id: st.id, label: st.label, n: tempos[st.id].length, mediana: mediana(tempos[st.id]) })),
    };
  }

  const api = {
    HOUR, metricas, MOTIVOS_PERDA, perdas, DAY, STAGES, OPEN_STAGES, CADENCE, MAINT,
    planCadence, makeTask, cancelCadence, setStage, dueTasks, staleQuotes, nextMaintenance, maintenanceDue, pipeline, proximoPasso, tempo,
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else (root.MZ = root.MZ || {}).followup = api;
})(globalThis);

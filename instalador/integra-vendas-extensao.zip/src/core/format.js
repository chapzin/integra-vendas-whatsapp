(function (root) {
  function brl(n) {
    return (Number(n) || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  }

  function fill(tpl, vars) {
    return String(tpl)
      .replace(/\{(\w+)\}/g, (_, k) => (vars[k] == null ? '' : String(vars[k])))
      .replace(/[ \t]{2,}/g, ' ')
      .replace(/ ([,.!?])/g, '$1')
      .replace(/^[\s,.;]+/, '')
      .replace(/^\p{Ll}/u, (ch) => ch.toUpperCase());
  }

  function firstName(name) {
    const n = String(name || '').trim();
    if (!n || /^\+?[\d\s()-]+$/.test(n)) return '';
    return n.split(/\s+/)[0];
  }

  function motoLabel(m) {
    if (!m || !m.modelo) return '';
    return m.ano ? `${m.modelo} ${m.ano}` : m.modelo;
  }

  // Mesma ordem de operações de uteis.CalculaDescontoAcrescimo da API: só o total da linha é arredondado.
  function liquido(tabela, pct, qtd) {
    let v = Number(tabela) || 0;
    if (pct > 0) v -= (v * pct) / 100;
    else if (pct < 0) v += (v * -pct) / 100;
    return Math.round(v * qtd * 100) / 100;
  }

  // Item do sistema com percentual gravado tem o total que a API vai calcular; os demais, qtd × preço.
  function linha(i) {
    const q = Number(i.qtd) || 0;
    if (i.iv && i.iv.tabela > 0 && typeof i.pct === 'number') return liquido(i.iv.tabela, i.pct, q);
    return Math.round(q * (Number(i.preco) || 0) * 100) / 100;
  }

  function quoteTotals(q) {
    const sub = Math.round((q.items || []).reduce((s, i) => s + linha(i), 0) * 100) / 100;
    const desconto = Number(q.desconto) || 0;
    const frete = Number(q.frete) || 0;
    return { sub, desconto, frete, total: Math.max(0, sub - desconto + frete) };
  }

  function ddmm(ms) {
    const d = new Date(ms);
    return `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}`;
  }

  function formatQuote(q, ctx = {}) {
    const t = quoteTotals(q);
    const out = [];
    out.push(ctx.loja ? `*Orçamento – ${ctx.loja}*` : '*Orçamento*');
    if (ctx.moto) out.push(`Moto: ${ctx.moto}`);
    out.push('');
    (q.items || []).filter((i) => i.desc).forEach((i, idx) => {
      const extra = [i.marca, i.tipo, i.codigo ? `cód. ${i.codigo}` : ''].filter(Boolean).join(' · ');
      const qtd = Number(i.qtd) || 0;
      out.push(`${idx + 1}) ${i.desc}${extra ? ` (${extra})` : ''}`);
      out.push(`   ${qtd} x ${brl(i.preco)} = *${brl(linha(i))}*`);
    });
    out.push('');
    if (t.desconto || t.frete) out.push(`Subtotal: ${brl(t.sub)}`);
    if (t.desconto) out.push(`Desconto: - ${brl(t.desconto)}`);
    if (t.frete) out.push(`Frete: ${brl(t.frete)}`);
    out.push(`*Total: ${brl(t.total)}*`);
    if (ctx.condicao) out.push(`Condição: ${ctx.condicao}${ctx.economia > 0.004 ? ` (economia de ${brl(ctx.economia)})` : ''}`);
    if (ctx.pix) out.push(`Pix: ${ctx.pix}`);
    if (ctx.validadeDias && ctx.now) out.push(`_Válido até ${ddmm(ctx.now + ctx.validadeDias * 864e5)}._`);
    return out.join('\n');
  }

  const api = { brl, liquido, linha, fill, firstName, motoLabel, quoteTotals, formatQuote, ddmm };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else (root.MZ = root.MZ || {}).format = api;
})(globalThis);

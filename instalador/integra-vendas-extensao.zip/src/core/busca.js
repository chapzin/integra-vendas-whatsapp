// A API devolve os produtos em ordem alfabética e corta no limite: a relevância é montada aqui.
(function (root) {
  const norm = (s) => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
  const tokens = (s) => norm(s).split(/[^a-z0-9]+/).filter(Boolean);

  const VAZIAS = new Set(['de', 'da', 'do', 'das', 'dos', 'pra', 'pro', 'para', 'p', 'com', 'c', 'e', 'a', 'o', 'um', 'uma', 'no', 'na', 'em']);

  // Abreviações do catálogo que não são só o começo da palavra (essas o prefixo já pega).
  const ABREV = {
    dianteiro: ['d', 'diant', 'dt'], dianteira: ['d', 'diant', 'dt'],
    traseiro: ['t', 'tras', 'tr'], traseira: ['t', 'tras', 'tr'],
    esquerdo: ['le', 'esq'], esquerda: ['le', 'esq'],
    direito: ['ld', 'dir'], direita: ['ld', 'dir'],
    rolamento: ['rol'], retentor: ['ret'], titan: ['tit'], corrente: ['corr'], combustivel: ['comb'],
    embreagem: ['embr', 'emb'], twister: ['twis', 'twi'], tornado: ['torn', 'tor'], vermelho: ['verm'], borracha: ['borr'],
  };

  function singular(w) {
    if (w.length <= 3 || /\d/.test(w) || FAMILIAS.has(w) || MARCAS.has(w)) return w;
    if (/[oa]es$/.test(w)) return `${w.slice(0, -3)}ao`;
    if (/res$/.test(w)) return w.slice(0, -2);
    if (/[aeo]is$/.test(w)) return `${w.slice(0, -2)}l`;
    if (/ns$/.test(w)) return `${w.slice(0, -2)}m`;
    if (/[^s]s$/.test(w)) return w.slice(0, -1);
    return w;
  }

  // Como o cliente escreve → como o catálogo escreve. A API só casa a palavra do catálogo.
  const GIRIAS = {
    tracao: 'relacao', guidon: 'guidao', guidom: 'guidao', guidam: 'guidao', guidau: 'guidao',
    maneta: 'manete', pastilia: 'pastilha', coxin: 'coxim',
    // O catálogo trunca ("AMORTEC", "EMBREAG"): mandando o pedaço, o prefixo acha as duas grafias.
    amortecedor: 'amortec', embreagem: 'embreag', embreage: 'embreag', imbreagem: 'embreag', carburador: 'carbur',
  };

  // "-anel" tira da lista; o que vai para a API é só o que precisa bater.
  function prepara(q, aprendidas) {
    const termos = [];
    const fora = [];
    norm(q).split(/\s+/).forEach((raw) => {
      const neg = raw.startsWith('-') && raw.length > 1;
      tokens(neg ? raw.slice(1) : raw).forEach((t) => {
        if (VAZIAS.has(t)) return;
        if (neg) { fora.push(t); return; }
        const w = singular(t);
        termos.push((aprendidas && aprendidas[w]) || GIRIAS[w] || w);
      });
    });
    return { envia: termos.join(' '), termos, fora, chave: termos.join(' ') };
  }

  // 3 = palavra igual ou abreviação conhecida, 2 = a palavra começa com o termo, 1 = o termo está dentro da palavra.
  function nivel(w, t) {
    if (w === t) return 3;
    if ((ABREV[t] || []).includes(w)) return 3;
    if (w.length >= 4 && t.length > w.length && t.startsWith(w)) return 3;
    if (t.length >= 2 && w.startsWith(t)) return 2;
    if (t.length >= 3 && w.includes(t)) return 1;
    return 0;
  }

  // Famílias de moto como aparecem no catálogo; a cilindrada sozinha não basta ("160" serve CG, Bros e Fan).
  const MARCAS = new Set(['honda', 'yamaha', 'suzuki', 'haojue', 'shineray', 'mottu', 'dafra', 'kawasaki']);
  const FAMILIAS = new Set(['cg', 'titan', 'tit', 'fan', 'start', 'cargo', 'biz', 'pop', 'bros', 'nxr', 'xre', 'cb', 'twister', 'pcx', 'elite',
    'factor', 'fazer', 'fz', 'crosser', 'lander', 'nmax', 'fluo', 'ybr', 'xtz', 'yes', 'dk', 'dr', 'jet', 'worker', 'sport', 'cbx', 'nx', 'xr', 'today', 'strada']);
  const partes = (s) => norm(s).match(/[a-z]+|\d+/g) || [];
  const ehFamilia = (w, fams) => fams.some((f) => w === f || (ABREV[f] || []).includes(w));

  function motoCtx(modelos) {
    const fams = []; const cc = [];
    (modelos || []).forEach((m) => partes(m).forEach((w) => {
      if (MARCAS.has(w)) return;
      if (/^\d+$/.test(w)) { if (Number(w) >= 50 && Number(w) <= 1300) cc.push(w); } else if (FAMILIAS.has(w) || ABREV[w]) fams.push(w);
    }));
    return fams.length ? { fams: [...new Set(fams)], cc: [...new Set(cc)] } : null;
  }

  // Quem digitou a moto na busca já escolheu: a moto da ficha só desempata quando a consulta não fala de moto.
  function consultaTemMoto(prep) {
    return prep.termos.some((t) => partes(t).some((w) => FAMILIAS.has(w)));
  }

  // Moto citada num texto ("capa azul da bros", "guidao crosser 150"). Texto com duas famílias
  // (ficha de produto "TIT/BIZ/POP") não diz de qual moto se fala: devolve vazio.
  // "pode fazer por 50?" é verbo; a Fazer só conta com cilindrada, "fz" ou artigo/marca antes ("da fazer").
  const VERBO_MOTO = new Set(['fazer', 'start']);
  const ANTES_MOTO = new Set(['da', 'na', 'uma', 'minha', 'sua', 'essa', 'dessa', 'desta', 'nessa', 'yamaha', 'honda', 'cg']);
  function motoNoTexto(texto) {
    const ws = partes(String(texto || '').replace(/(?:https?:\/\/|www\.)\S+/gi, ' ')); // "watch?v=nX0w…" não é a Honda NX
    const achou = [];
    ws.forEach((w, i) => {
      if (!FAMILIAS.has(w)) return;
      const n = ws[i + 1];
      if (w === 'cg' && FAMILIAS.has(n)) return; // "cg start", "cg titan": cg é o prefixo da linha
      if (VERBO_MOTO.has(w) && !(n && /^\d+$/.test(n)) && !ANTES_MOTO.has(ws[i - 1]) && n !== 'fz') return;
      achou.push({ fam: w, cc: n && /^\d+$/.test(n) && Number(n) >= 50 && Number(n) <= 1300 ? n : '' });
    });
    if (!achou.length || new Set(achou.map((x) => x.fam)).size > 1) return '';
    const cc = achou.map((x) => x.cc).filter(Boolean).pop();
    return cc ? `${achou[0].fam} ${cc}` : achou[0].fam;
  }
  // Do mais recente para o mais antigo: a primeira moto sem ambiguidade.
  function motoAntes(textos) {
    for (let i = (textos || []).length - 1; i >= 0; i--) { const m = motoNoTexto(textos[i]); if (m) return m; }
    return '';
  }

  // Nome que muda de uma loja para outra: não reescreve, tenta o outro quando o primeiro não acha nada.
  const SINONIMOS = { retrovisor: 'espelho', espelho: 'retrovisor' };
  // Peça universal vem como "P/HONDA": sem nada para a Bros, a marca dela é a próxima tentativa.
  const MARCA_DE = {};
  [['honda', 'cg titan tit fan start cargo biz pop bros nxr xre cb twister pcx elite cbx nx xr today strada'],
    ['yamaha', 'factor fazer fz crosser lander nmax fluo ybr xtz'], ['suzuki', 'yes']]
    .forEach(([m, fs]) => fs.split(' ').forEach((f) => { MARCA_DE[f] = m; }));
  function alternativas(envia) {
    const ws = String(envia || '').split(' ').filter(Boolean);
    const sin = ws.map((w) => SINONIMOS[w] || w);
    // Só a primeira família vira marca; "cg 160" → "honda" (a cilindrada sozinha não ajuda).
    const marca = (a) => {
      const i = a.findIndex((w) => MARCA_DE[w]);
      if (i < 0) return a;
      return [...a.slice(0, i), MARCA_DE[a[i]], ...a.slice(i + 1).filter((w) => !/^\d+$/.test(w))];
    };
    return [...new Set([sin, marca(ws), marca(sin)].map((a) => a.join(' ')))].filter((t) => t && t !== ws.join(' '));
  }

  const famCanon = (w) => (FAMILIAS.has(w) && !Object.values(ABREV).some((a) => a.includes(w)) ? w
    : Object.keys(ABREV).find((k) => FAMILIAS.has(k) && ABREV[k].includes(w)) || w);
  // "bros" → "Honda Bros 160" pelo catálogo de modelos; sem par no catálogo, só capitaliza.
  function nomeMoto(citada, catalogo) {
    const [f, cc] = String(citada || '').split(' ');
    const fam = famCanon(f);
    const ok = (m) => { const ws = partes(m); return ws.includes(fam) && (!cc || ws.includes(cc)); };
    return (catalogo || []).find(ok) || [fam, cc].filter(Boolean).join(' ').replace(/\b[a-z]/g, (l) => l.toUpperCase());
  }
  // Motos citadas pelo cliente que a Ficha ainda não tem (nem foram descartadas): a mais recente primeiro.
  function motosNovas(citadas, modelos, ignoradas) {
    const naFicha = new Set(((motoCtx(modelos) || {}).fams || []).map(famCanon));
    const fora = new Set((ignoradas || []).map(famCanon));
    const vistas = new Set();
    return [...(citadas || [])].reverse().filter((m) => {
      const fam = famCanon(m.split(' ')[0]);
      if (naFicha.has(fam) || fora.has(fam) || vistas.has(fam)) return false;
      vistas.add(fam);
      return true;
    });
  }

  function pontoMoto(nome, moto) {
    const ws = partes(nome);
    const fam = ws.some((w) => ehFamilia(w, moto.fams));
    if (!fam) return ws.some((w) => FAMILIAS.has(w)) ? -6 : 0;
    return moto.cc.some((c) => ws.includes(c)) ? 18 : 10;
  }

  function pontua(p, prep, ctx = {}) {
    const nome = tokens(p.descricao);
    const cod = norm(p.codigo);
    const q = prep.termos;
    let s = 0;
    if (q.length === 1 && cod && cod === q[0]) s += 200;
    else if (q.length && cod && q.some((t) => t.length >= 3 && cod.startsWith(t))) s += 40;
    const pos = [];
    let noNome = 0;
    q.forEach((t) => {
      let best = 0; let at = -1;
      nome.forEach((w, i) => { const n = nivel(w, t); if (n > best) { best = n; at = i; } });
      if (best) { noNome++; s += best * 10 + Math.max(0, 6 - at); pos.push(at); }
    });
    if (q.length && noNome === q.length) s += 30;
    else if (!noNome) s -= 30;
    if (q.length && nome.length && nivel(nome[0], q[0]) >= 2) s += 25;
    else if (pos.includes(0)) s += 12;
    if (pos.length > 1 && pos.every((x, i) => i === 0 || x > pos[i - 1])) s += 5;
    if (Number(p.estoque) > 0) s += 6;
    if (p.ultimo_pedido && p.ultimo_pedido.id) s += 10;
    if (ctx.costuma && ctx.costuma.has(p.id)) s += 6;
    const esc = ctx.escolhas && ctx.escolhas[p.id];
    if (esc) s += 15 * Math.min(esc, 3);
    if (ctx.moto && !ctx.motoNaConsulta) s += pontoMoto(p.descricao, ctx.moto);
    return s - nome.length * 0.3;
  }

  function ordena(lista, prep, ctx = {}) {
    const fora = prep.fora;
    if (ctx.moto) ctx = { ...ctx, motoNaConsulta: consultaTemMoto(prep) };
    return (lista || [])
      .map((p, i) => ({ p, i, nome: tokens(p.descricao) }))
      .filter((x) => !fora.length || !fora.some((f) => x.nome.some((w) => w.startsWith(f))))
      .map((x) => ({ ...x, s: pontua(x.p, prep, ctx) }))
      .sort((a, b) => b.s - a.s || a.i - b.i)
      .map((x) => x.p);
  }

  // O primeiro nome da descrição é o tipo da peça (ÓLEO, ANEL, FILTRO): vira filtro rápido.
  function tipo(p) { return tokens(p.descricao)[0] || ''; }
  function tipos(lista, prep, max = 6) {
    const cont = new Map();
    (lista || []).forEach((p) => { const t = tipo(p); if (t && !/^\d/.test(t)) cont.set(t, (cont.get(t) || 0) + 1); });
    const q0 = prep && prep.termos[0];
    return [...cont].map(([id, n]) => ({ id, n, casa: q0 ? nivel(id, q0) >= 2 : false }))
      .sort((a, b) => b.casa - a.casa || b.n - a.n)
      .slice(0, max);
  }

  function aprende(mapa, chave, id, max = 300) {
    if (!chave || !id) return mapa;
    const m = mapa || {};
    const cur = m[chave] || {};
    delete m[chave];
    cur[id] = (cur[id] || 0) + 1;
    m[chave] = cur;
    const ks = Object.keys(m);
    if (ks.length > max) ks.slice(0, ks.length - max).forEach((k) => delete m[k]);
    return m;
  }

  // Quanto o primeiro da lista parece ser o que o cliente pediu.
  function cobre(p, prep) {
    const nome = [...tokens(p.descricao), ...partes(p.descricao)];
    const q = prep.termos;
    if (!q.length) return 0;
    if (q.length === 1 && norm(p.codigo) === q[0]) return 1;
    return q.filter((t) => nome.some((w) => nivel(w, t) >= 2)).length / q.length;
  }
  function certeza(ordenados, prep, ctx = {}) {
    const [a, b] = ordenados || [];
    if (!a) return 'nada';
    const ca = cobre(a, prep);
    if (ca < 0.5) return 'baixa';
    if (ca < 1) return 'confira';
    if (!b || cobre(b, prep) < 1) return 'alta';
    return pontua(a, prep, ctx) - pontua(b, prep, ctx) >= 8 ? 'alta' : 'confira';
  }

  // Vendedor trocou uma palavra só ("guidon" → "guidao") e escolheu um produto: a troca vale nas próximas buscas.
  function aprendeGiria(mapa, antes, depois) {
    const a = tokens(antes).map(singular);
    const d = tokens(depois).map(singular);
    const saiu = a.filter((w) => !d.includes(w));
    const entrou = d.filter((w) => !a.includes(w));
    const m = mapa || {};
    if (saiu.length === 1 && entrou.length === 1 && saiu[0].length >= 3 && entrou[0].length >= 3) m[saiu[0]] = entrou[0];
    return m;
  }

  // Cliente: a API exige todas as palavras (como prefixo) ou a frase na ordem, não tira acento da consulta
  // e corta em ordem alfabética. Aqui a consulta vai limpa e a relevância é montada depois.
  const VAZIAS_CLI = new Set([...VAZIAS, 'ltda', 'me', 'epp', 'eireli', 'cia', 'mei']);
  function prepCliente(q) {
    const s = String(q || '').trim();
    if (!/[a-zA-ZÀ-ÿ]/.test(s)) return { envia: s, termos: [], numero: s.replace(/\D/g, '') };
    const termos = tokens(s).filter((t) => !VAZIAS_CLI.has(t));
    return { envia: termos.join(' '), termos, numero: '' };
  }

  // Erro de digitação: 1 letra trocada/faltando a partir de 4 letras, 2 a partir de 7.
  function perto(a, b) {
    const max = b.length >= 7 ? 2 : b.length >= 4 ? 1 : 0;
    if (!max || Math.abs(a.length - b.length) > max) return false;
    let prev = Array.from({ length: b.length + 1 }, (_, j) => j);
    for (let i = 1; i <= a.length; i++) {
      const cur = [i];
      let menor = i;
      for (let j = 1; j <= b.length; j++) {
        cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
        if (cur[j] < menor) menor = cur[j];
      }
      if (menor > max) return false;
      prev = cur;
    }
    return prev[b.length] <= max;
  }
  function nivelCli(w, t) {
    const n = nivel(w, t);
    if (n >= 2) return n;
    if (perto(w, t) || (w.length > t.length && perto(w.slice(0, t.length), t))) return 1.5;
    return n;
  }

  function pontuaCliente(x, termos, ctx = {}) {
    const fant = tokens(x.nome_fantasia);
    const razao = tokens(x.razao_social);
    const outros = tokens([x.cidade, x.bairro, x.email].filter(Boolean).join(' '));
    const melhor = (ws, t) => ws.reduce((m, w) => Math.max(m, nivelCli(w, t)), 0);
    let s = 0; let achou = 0; let soFant = 0; let soRazao = 0;
    termos.forEach((t) => {
      const f = melhor(fant, t); const r = melhor(razao, t);
      const b = Math.max(f, r * 0.95, melhor(outros, t) * 0.5);
      if (f) soFant++;
      if (r) soRazao++;
      if (b) { achou++; s += b * 10; }
    });
    if (termos.length && achou === termos.length) s += 30;
    else if (termos.length && !achou) s -= 40;
    if (termos.length > 1 && (soFant === termos.length || soRazao === termos.length)) s += 12;
    const t0 = termos[0];
    if (t0 && ((fant[0] && nivelCli(fant[0], t0) >= 2) || (razao[0] && nivelCli(razao[0], t0) >= 2))) s += 15;
    if (ctx.conhecidos && ctx.conhecidos.has(x.id)) s += 25;
    return s - Math.min(fant.length || razao.length, 12) * 0.2;
  }

  function ordenaClientes(lista, termos, ctx = {}) {
    if (!termos || !termos.length) return lista || [];
    return (lista || []).map((x, i) => ({ x, i, s: pontuaCliente(x, termos, ctx) }))
      .sort((a, b) => b.s - a.s || a.i - b.i)
      .map((y) => y.x);
  }

  // Nada com todas as palavras: primeiro o começo de cada uma (pega erro no fim da palavra), depois larga uma palavra.
  function afrouxarCliente(termos) {
    const corta = (t) => (t.length >= 5 ? t.slice(0, 4) : t);
    const out = [];
    const q = termos.join(' ');
    out.push(termos.map(corta).join(' '));
    // Erro já nas primeiras letras ("cleyton" × CLEITON): com duas palavras, 3 letras de cada ainda filtra bem.
    if (termos.length > 1) out.push(termos.map((t) => t.slice(0, 3)).join(' '));
    if (termos.length > 1) {
      // Larga primeiro a palavra mais curta: "moto" sozinho traz metade do cadastro.
      const curtas = termos.map((t, i) => [t.length, i]).sort((a, b) => a[0] - b[0]).map(([, i]) => i);
      curtas.forEach((i) => out.push(termos.filter((_, j) => j !== i).map(corta).join(' ')));
    }
    return [...new Set(out)].filter((t) => t !== q && t.replace(/\s/g, '').length >= 3);
  }

  // Todas as palavras batem com o nome (mesmo com erro de digitação): a busca pode parar de afrouxar.
  function casaCliente(x, termos) {
    const ws = [...tokens(x.nome_fantasia), ...tokens(x.razao_social)];
    return termos.length > 0 && termos.every((t) => ws.some((w) => nivelCli(w, t) >= 1.5));
  }

  const api = { norm, tokens, singular, prepara, nivel, pontua, ordena, tipo, tipos, aprende, motoCtx, consultaTemMoto, motoNoTexto, motoAntes, nomeMoto, motosNovas, alternativas, GIRIAS, certeza, cobre, aprendeGiria,
    prepCliente, perto, pontuaCliente, ordenaClientes, afrouxarCliente, casaCliente };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else (root.MZ = root.MZ || {}).busca = api;
})(globalThis);

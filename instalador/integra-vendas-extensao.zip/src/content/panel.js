(function (root) {
  const MZ = root.MZ;
  const F = MZ.format;
  const FU = MZ.followup;
  const S = MZ.store;
  const W = MZ.wa;
  const IV = MZ.iv;
  const DZ = MZ.dicas;
  const BS = MZ.busca;
  const E = MZ.envios;
  const W_MIN = 340, W_MAX = 760, W_DEF = 640, W_TWO = 560;
  const clampW = (w) => Math.min(W_MAX, Math.max(W_MIN, Math.round(Number(w) || W_DEF)));
  const NAME = 'Integra Vendas';

  const PAGE_CSS = `
    html.mz-open #app { width: calc(100% - var(--mz-w, ${W_DEF}px)) !important; }
    html.mz-resizing, html.mz-resizing * { cursor: ew-resize !important; user-select: none !important; }
    #mz-host { position: fixed; top: 0; right: 0; height: 100vh; z-index: 2147483000; }
    .mz-stripe { position: absolute; left: 0; top: 10px; bottom: 10px; width: 3px; border-radius: 0 3px 3px 0; background: var(--mz-c); pointer-events: none; z-index: 1; }
    .mz-ring { position: absolute; border-radius: 50%; pointer-events: none; z-index: 1; box-shadow: 0 0 0 2px var(--mz-u); }
    .mz-ring.mz-red { --mz-u: #f15c6d; } .mz-ring.mz-amber { --mz-u: #e2a73f; } .mz-ring.mz-green { --mz-u: #25d366; }
    .mz-glyph { position: absolute; width: 17px; height: 17px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font: 700 10px/1 system-ui, sans-serif; color: #fff; background: var(--mz-c); box-shadow: 0 0 0 2px #fff; pointer-events: none; z-index: 2; }
    body.dark .mz-glyph { box-shadow: 0 0 0 2px #111b21; }
    .mz-pill { display: inline-flex; align-items: center; gap: 4px; flex: 0 0 auto; min-width: 0; max-width: 72%; margin-right: 6px; align-self: center; padding: 0 7px 0 6px; border-radius: 9px; font: 500 11.5px/18px system-ui, sans-serif; color: var(--mz-c); background: color-mix(in srgb, var(--mz-c) 13%, transparent); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; vertical-align: middle; cursor: pointer; }
    .mz-pill:hover { background: color-mix(in srgb, var(--mz-c) 22%, transparent); }
    .mz-pill b { font-weight: 600; } .mz-pill i { font-style: normal; opacity: .75; }
    .mz-pill.mz-red { --mz-c: #d63b4d !important; } body.dark .mz-pill.mz-red { --mz-c: #f15c6d !important; }
    .mz-cotar { display: none; position: absolute; top: -9px; right: -6px; z-index: 5; align-items: center; height: 22px; padding: 0 9px; border: 0; border-radius: 11px; background: #00a884; color: #fff; font: 600 11.5px/1 system-ui, sans-serif; cursor: pointer; box-shadow: 0 1px 3px rgba(0,0,0,.3); }
    .mz-cotar::after { content: attr(data-n); }
    .mz-cotar-host:hover > .mz-cotar { display: inline-flex; }
    .mz-need { display: inline-flex; align-items: center; gap: 6px; height: 32px; padding: 0 12px; margin-right: 8px; flex: 0 0 auto; border: 0; border-radius: 16px; font: 500 14px/1 system-ui, sans-serif; cursor: pointer; white-space: nowrap; color: #c62f3c; background: #fdeced; }
    .mz-need b { font-weight: 700; } .mz-need.mz-zero { color: #54656f; background: #f0f2f5; }
    body.dark .mz-need { color: #f15c6d; background: rgba(241,92,109,.14); } body.dark .mz-need.mz-zero { color: #8696a0; background: #202c33; }
    .mz-need.mz-on { color: #fff; background: #c62f3c; } .mz-need.mz-zero.mz-on { color: #fff; background: #54656f; }
    body.dark .mz-need.mz-on { color: #111b21; background: #f15c6d; }
    .mz-fil { position: fixed; z-index: 2147482000; overflow-y: auto; background: #fff; color: #111b21; font: 14px/1.3 system-ui, sans-serif; border-top: 1px solid #e9edef; }
    body.dark .mz-fil { background: #111b21; color: #e9edef; border-color: #222d34; }
    .mz-fil-h { position: sticky; top: 0; display: flex; align-items: center; justify-content: space-between; padding: 8px 16px; font-size: 12.5px; font-weight: 600; color: #667781; background: inherit; }
    .mz-fil-x { border: 0; background: none; color: inherit; font-size: 20px; line-height: 1; cursor: pointer; padding: 0 4px; }
    .mz-fil-r { display: flex; align-items: center; gap: 12px; padding: 10px 16px; cursor: pointer; border-bottom: 1px solid #f0f2f5; }
    body.dark .mz-fil-r { border-color: #1f2c33; }
    .mz-fil-r:hover, .mz-fil-r.on { background: #f5f6f6; } body.dark .mz-fil-r:hover, body.dark .mz-fil-r.on { background: #202c33; }
    .mz-fil-u { width: 10px; height: 10px; border-radius: 50%; flex: 0 0 auto; background: var(--mz-c); box-shadow: 0 0 0 3px #fff, 0 0 0 5px var(--mz-u, transparent); }
    body.dark .mz-fil-u { box-shadow: 0 0 0 3px #111b21, 0 0 0 5px var(--mz-u, transparent); }
    .mz-fil-u.mz-red { --mz-u: #f15c6d; } .mz-fil-u.mz-amber { --mz-u: #e2a73f; } .mz-fil-u.mz-green { --mz-u: #25d366; }
    .mz-fil-m { flex: 1 1 auto; min-width: 0; display: flex; flex-direction: column; }
    .mz-fil-m b { font-weight: 500; font-size: 15px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .mz-fil-m small { font-size: 12px; color: var(--mz-c); }
    .mz-fil-a { flex: 0 0 auto; max-width: 48%; font-size: 12.5px; font-weight: 600; color: var(--mz-c); text-align: right; }
    .mz-fil-a i { font-style: normal; font-weight: 400; opacity: .75; }
    .mz-fil-v { padding: 24px 16px; color: #667781; text-align: center; }
    html.mz-blur #pane-side span[title], html.mz-blur #pane-side img, html.mz-blur #main [role="row"], html.mz-blur #main header { filter: blur(6px); transition: filter .15s; }
    html.mz-blur #pane-side:hover span[title], html.mz-blur #pane-side:hover img, html.mz-blur #main:hover [role="row"], html.mz-blur #main:hover header { filter: none; }
  `;

  const CSS = `
    :host { all: initial; }
    .wrap {
      --bg: #ffffff; --surface: #ffffff; --surface2: #f0f2f5; --side: #f7f8fa; --fg: #111b21; --muted: #667781; --line: #e9edef;
      --accent: #008069; --accent-2: #00a884; --accent-soft: #e7f8f1; --accent-fg: #008069; --on-accent: #ffffff;
      --ok: #008069; --ok-soft: #e7f8f1; --bad: #c62f3c; --bad-soft: #fdeced; --warn: #a15c00; --warn-soft: #fff4e0;
      --info: #027eb5; --info-soft: #e5f4fb; --shadow: none; --scheme: light;
    }
    .wrap.dark {
      --bg: #111b21; --surface: #111b21; --surface2: #202c33; --side: #182229; --fg: #e9edef; --muted: #8696a0; --line: #233138;
      --accent: #00a884; --accent-2: #06cf9c; --accent-soft: rgba(0,168,132,.15); --accent-fg: #06cf9c; --on-accent: #0b141a;
      --ok: #00a884; --ok-soft: rgba(0,168,132,.15); --bad: #f15c6d; --bad-soft: rgba(241,92,109,.14); --warn: #e2a73f; --warn-soft: rgba(226,167,63,.14);
      --info: #53bdeb; --info-soft: rgba(83,189,235,.14); --shadow: none; --scheme: dark;
    }
    * { box-sizing: border-box; font-family: ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; }
    b, strong { font-weight: 600; }
    .grip { position: absolute; left: -3px; top: 0; bottom: 0; width: 7px; cursor: ew-resize; z-index: 5; }
    .grip:hover, .grip.on { background: linear-gradient(90deg, transparent 2px, var(--accent-2) 2px, var(--accent-2) 4px, transparent 4px); }
    .wrap { position: relative; width: var(--mz-w, ${W_DEF}px); height: 100vh; display: flex; flex-direction: column; background: var(--bg); color: var(--fg); border-left: 1px solid var(--line); font-size: 13px; line-height: 1.4; -webkit-font-smoothing: antialiased; }
    .wrap.closed { display: none; }
    svg.i { width: 16px; height: 16px; stroke: currentColor; fill: none; stroke-width: 1.8; stroke-linecap: round; stroke-linejoin: round; flex: 0 0 auto; }

    .tab-open { position: fixed; right: 0; top: 42%; writing-mode: vertical-rl; background: var(--accent, #008069); color: #fff; border: 0; padding: 12px 6px; border-radius: 10px 0 0 10px; cursor: pointer; font: 600 12px system-ui, sans-serif; box-shadow: -2px 2px 10px rgba(0,0,0,.15); }

    .top { display: flex; align-items: center; gap: 4px; padding: 8px 8px 8px 14px; background: var(--surface2); }
    .mark { width: 26px; height: 26px; border-radius: 8px; margin-right: 6px; background: var(--accent); color: var(--on-accent); display: grid; place-items: center; font-weight: 800; font-size: 13px; letter-spacing: -.03em; flex: 0 0 auto; }
    .brand { flex: 1; min-width: 0; }
    .brand b { display: block; font-size: 13px; font-weight: 600; }
    .conn { display: flex; align-items: center; gap: 6px; border: 0; background: none; padding: 0; font-size: 12px; color: var(--muted); cursor: pointer; max-width: 100%; }
    .conn span { white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .dot { width: 7px; height: 7px; border-radius: 50%; background: var(--muted); flex: 0 0 auto; }
    .dot.on { background: var(--ok); box-shadow: 0 0 0 3px var(--ok-soft); }
    .icon-btn { width: 32px; height: 32px; border-radius: 9px; border: 0; background: none; color: var(--muted); display: grid; place-items: center; cursor: pointer; flex: 0 0 auto; }
    .icon-btn:hover { background: var(--surface2); color: var(--fg); }

    .top .icon-btn { position: relative; }
    .top .icon-btn.on { background: var(--accent-soft); color: var(--accent-fg); }
    .top .icon-btn .badge { top: 1px; left: auto; right: 0; }
    nav.tabs { display: flex; gap: 2px; padding: 0 10px 10px; background: var(--surface); border-bottom: 1px solid var(--line); }
    nav.tabs button { flex: 1; position: relative; display: flex; flex-direction: column; align-items: center; gap: 3px; padding: 7px 0 6px; border: 0; border-radius: 10px; background: none; color: var(--muted); font-size: 11px; font-weight: 500; cursor: pointer; }
    nav.tabs button:hover { background: var(--surface2); color: var(--fg); }
    nav.tabs button.on { background: var(--accent-soft); color: var(--accent-fg); font-weight: 600; }
    .badge { position: absolute; top: 2px; left: calc(50% + 6px); min-width: 16px; height: 16px; padding: 0 4px; border-radius: 8px; background: var(--bad); color: #fff; font-size: 10px; font-weight: 600; line-height: 16px; text-align: center; }

    .cols { flex: 1; min-height: 0; display: flex; }
    .body { flex: 1; min-width: 0; overflow-y: auto; padding: 0 0 60px; scrollbar-width: thin; }
    .side { display: none; flex-direction: column; min-height: 0; background: var(--side); border-left: 1px solid var(--line); }
    .wrap.has-side .side { display: flex; width: 292px; flex: 0 0 auto; }
    .wrap.narrow .cols { flex-direction: column; }
    .wrap.narrow.has-side .side { width: auto; max-height: 52%; border-left: 0; border-top: 1px solid var(--line); }
    .side-list { flex: 1; min-height: 0; overflow-y: auto; scrollbar-width: thin; overflow-x: hidden; }
    .side .manual-extra { grid-template-columns: 1fr 1fr; }
    .side .manual-extra > :last-child { grid-column: 1 / -1; }
    .side-h { display: flex; align-items: center; justify-content: space-between; padding: 14px 16px 8px; font-size: 11px; font-weight: 600; letter-spacing: .06em; text-transform: uppercase; color: var(--muted); }
    .side-ft { border-top: 1px solid var(--line); padding: 10px 16px 14px; flex: 0 0 auto; }
    .side-cfg { border-top: 1px solid var(--line); padding: 12px 16px 14px; margin-top: 4px; }
    .ped { margin-top: 14px; display: flex; flex-direction: column; gap: 6px; }
    .ped .two { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }
    .ped select, .ped input, .ped textarea { padding: 5px 8px; font-size: 12px; }
    .ped textarea { min-height: 34px; }
    .side-ft .sub-acts { display: grid; grid-template-columns: 1fr 1fr; gap: 4px; }
    .side-ft .sub-acts .btn { width: 100%; justify-content: center; }
    .side .it { padding: 10px 16px; }
    .side .it:first-child { padding-top: 4px; }
    .it-c { display: flex; gap: 10px; align-items: center; cursor: pointer; }
    .side .it.it-c:first-child { padding-top: 10px; }
    .it-c:hover { background: var(--surface2); }
    .it-n { font-size: 12px; font-weight: 500; line-height: 1.3; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
    .it-c .meta { margin-top: 2px; }
    .it-c .lt { font-size: 13px; align-self: flex-start; }
    .side .it.open { background: var(--surface2); }
    .side .it.open .it-top { cursor: pointer; }
    .side-ft .actions { flex-direction: column; gap: 4px; }
    .cond { margin: 0; }
    .cond-h { display: flex; align-items: center; justify-content: space-between; margin-bottom: 6px; font-size: 11px; font-weight: 600; letter-spacing: .06em; text-transform: uppercase; color: var(--muted); }
    .cond-h .link { text-transform: none; letter-spacing: 0; font-size: 11.5px; }
    .pols { display: grid; grid-template-columns: 1fr 1fr; gap: 4px; }
    .pol { height: 28px; border-radius: 8px; border: 1px solid var(--line); background: none; color: var(--fg); font: inherit; font-size: 12px; font-weight: 500; cursor: pointer; }
    .pol:hover:not(:disabled) { background: var(--surface2); }
    .pol.on { background: var(--accent-soft); border-color: var(--accent); color: var(--accent-fg); font-weight: 600; }
    .pol:disabled { opacity: .45; cursor: not-allowed; }
    .cond-pers { display: flex; align-items: center; gap: 8px; margin-top: 6px; font-size: 12px; color: var(--muted); }
    .pct { position: relative; width: 64px; flex: 0 0 auto; }
    .pct input { padding: 4px 20px 4px 8px; text-align: right; font-size: 12px; }
    .pct > span { position: absolute; right: 8px; top: 50%; transform: translateY(-50%); font-size: 11px; color: var(--muted); pointer-events: none; }
    .cond-ult { margin-top: 6px; font-size: 11.5px; color: var(--muted); }
    .ult-c { display: flex; gap: 6px; align-items: flex-start; margin-top: 8px; font-size: 12px; color: var(--muted); line-height: 1.4; }
    .ult-c b { color: var(--fg); font-weight: 600; }
    .ult-c svg { width: 13px; height: 13px; margin-top: 2px; flex: 0 0 auto; }
    .meta .ult { color: var(--accent-fg); }
    .it-desc { display: flex; align-items: center; gap: 8px; margin-top: 6px; font-size: 12px; color: var(--muted); }
    .side-ft .actions .btn { width: 100%; justify-content: center; }
    .side .stepper button { width: 24px; height: 28px; }
    .side .stepper input { width: 34px; padding: 5px 2px; }
    .side .money { width: 86px; }
    .side .card { padding: 12px 16px; }
    .side .totals { background: none; padding: 0; margin: 0; }
    .side .tot-big b { font-size: 20px; }
    .side .grid2 { grid-template-columns: 1fr; }
    .side .card .actions { flex-direction: column; }
    .chips { -webkit-mask-image: linear-gradient(90deg, #000 calc(100% - 28px), transparent); mask-image: linear-gradient(90deg, #000 calc(100% - 28px), transparent); padding-right: 24px; }
    .side-empty { padding: 26px 18px; text-align: center; color: var(--muted); font-size: 13px; }
    .hero { display: flex; align-items: center; gap: 10px; padding: 12px 16px 0; }
    .hero .nm { font-size: 14px; font-weight: 600; }
    .card { background: none; border: 0; border-bottom: 1px solid var(--line); border-radius: 0; padding: 14px 16px; margin: 0; }
    .card-h { display: flex; align-items: center; gap: 8px; margin-bottom: 10px; }
    .card-h .ttl { flex: 1; min-width: 0; white-space: nowrap; display: flex; align-items: center; gap: 7px; font-weight: 600; font-size: 11px; letter-spacing: .06em; text-transform: uppercase; color: var(--muted); }
    .card-h .ttl svg { color: var(--muted); }
    .card-h.click { cursor: pointer; margin-bottom: 0; user-select: none; }
    .card.open > .card-h.click { margin-bottom: 12px; }
    .chev { color: var(--muted); transition: transform .15s; }
    .card.open .chev { transform: rotate(180deg); }
    .sec-t { font-size: 11px; font-weight: 600; letter-spacing: .06em; text-transform: uppercase; color: var(--muted); margin: 16px 4px 8px; }
    .sec-t:first-child { margin-top: 2px; }

    .hero-top { display: flex; gap: 11px; align-items: center; }
    .avatar { width: 42px; height: 42px; border-radius: 50%; display: grid; place-items: center; color: #fff; font-weight: 600; font-size: 14px; flex: 0 0 auto; }
    .avatar.sm { width: 32px; height: 32px; font-size: 12px; }
    .nm { font-size: 14px; font-weight: 600; letter-spacing: -.01em; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .sub { font-size: 12px; color: var(--muted); }
    .hero-sel { display: flex; gap: 8px; margin-top: 11px; }
    select.pill { border-radius: 20px; padding: 6px 10px; font-weight: 600; font-size: 12px; }
    select.stage { width: auto; flex: 0 0 auto; max-width: 180px; }
    .st-orcamento, .st-pos_venda { background: var(--info-soft); color: var(--info); border-color: transparent; }
    .st-aguardando_pix { background: var(--warn-soft); color: var(--warn); border-color: transparent; }
    .st-pago, .st-enviado { background: var(--ok-soft); color: var(--ok); border-color: transparent; }
    .st-separando { background: var(--accent-soft); color: var(--accent-fg); border-color: transparent; }
    .st-perdido { background: var(--bad-soft); color: var(--bad); border-color: transparent; }
    .facts { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 10px; }
    .fact { display: inline-flex; gap: 5px; align-items: center; font-size: 12px; color: var(--muted); background: var(--surface2); padding: 3px 9px; border-radius: 20px; }
    .fact svg { width: 13px; height: 13px; }

    .seg { display: flex; gap: 20px; padding: 0 16px; margin-top: 8px; border-bottom: 1px solid var(--line); }
    .seg button { position: relative; display: flex; align-items: center; gap: 5px; border: 0; background: none; padding: 9px 0 10px; font-size: 13px; white-space: nowrap; font-weight: 600; color: var(--muted); cursor: pointer; }
    .seg button:hover { color: var(--fg); }
    .seg button.on { color: var(--fg); }
    .seg button.on::after { content: ''; position: absolute; left: 0; right: 0; bottom: -1px; height: 2px; border-radius: 2px; background: var(--accent); }
    .cnt { font-size: 10px; font-weight: 600; padding: 0 6px; border-radius: 8px; background: var(--line); color: var(--fg); line-height: 16px; }
    .cnt.hot { background: var(--bad); color: #fff; }
    .cnt.acc { background: var(--accent); color: var(--on-accent); }

    input, select, textarea { width: 100%; padding: 7px 10px; border: 1px solid var(--line); border-radius: 8px; font-size: 13px; background: var(--surface); color: var(--fg); color-scheme: var(--scheme); outline: none; transition: border-color .12s, box-shadow .12s; }
    input:focus, select:focus, textarea:focus { border-color: var(--accent-2); box-shadow: 0 0 0 3px var(--accent-soft); }
    input::placeholder, textarea::placeholder { color: var(--muted); opacity: .8; }
    textarea { resize: vertical; min-height: 64px; line-height: 1.45; }
    label.fld { display: flex; flex-direction: column; gap: 4px; font-size: 11px; font-weight: 500; color: var(--muted); }
    .search { position: relative; flex: 1; min-width: 0; }
    .search > svg { position: absolute; left: 10px; top: 50%; transform: translateY(-50%); color: var(--muted); pointer-events: none; }
    .search input { padding-left: 32px; padding-right: 56px; }
    .search .clr { position: absolute; right: 5px; top: 50%; transform: translateY(-50%); width: 24px; height: 24px; border: 0; border-radius: 7px; background: none; color: var(--muted); display: grid; place-items: center; cursor: pointer; }
    .search .clr:hover { background: var(--surface2); color: var(--fg); }
    .search .clr svg { width: 14px; height: 14px; }
    .search > .spin { position: absolute; right: 34px; top: 50%; margin-top: -6.5px; }
    .res.kb { box-shadow: inset 3px 0 0 var(--accent-2); background: var(--surface2); }
    .res-h .cnt { white-space: nowrap; }
    .res-h .keys { flex: 1; min-width: 0; text-align: right; font-weight: 500; opacity: .8; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-left: 8px; }
    .picked { display: flex; align-items: center; gap: 6px; margin-top: 8px; padding: 6px 6px 6px 10px; border-radius: 10px; background: var(--accent-soft); color: var(--accent-fg); font-size: 12px; font-weight: 600; }

    .btn { display: inline-flex; align-items: center; justify-content: center; gap: 6px; padding: 8px 12px; border-radius: 8px; border: 1px solid var(--line); background: var(--surface); color: var(--fg); font-size: 13px; font-weight: 600; cursor: pointer; white-space: nowrap; transition: background .12s, filter .12s; }
    .btn:hover { background: var(--surface2); }
    .btn:active { transform: translateY(1px); }
    .btn.pri { background: var(--accent); border-color: var(--accent); color: var(--on-accent); }
    .btn.pri:hover { background: var(--accent); filter: brightness(1.12); }
    .btn.ok { background: var(--ok); border-color: var(--ok); color: var(--on-accent); }
    .btn.ok:hover { background: var(--ok); filter: brightness(1.08); }
    .btn.danger { color: var(--bad); }
    .btn.danger:hover { background: var(--bad-soft); }
    .btn.danger.fill { background: var(--bad); border-color: var(--bad); color: #fff; }
    .btn.ghost { border-color: transparent; background: none; color: var(--muted); }
    .btn.ghost:hover { background: var(--surface2); color: var(--fg); }
    .btn.sm { padding: 5px 9px; font-size: 12px; border-radius: 8px; }
    .btn.sm svg { width: 14px; height: 14px; }
    .btn.block { width: 100%; }
    .btn.dashed { border-style: dashed; background: none; color: var(--muted); width: 100%; }
    .btn.dashed:hover { color: var(--accent-fg); border-color: var(--accent-2); background: var(--accent-soft); }
    .btn[disabled] { opacity: .5; pointer-events: none; }
    .link { border: 0; background: none; padding: 4px 2px; color: var(--accent-fg); font-weight: 600; font-size: 12px; cursor: pointer; display: inline-flex; gap: 5px; align-items: center; }
    .link svg { width: 14px; height: 14px; }
    .link:hover { text-decoration: underline; }
    .link.muted { color: var(--muted); }

    .row { display: flex; gap: 8px; align-items: center; }
    .row > .grow, .grow { flex: 1; min-width: 0; }
    .grid2 { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
    .stack > * + * { margin-top: 8px; }
    .mt { margin-top: 10px; }
    .mb { margin-bottom: 10px; }
    .muted { color: var(--muted); font-size: 12px; }
    .tiny { font-size: 11px; color: var(--muted); }
    .ellipsis { white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .t1 { font-weight: 600; }

    .tag { display: inline-flex; align-items: center; gap: 4px; font-size: 11px; font-weight: 600; padding: 2px 8px; border-radius: 20px; background: var(--surface2); color: var(--muted); white-space: nowrap; flex: 0 0 auto; }
    .tag.ok { background: var(--ok-soft); color: var(--ok); }
    .tag.bad { background: var(--bad-soft); color: var(--bad); }
    .tag.warn { background: var(--warn-soft); color: var(--warn); }
    .tag.info { background: var(--info-soft); color: var(--info); }
    .tag.acc { background: var(--accent-soft); color: var(--accent-fg); }
    .ibox { width: 34px; height: 34px; border-radius: 10px; display: grid; place-items: center; background: var(--surface2); color: var(--muted); flex: 0 0 auto; }
    .ibox.ok { background: var(--ok-soft); color: var(--ok); }
    .ibox.acc { background: var(--accent-soft); color: var(--accent-fg); }

    .list > .li { display: flex; gap: 10px; align-items: center; padding: 9px 0; border-top: 1px solid var(--line); }
    .list > .li:first-child { border-top: 0; padding-top: 0; }
    .list > .li:last-child { padding-bottom: 0; }
    .li .main { flex: 1; min-width: 0; }
    .li.click { cursor: pointer; }
    .li.click:hover .t1 { color: var(--accent-fg); }
    .li .chev-r { color: var(--muted); }

    .it { padding: 11px 0; border-top: 1px solid var(--line); }
    .it:first-child { border-top: 0; padding-top: 2px; }
    .it-top { display: flex; gap: 8px; align-items: flex-start; }
    .it-d { flex: 1; min-width: 0; font-weight: 600; line-height: 1.3; }
    .meta { font-size: 11px; color: var(--muted); margin-top: 3px; display: flex; flex-wrap: wrap; gap: 4px 8px; align-items: center; }
    .it-bottom { display: flex; align-items: center; gap: 8px; margin-top: 9px; }
    .stepper { display: flex; align-items: center; border: 1px solid var(--line); border-radius: 9px; overflow: hidden; flex: 0 0 auto; }
    .stepper button { width: 28px; height: 30px; border: 0; background: var(--surface2); color: var(--fg); cursor: pointer; display: grid; place-items: center; }
    .stepper button:hover { color: var(--accent-fg); }
    .stepper button svg { width: 14px; height: 14px; }
    .stepper input { width: 44px; border: 0; border-radius: 0; text-align: center; padding: 6px 2px; box-shadow: none; }
    .money { position: relative; width: 104px; flex: 0 0 auto; }
    .money > span { position: absolute; left: 9px; top: 50%; transform: translateY(-50%); font-size: 11px; color: var(--muted); pointer-events: none; }
    .money input { padding-left: 29px; text-align: right; }
    .lt { margin-left: auto; font-weight: 600; font-variant-numeric: tabular-nums; }
    .x-btn { border: 0; background: none; color: var(--muted); cursor: pointer; padding: 3px; border-radius: 7px; display: grid; place-items: center; flex: 0 0 auto; }
    .x-btn:hover { color: var(--bad); background: var(--bad-soft); }
    .x-btn svg { width: 15px; height: 15px; }
    .manual-extra { display: grid; grid-template-columns: 1fr 96px 1fr; gap: 6px; margin-top: 6px; }
    .manual-extra input, .manual-extra select { padding: 5px 8px; font-size: 12px; }

    .totals { background: var(--surface2); border-radius: 12px; padding: 10px 12px; margin-top: 12px; }
    .tot-row { display: flex; justify-content: space-between; align-items: center; font-size: 12px; color: var(--muted); padding: 2px 0; }
    .tot-row .money { width: 96px; }
    .tot-row .money input { padding-top: 4px; padding-bottom: 4px; font-size: 12px; background: var(--surface); }
    .tot-big { display: flex; justify-content: space-between; align-items: baseline; margin-top: 6px; padding-top: 8px; border-top: 1px dashed var(--line); font-weight: 600; }
    .tot-big b { font-size: 20px; letter-spacing: -.02em; font-variant-numeric: tabular-nums; }
    .actions { display: flex; gap: 8px; margin-top: 12px; }
    .actions > .btn { flex: 1; }
    .acts { display: flex; gap: 4px; flex-wrap: wrap; margin-top: 8px; }

    .results { border: 1px solid var(--line); border-radius: 8px; margin: 8px 0 4px; max-height: 340px; overflow-y: auto; background: var(--surface); }
    .res-h { display: flex; justify-content: space-between; align-items: center; padding: 6px 6px 6px 11px; font-size: 11px; font-weight: 600; color: var(--muted); border-bottom: 1px solid var(--line); position: sticky; top: 0; background: var(--surface); z-index: 1; }
    .res { display: flex; flex-wrap: wrap; gap: 4px 10px; align-items: flex-start; padding: 9px 11px; border-bottom: 1px solid var(--line); }
    .res .t1 { font-weight: 500; overflow-wrap: anywhere; }
    .res-b { display: flex; align-items: center; gap: 6px; margin-top: 6px; }
    .thumb { width: 44px; height: 44px; border-radius: 8px; background: var(--surface2); color: var(--muted); display: grid; place-items: center; flex: 0 0 auto; overflow: hidden; }
    .thumb svg { width: 18px; height: 18px; opacity: .55; }
    .thumb img { width: 100%; height: 100%; object-fit: contain; background: #fff; display: block; }
    .thumb.sm { width: 36px; height: 36px; border-radius: 6px; }
    .thumb.lg { width: 72px; height: 72px; border-radius: 10px; }
    .thumb.lg svg { width: 28px; height: 28px; }
    .tw { position: relative; flex: 0 0 auto; }
    .thumb.drag { cursor: grab; position: relative; }
    .thumb.drag:active { cursor: grabbing; }
    .thumb.lg.drag::after { content: "arraste p/ conversa"; position: absolute; left: 0; right: 0; bottom: 0; padding: 3px 0; font-size: 10px; font-weight: 600; text-align: center; color: #fff; background: rgba(11, 20, 26, .72); opacity: 0; transition: opacity .15s; }
    .thumb.lg.drag:hover::after { opacity: 1; }
    .res-r { display: flex; flex-direction: column; align-items: flex-end; gap: 6px; flex: 0 0 auto; }
    .res-btns { display: flex; gap: 4px; }
    .res-btns .add { width: 28px; height: 28px; }
    .tw .pick { position: absolute; top: -5px; left: -5px; box-shadow: 0 0 0 2px var(--surface); }
    .results:not(.picking) .res:not(:hover):not(.kb) .pick:not(.on) { opacity: 0; }
    .det { margin: 8px 0 4px; padding: 12px; border-radius: 10px; background: var(--surface2); }
    .det-top { display: flex; gap: 12px; }
    .galeria { display: flex; flex-wrap: wrap; align-items: center; gap: 6px; margin-top: 8px; }
    .galeria .thumb { cursor: pointer; box-shadow: 0 0 0 1px var(--line); }
    .galeria .thumb.on { box-shadow: 0 0 0 2px var(--accent); }
    .galeria-n { font-size: 11.5px; color: var(--muted); }
    .precos { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; margin-top: 10px; }
    .pb { border: 1px solid var(--line); border-radius: 8px; padding: 6px 8px; background: var(--surface); min-width: 0; }
    .pb.on { border-color: var(--accent); box-shadow: 0 0 0 1px var(--accent) inset; }
    .pb-l { font-size: 10.5px; font-weight: 600; letter-spacing: .04em; text-transform: uppercase; color: var(--muted); }
    .pb.on .pb-l { color: var(--accent-fg); }
    .pb-v { font-size: 16px; font-weight: 600; font-variant-numeric: tabular-nums; letter-spacing: -.02em; margin-top: 1px; }
    .pb-s { font-size: 11px; color: var(--muted); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .price2 { text-align: right; font-variant-numeric: tabular-nums; line-height: 1.25; }
    .price2 small { font-size: 10px; font-weight: 500; color: var(--muted); margin-right: 4px; text-transform: uppercase; letter-spacing: .03em; }
    .price2 .pz { font-size: 13px; font-weight: 600; white-space: nowrap; }
    .price2 .pv { font-size: 12px; color: var(--muted); white-space: nowrap; }
    .price2 .on { color: var(--accent-fg); }
    .price2 .pv.on { font-weight: 600; font-size: 13px; }
    .price2 .pz:not(.on) { font-weight: 500; }
    .det .big { margin-top: 4px; font-size: 18px; font-weight: 600; font-variant-numeric: tabular-nums; letter-spacing: -.02em; }
    .det .t1 { font-weight: 600; line-height: 1.3; }
    .det .kv { font-size: 12px; color: var(--muted); line-height: 1.55; margin-top: 3px; }
    .det .kv b { color: var(--fg); }
    .li .main.click { cursor: pointer; }
    .list > .li.sel { background: var(--accent-soft); margin: 0 -8px; padding-left: 8px; padding-right: 8px; border-radius: 8px; }
    .li.sel > .chev-r { color: var(--accent-fg); }
    .side .it.ro { cursor: default; }
    .side .it.ro:hover { background: none; }
    .side-cfg.det .kv { margin-top: 2px; }
    .det .row { margin-top: 10px; }
    .det .row .btn { flex: 1; justify-content: center; }
    .kbd { font-size: 10px; font-weight: 600; border: 1px solid currentColor; border-bottom-width: 2px; border-radius: 4px; padding: 0 4px; opacity: .7; line-height: 14px; }
    .res-b .meta { margin-top: 0; }
    .res-b .meta span { white-space: nowrap; }
    .res-b .price { margin-right: 4px; }
    .res-b .add { width: 28px; height: 28px; }
    .res:last-child { border-bottom: 0; }
    .res:hover { background: var(--surface2); }
    .res .main { flex: 1; min-width: 0; }
    .res .price { font-weight: 600; font-size: 13px; font-variant-numeric: tabular-nums; }
    .add.snd { background: var(--surface2); color: var(--muted); }
    .hint { border-radius: 12px; padding: 10px 11px; margin-top: 10px; font-size: 13px; }
    .hint.warn { background: var(--warn-soft); }
    .hint.warn > .row > svg { color: var(--warn); }
    .hint.ok { background: var(--ok-soft); }
    .hint.ok > .row > svg { color: var(--ok); }
    .hint .row > svg { margin-top: 1px; }
    .mt { margin-top: 8px; }
    .add.snd.on { background: var(--ok-soft); color: var(--ok); }
    .pick { width: 18px; height: 18px; flex: 0 0 auto; border-radius: 5px; border: 1.5px solid var(--line); background: var(--surface); color: #fff; display: grid; place-items: center; cursor: pointer; padding: 0; }
    .pick.on { background: var(--accent); border-color: var(--accent); }
    .pick svg { width: 12px; height: 12px; }
    .res.on { background: var(--accent-soft); }
    .add.snd:hover { color: var(--accent-fg); background: var(--accent-soft); }
    .mais { margin: 10px 0 4px; }
    .mais-h { display: flex; align-items: center; justify-content: space-between; margin-bottom: 4px; font-size: 11px; font-weight: 600; letter-spacing: .06em; text-transform: uppercase; color: var(--muted); }
    .mais-h .link { text-transform: none; letter-spacing: 0; font-size: 11.5px; font-weight: 500; }
    .mais-it { display: flex; align-items: center; gap: 8px; width: 100%; border: 0; background: none; color: var(--fg); text-align: left; font: inherit; padding: 6px 8px; margin: 0 -8px; width: calc(100% + 16px); border-radius: 8px; cursor: pointer; }
    .mais-it:hover { background: var(--surface2); }
    .mais-q { flex: 0 0 auto; min-width: 34px; text-align: center; font-size: 11px; font-weight: 600; color: var(--accent-fg); background: var(--accent-soft); border-radius: 10px; padding: 2px 6px; font-variant-numeric: tabular-nums; }
    .mais-n { flex: 1; min-width: 0; font-size: 12px; line-height: 1.3; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
    .mais-go, .mais-ok { flex: 0 0 auto; color: var(--muted); display: flex; }
    .mais-go svg, .mais-ok svg { width: 14px; height: 14px; }
    .mais-it:not(:hover) .mais-go { opacity: .5; }
    .mais-ok { color: var(--ok); }
    .chips.tipos { margin: 6px 0 4px; }
    .chips.tipos .chip { padding: 4px 9px; }
    .chips.tipos .chip.on { background: var(--accent-soft); color: var(--accent-fg); box-shadow: 0 0 0 1px var(--accent) inset; }
    .chip-n { margin-left: 5px; font-size: 10.5px; opacity: .65; font-variant-numeric: tabular-nums; }
    .moto-cit { display: flex; align-items: center; gap: 8px; margin-bottom: 10px; padding: 8px 10px; border-radius: 10px; background: var(--accent-soft); color: var(--fg); font-size: 12.5px; }
    .fechar { margin-bottom: 10px; padding: 8px 10px; border-radius: 10px; border: 1px solid var(--accent); background: var(--accent-soft); font-size: 12.5px; }
    .fechar > .row svg { width: 16px; height: 16px; color: var(--accent); flex: 0 0 auto; }
    .fechar ul { margin: 6px 0 6px 22px; padding: 0; }
    .fechar li { margin: 2px 0; }
    .btn.pulse { box-shadow: 0 0 0 2px var(--surface), 0 0 0 4px var(--accent); animation: mzpulse 1.4s ease-in-out 4; }
    @keyframes mzpulse { 50% { box-shadow: 0 0 0 2px var(--surface), 0 0 0 7px transparent; } }
    .perda { margin: 0 12px 8px; padding: 8px 10px; border-radius: 10px; background: var(--bad-soft); font-size: 12.5px; display: grid; gap: 6px; }
    .perda .lbl { font-weight: 600; color: var(--bad); }
    .perda input { width: 100%; box-sizing: border-box; }
    .perda .chips { flex-wrap: wrap; margin: 0; overflow: visible; }
    .moto-cit svg { width: 16px; height: 16px; color: var(--accent); flex: 0 0 auto; }
    .lt-l { padding: 8px 0; border-bottom: 1px solid var(--line); }
    .lt-l:last-of-type { border-bottom: 0; }
    .lt-top { display: flex; align-items: center; gap: 6px; }
    .lt-top input { font: inherit; font-size: 13px; color: var(--fg); background: var(--surface2); border: 1px solid transparent; border-radius: 6px; padding: 4px 7px; min-width: 0; }
    .lt-top input:focus { outline: none; border-color: var(--accent); }
    .lt-qtd { width: 44px; text-align: center; flex: 0 0 auto; }
    .lt-termo { flex: 1 1 auto; }
    .lt-orig { margin: 3px 0 0 50px; }
    .lt-opcoes { display: flex; flex-direction: column; gap: 2px; margin: 5px 0 0 50px; }
    .lt-op { display: flex; align-items: center; gap: 8px; width: 100%; text-align: left; font: inherit; font-size: 12px; color: var(--muted); background: none; border: 1px solid transparent; border-radius: 6px; padding: 4px 7px; cursor: pointer; }
    .lt-op:hover { background: var(--surface2); }
    .lt-op .thumb { width: 34px; height: 34px; border-radius: 6px; }
    .lt-op .thumb svg { width: 14px; height: 14px; }
    .lt-op.on { color: var(--fg); background: var(--accent-soft); border-color: var(--accent); }
    .lt-nome { flex: 1 1 auto; min-width: 0; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; line-height: 1.3; }
    .lt-op b { font-weight: 600; color: var(--fg); flex: 0 0 auto; }
    .lt-l.nada .lt-termo, .lt-l.erro .lt-termo { border-color: var(--bad); }
    .res-mais { display: block; width: 100%; border: 0; background: none; color: var(--accent-fg); font: inherit; font-size: 12px; font-weight: 600; padding: 8px; cursor: pointer; }
    .res-mais:hover { background: var(--surface2); }
    .vit-tabs { display: flex; gap: 4px; flex: 0 0 auto; }
    .vitrine .mais-h > span:first-child { white-space: nowrap; }
    .vit-t { border: 0; font-family: inherit; font-size: 11.5px; font-weight: 500; line-height: 1; text-transform: none; letter-spacing: 0; padding: 4px 8px; border-radius: 999px; background: var(--surface2); color: var(--muted); cursor: pointer; white-space: nowrap; }
    .vit-t.on { background: var(--accent-soft); color: var(--accent-fg); }
    .vit-it { cursor: pointer; }
    .vit-m { display: block; font-size: 11px; color: var(--muted); font-variant-numeric: tabular-nums; }
    .vit-it .mais-n { -webkit-line-clamp: 3; }
    .chips .lead { align-self: center; font-size: 12px; color: var(--muted); white-space: nowrap; }
    .chip svg { width: 12px; height: 12px; vertical-align: -2px; margin-right: 3px; }
    .big-n { font-size: 20px; font-weight: 600; letter-spacing: -.03em; line-height: 1.1; }
    .bars { display: flex; align-items: flex-end; gap: 6px; height: 64px; margin-top: 12px; }
    .bars > div { flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: flex-end; gap: 3px; height: 100%; }
    .bars i { display: block; width: 100%; min-height: 2px; border-radius: 4px 4px 2px 2px; background: var(--accent-soft); }
    .bars .cur i { background: var(--accent); }
    .bars span { font-size: 10px; color: var(--muted); }
    .add { width: 30px; height: 30px; border-radius: 9px; border: 0; background: var(--accent-soft); color: var(--accent-fg); cursor: pointer; display: grid; place-items: center; flex: 0 0 auto; }
    .add:hover { background: var(--accent); color: #fff; }

    .banner { display: flex; gap: 10px; align-items: center; padding: 11px 12px; border-radius: 8px; background: var(--accent-soft); color: var(--accent-fg); margin: 12px 16px; font-size: 12px; font-weight: 500; }
    .err { display: flex; gap: 7px; align-items: flex-start; padding: 9px 10px; border-radius: 10px; background: var(--bad-soft); color: var(--bad); font-size: 12px; white-space: pre-wrap; margin-top: 10px; }
    .err svg { margin-top: 1px; width: 14px; height: 14px; }
    .busy { display: flex; align-items: center; gap: 8px; font-size: 12px; color: var(--muted); margin-top: 10px; }
    .spin { width: 13px; height: 13px; border: 2px solid var(--line); border-top-color: var(--accent-2); border-radius: 50%; animation: sp .7s linear infinite; flex: 0 0 auto; }
    @keyframes sp { to { transform: rotate(360deg); } }
    .confirm { margin-top: 10px; padding: 11px 12px; border-radius: 12px; background: var(--warn-soft); font-size: 13px; }
    .confirm .row { margin-top: 9px; justify-content: flex-end; }

    .empty { text-align: center; padding: 22px 14px 18px; color: var(--muted); font-size: 12px; }
    .empty .ic { width: 46px; height: 46px; border-radius: 50%; background: var(--surface2); color: var(--muted); display: grid; place-items: center; margin: 0 auto 10px; }
    .empty .ic svg { width: 20px; height: 20px; }
    .empty b { display: block; color: var(--fg); font-size: 13px; margin-bottom: 4px; }
    .empty .btn { margin-top: 12px; }
    .empty.big { padding-top: 60px; }

    .fu { position: relative; padding: 0 0 14px 20px; }
    .fu::before { content: ''; position: absolute; left: 5px; top: 14px; bottom: 0; width: 2px; background: var(--line); }
    .fu:last-child { padding-bottom: 0; }
    .fu:last-child::before { display: none; }
    .fu .node { position: absolute; left: 0; top: 3px; width: 12px; height: 12px; border-radius: 50%; background: var(--surface); border: 2px solid var(--line); }
    .fu.next .node { border-color: var(--accent-2); }
    .fu.late .node { border-color: var(--bad); background: var(--bad); }
    .quote { background: var(--surface2); border-radius: 10px; padding: 8px 10px; font-size: 12px; margin: 7px 0 8px; white-space: pre-wrap; line-height: 1.45; }
    .clamp { display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden; }

    .kpis { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; padding: 12px 16px 4px; }
    .kpi { background: var(--surface2); border: 0; border-radius: 8px; padding: 11px 12px; box-shadow: var(--shadow); }
    .kpi .n { font-size: 20px; font-weight: 600; letter-spacing: -.03em; line-height: 1.1; }
    .kpi .l { font-size: 12px; color: var(--muted); display: flex; gap: 5px; align-items: center; margin-top: 3px; }
    .kpi .l svg { width: 13px; height: 13px; }
    .kpi.hot .n { color: var(--bad); }
    .kpi.zero .n { color: var(--muted); }
    .fn { display: flex; align-items: center; gap: 8px; font-size: 12px; padding: 4px 0; }
    .fn .lbl { width: 118px; color: var(--muted); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .fn .bar { flex: 1; height: 8px; border-radius: 4px; background: var(--surface2); overflow: hidden; }
    .fn .bar i { display: block; height: 100%; border-radius: 4px; background: var(--accent-2); }
    .fn .v { min-width: 20px; text-align: right; font-weight: 600; }

    .chips { display: flex; gap: 6px; overflow-x: auto; padding-bottom: 2px; margin: 10px 0; scrollbar-width: none; }
    .chip { border: 0; background: var(--surface2); color: var(--fg); border-radius: 20px; padding: 5px 12px; font-size: 12px; font-weight: 500; cursor: pointer; white-space: nowrap; }
    .chip:hover { color: var(--fg); }
    .chip.on { background: var(--accent); color: var(--on-accent); }
    .chips.quebra { flex-wrap: wrap; overflow: visible; -webkit-mask-image: none; mask-image: none; padding-right: 0; gap: 4px 6px; }
    .chips.fit { -webkit-mask-image: none; mask-image: none; padding-right: 0; gap: 4px; margin: 4px 0 6px; }
    .chips.fit .chip { padding: 4px 9px; }

    .maint { display: grid; grid-template-columns: 1fr 128px 58px; gap: 6px; align-items: center; padding: 5px 0; font-size: 12px; }
    .maint input { padding: 4px 6px; font-size: 12px; }
    .maint .due { text-align: right; font-size: 11px; color: var(--muted); }
    .maint .due.soon { color: var(--bad); font-weight: 600; }
    .sub-h { display: flex; align-items: center; justify-content: space-between; font-size: 11px; font-weight: 600; letter-spacing: .05em; text-transform: uppercase; color: var(--muted); margin: 12px 0 4px; }

    .switch { display: flex; gap: 10px; align-items: flex-start; cursor: pointer; }
    .switch input { display: none; }
    .switch .knob { width: 34px; height: 20px; border-radius: 10px; background: var(--line); position: relative; flex: 0 0 auto; transition: background .15s; margin-top: 1px; }
    .switch .knob::after { content: ''; position: absolute; top: 2px; left: 2px; width: 16px; height: 16px; border-radius: 50%; background: #fff; transition: left .15s; box-shadow: 0 1px 2px rgba(0,0,0,.2); }
    .switch input:checked + .knob { background: var(--accent); }
    .switch input:checked + .knob::after { left: 16px; }

    .health { font-family: ui-monospace, SFMono-Regular, monospace; font-size: 11px; padding: 2px 0; }
    .ok-c { color: var(--ok); } .warn-c { color: var(--warn); } .bad-c { color: var(--bad); }

    .toast { position: absolute; bottom: 18px; left: 50%; transform: translate(-50%, 8px); width: max-content; max-width: 330px; background: #15171c; color: #fff; padding: 10px 14px; border-radius: 12px; font-size: 12px; opacity: 0; transition: opacity .2s, transform .2s; pointer-events: none; box-shadow: 0 10px 30px rgba(0,0,0,.22); }
    .toast.show { opacity: 1; transform: translate(-50%, 0); }
  `;

  const ICONS = {
    chat: ['M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z'],
    calendar: ['r:3,4,18,18,2', 'M16 2v4', 'M8 2v4', 'M3 10h18'],
    zap: ['M13 2 3 14h9l-1 8 10-12h-9l1-8z'],
    sliders: ['M4 21v-7', 'M4 10V3', 'M12 21v-9', 'M12 8V3', 'M20 21v-5', 'M20 12V3', 'M1 14h6', 'M9 8h6', 'M17 16h6'],
    search: ['c:11,11,7', 'm21 21-4.3-4.3'],
    plus: ['M5 12h14', 'M12 5v14'],
    minus: ['M5 12h14'],
    x: ['M18 6 6 18', 'm6 6 12 12'],
    send: ['m22 2-7 20-4-9-9-4Z', 'M22 2 11 13'],
    check: ['M20 6 9 17l-5-5'],
    clock: ['c:12,12,10', 'M12 6v6l4 2'],
    file: ['M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z', 'M14 2v6h6'],
    download: ['M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4', 'm7 10 5 5 5-5', 'M12 15V3'],
    down: ['m6 9 6 6 6-6'],
    right: ['m9 18 6-6-6-6'],
    close: ['r:3,3,18,18,2', 'M15 3v18', 'm8 9 3 3-3 3'],
    building: ['M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z', 'M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2', 'M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2', 'M10 6h4', 'M10 10h4', 'M10 14h4', 'M10 18h4'],
    bell: ['M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9', 'M10.3 21a1.94 1.94 0 0 0 3.4 0'],
    box: ['M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z', 'M3.3 7 12 12l8.7-5', 'M12 22V12'],
    wrench: ['M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z'],
    trash: ['M3 6h18', 'M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6', 'M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2'],
    ext: ['M15 3h6v6', 'M10 14 21 3', 'M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6'],
    bike: ['c:5.5,17.5,3.5', 'c:18.5,17.5,3.5', 'M15 6h2l3 11.5', 'M5.5 17.5 9 10h6l-3 7.5', 'M9 10 7.5 6H5'],
    note: ['M12 20h9', 'M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z'],
    cart: ['c:8,21,1', 'c:19,21,1', 'M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12'],
    logout: ['M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4', 'm16 17 5-5-5-5', 'M21 12H9'],
    phone: ['M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z'],
    alert: ['c:12,12,10', 'M12 8v4', 'M12 16h.01'],
    link: ['M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71', 'M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71'],
    user: ['M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2', 'c:12,7,4'],
    funnel: ['M22 3H2l8 9.46V19l4 2v-8.54L22 3z'],
    shield: ['M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z'],
    store: ['M3 9h18l-2-6H5z', 'M5 9v12h14V9', 'M9 21v-6h6v6'],
    activity: ['M22 12h-4l-3 9L9 3l-3 9H2'],
    pause: ['c:12,12,10', 'M10 15V9', 'M14 15V9'],
  };
  const SVGNS = 'http://www.w3.org/2000/svg';

  function icon(name) {
    const svg = document.createElementNS(SVGNS, 'svg');
    svg.setAttribute('viewBox', '0 0 24 24');
    svg.setAttribute('class', 'i');
    (ICONS[name] || []).forEach((s) => {
      let el;
      if (s.startsWith('c:')) {
        const [cx, cy, r] = s.slice(2).split(',');
        el = document.createElementNS(SVGNS, 'circle');
        el.setAttribute('cx', cx); el.setAttribute('cy', cy); el.setAttribute('r', r);
      } else if (s.startsWith('r:')) {
        const [x, y, w, hh, rx] = s.slice(2).split(',');
        el = document.createElementNS(SVGNS, 'rect');
        el.setAttribute('x', x); el.setAttribute('y', y); el.setAttribute('width', w); el.setAttribute('height', hh); el.setAttribute('rx', rx);
      } else {
        el = document.createElementNS(SVGNS, 'path');
        el.setAttribute('d', s);
      }
      svg.append(el);
    });
    return svg;
  }

  const state = { tab: 'cliente', sub: 'venda', chat: null, open: true, ui: { ped: true }, confirm: null, cat: '' };
  let shadow, wrap, body, side, headEl, topEl, toastEl, openBtn, cur = null;

  function h(tag, props, ...kids) {
    const el = document.createElement(tag);
    Object.entries(props || {}).forEach(([k, v]) => {
      if (v == null || v === false) return;
      if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
      else if (k === 'value') el.value = v;
      else if (k === 'checked') el.checked = v;
      else el.setAttribute(k, v === true ? '' : v);
    });
    kids.flat(Infinity).forEach((c) => { if (c != null && c !== false && c !== '') el.append(c.nodeType ? c : String(c)); });
    return el;
  }

  const input = (value, onChange, attrs = {}) => h('input', Object.assign({ value: value == null ? '' : value, onchange: (e) => onChange(e.target.value) }, attrs));
  const fld = (label, el) => h('label', { class: 'fld' }, label, el);
  const btn = (text, onclick, cls = '', ic) => h('button', { class: `btn ${cls}`, onclick }, ic ? icon(ic) : '', text);
  const link = (text, onclick, ic, cls = '') => h('button', { class: `link ${cls}`, onclick }, ic ? icon(ic) : '', text);
  const tag = (text, cls = '') => h('span', { class: `tag ${cls}` }, text);
  const num = (v) => Number(String(v).replace(',', '.')) || 0;
  const brlNum = (v) => (v === '' || v == null ? '' : (Number(v) || 0).toFixed(2).replace('.', ','));
  const pctInput = (value, onChange) => h('div', { class: 'pct' }, input(value ? String(value).replace('.', ',') : '', onChange, { inputmode: 'decimal', placeholder: '0' }), h('span', {}, '%'));
  const money = (value, onChange, placeholder = '0,00') => h('div', { class: 'money' }, h('span', {}, 'R$'), input(brlNum(value), onChange, { inputmode: 'decimal', placeholder }));
  const searchBox = (attrs) => h('div', { class: 'search' }, icon('search'), h('input', attrs));

  function card(title, ic, right, ...kids) {
    return h('div', { class: 'card' }, h('div', { class: 'card-h' }, h('div', { class: 'ttl' }, ic ? icon(ic) : '', title), right), kids);
  }

  // Seção recolhível; o estado aberto/fechado sobrevive ao re-render.
  function fold(key, title, ic, right, content) {
    const open = !!state.ui[key];
    return h('div', { class: `card ${open ? 'open' : ''}` },
      h('div', { class: 'card-h click', onclick: () => { state.ui[key] = !open; render(true); } },
        h('div', { class: 'ttl' }, ic ? icon(ic) : '', title), right, h('span', { class: 'chev' }, icon('down'))),
      open ? content() : '');
  }

  function empty(ic, title, text, action) {
    return h('div', { class: 'empty' }, h('div', { class: 'ic' }, icon(ic)), h('b', {}, title), text, action || '');
  }

  function select(value, options, onChange, cls) {
    return h('select', { class: cls, onchange: (e) => onChange(e.target.value) },
      options.map((o) => h('option', { value: o.id, selected: o.id === value }, o.label)));
  }

  // Confirmação dentro do painel: confirm() nativo trava a aba do WhatsApp enquanto aberto.
  function confirmBox(key, text, yesLabel, onYes, cls = 'pri') {
    if (state.confirm !== key) return '';
    return h('div', { class: 'confirm' }, text,
      h('div', { class: 'row' },
        btn('Voltar', () => { state.confirm = null; render(true); }, 'sm ghost'),
        btn(yesLabel, () => { state.confirm = null; onYes(); }, `sm ${cls}`)));
  }
  const ask = (key) => () => { state.confirm = key; render(true); };

  function rel(due, now) {
    const d = due - now;
    if (Math.abs(d) < 6e4) return 'agora';
    const a = Math.abs(d);
    const u = a < FU.HOUR ? `${Math.max(1, Math.round(a / 6e4))} min` : a < FU.DAY ? `${Math.round(a / FU.HOUR)} h` : `${Math.round(a / FU.DAY)} d`;
    return d >= 0 ? `em ${u}` : `atrasado ${u}`;
  }
  const since = (ms) => rel(ms, Date.now()).replace('atrasado ', 'há ');

  const toISODate = (ms) => (ms ? new Date(ms).toISOString().slice(0, 10) : '');
  const fromISODate = (s) => (s ? new Date(`${s}T12:00:00`).getTime() : null);

  function initials(name) {
    const parts = String(name || '?').replace(/[^\p{L}\p{N}\s]/gu, '').trim().split(/\s+/).filter(Boolean);
    if (!parts.length) return '#';
    if (/^\d/.test(parts[0])) return '#';
    return (parts[0][0] + (parts.length > 1 ? parts[parts.length - 1][0] : '')).toUpperCase();
  }

  function avatar(name, cls = '') {
    let hash = 0;
    for (const ch of String(name || '')) hash = (hash * 31 + ch.codePointAt(0)) >>> 0;
    return h('div', { class: `avatar ${cls}`, style: `background: hsl(${hash % 360} 45% 46%)` }, initials(name));
  }

  function toast(msg) {
    toastEl.textContent = msg;
    toastEl.classList.add('show');
    clearTimeout(toast.t);
    toast.t = setTimeout(() => toastEl.classList.remove('show'), 2800);
  }

  function insert(text, kind, label) {
    const baseline = E.countMatches(W.bubbles(), text);
    if (W.insertText(text)) toast('Texto inserido na conversa. Revise e aperte Enviar.');
    else {
      navigator.clipboard.writeText(text).catch(() => {});
      toast('Não achei a caixa de mensagem; texto copiado para colar.');
    }
    if (state.chat) {
      const c = S.contact(state.chat);
      E.logInsert(c, { kind, label, text, baseline });
      S.commit(c);
    }
  }

  function checkSent(chat) {
    const c = chat && S.data.contacts[chat.key];
    if (!E.hasPending(c)) return;
    const sent = E.confirmSent(c, W.bubbles());
    if (!sent) return;
    sent.forEach((e) => {
      const t = E.precoFollowup(c, e);
      if (t) { c.followups.push(t); toast('Preço enviado. Retorno agendado para amanhã no Follow-up.'); }
    });
    S.commit(c); render(true);
  }

  const pendingOf = (c) => (c.followups || []).filter((f) => f.status === 'pendente').sort((a, b) => a.due - b.due);
  const newDraft = () => ({ items: [], frete: '', desconto: '' });
  const blankItem = () => ({ desc: '', marca: '', codigo: '', tipo: '', qtd: 1, preco: '' });

  // ---------- IntegraVendas ----------

  const iv = { status: null, lists: null, prod: [], prodQ: '', prodIdx: 0, picked: [], cli: [], cliQ: '', cliIdx: 0, loading: '', busy: '', err: '', errAt: '' };

  function ivCall(op, args) {
    return new Promise((resolve, reject) => {
      try {
        chrome.runtime.sendMessage({ type: 'iv', op, args }, (r) => {
          if (chrome.runtime.lastError || !r) { reject(new Error('Extensão recarregada — atualize a página do WhatsApp (F5).')); return; }
          if (r.ok) { resolve(r.data); return; }
          if (r.status === 401) { iv.status = { logged: false }; iv.lists = null; }
          reject(new Error(r.error));
        });
      } catch (_) {
        reject(new Error('Extensão recarregada — atualize a página do WhatsApp (F5).'));
      }
    });
  }

  const api = (method, path, body) => ivCall('call', { method, path, body });

  // url -> data: da foto ('' = sem foto) ou a promessa em andamento; o redesenho reaproveita sem nova busca.
  const imgs = new Map();
  function thumb(url, cls = '', peca = null) {
    const el = h('div', { class: `thumb ${cls}` }, icon('box'));
    if (!url) return el;
    const put = (t, d) => {
      if (!d) return;
      t.replaceChildren(h('img', { src: d, alt: '', draggable: 'false' }));
      if (peca) { t.setAttribute('draggable', 'true'); t.classList.add('drag'); t.title = 'Arraste para a conversa: vai a foto com a ficha da peça'; }
    };
    if (peca) {
      el.addEventListener('dragstart', (e) => {
        dragPeca = peca;
        e.dataTransfer.effectAllowed = 'copy';
        e.dataTransfer.setData(DRAG_TYPE, String(peca.codigo || ''));
      });
      el.addEventListener('dragend', () => { dragPeca = null; dropHint(false); });
    }
    const got = imgs.get(url);
    if (typeof got === 'string') { put(el, got); return el; }
    el.setAttribute('data-img', url);
    if (!got) {
      imgs.set(url, ivCall('img', { url }).then((r) => (r && r.dataUrl) || '').catch(() => '').then((d) => {
        imgs.set(url, d);
        shadow.querySelectorAll('.thumb[data-img]').forEach((t) => { if (t.getAttribute('data-img') === url) put(t, d); });
      }));
    }
    return el;
  }

  // Arrastar a foto do painel e soltar na conversa manda a foto com a ficha formatada na legenda.
  const DRAG_TYPE = 'application/x-integra-peca';
  let dragPeca = null;
  let hintEl = null;
  function dropHint(on) {
    const main = W.q('main');
    if (!on || !main) { if (hintEl) hintEl.remove(); hintEl = null; return; }
    if (!hintEl) {
      hintEl = document.createElement('div');
      hintEl.textContent = 'Solte para mandar a foto com a ficha da peça';
      document.body.append(hintEl);
    }
    const b = main.getBoundingClientRect();
    hintEl.style.cssText = `position:fixed;left:${b.left + 12}px;top:${b.top + 12}px;width:${b.width - 24}px;height:${b.height - 24}px;z-index:2147483646;pointer-events:none;border:2px dashed #00a884;border-radius:12px;background:rgba(0,168,132,.10);display:grid;place-items:center;color:#e9edef;font:600 15px system-ui,sans-serif;text-shadow:0 1px 3px #000`;
  }
  const overMain = (e) => { const m = W.q('main'); return m && m.contains(e.target); };
  document.addEventListener('dragover', (e) => {
    if (!dragPeca) return;
    const ok = overMain(e);
    dropHint(ok);
    if (ok) { e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; }
  }, true);
  document.addEventListener('drop', (e) => {
    if (!dragPeca || !overMain(e)) return;
    e.preventDefault(); e.stopImmediatePropagation();
    const p = dragPeca;
    dragPeca = null; dropHint(false);
    sendFoto(p);
  }, true);

  function dataUrlFile(d, nome) {
    const [head, b64] = d.split(',');
    const mime = (head.match(/data:([^;]+)/) || [])[1] || 'image/jpeg';
    let buf;
    if (/;base64/.test(head)) {
      const bin = atob(b64);
      buf = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) buf[i] = bin.charCodeAt(i);
    } else buf = new TextEncoder().encode(decodeURIComponent(b64));
    return new File([buf], `${nome}.${(mime.split('/')[1] || 'jpg').replace('jpeg', 'jpg')}`, { type: mime });
  }

  async function sendFoto(p) {
    const text = p.msg ? p.msg() : IV.precoMsg(p);
    const d = imgs.get(p.imagem);
    if (typeof d !== 'string' || !d) { insert(text, 'preco', p.descricao); return; }
    toast('Anexando a foto…');
    const c = state.chat ? S.contact(state.chat) : null;
    const baseline = c ? E.countMatches(W.bubbles(), text) : 0;
    const r = await W.attachImage(dataUrlFile(d, `peca-${String(p.codigo || 'foto').replace(/\W+/g, '')}`), text);
    if (r === 'aberta') { toast('Já tem uma foto esperando envio: envie ou descarte antes de arrastar outra.'); return; }
    if (r !== 'ok' && r !== 'sem-legenda') { insert(text, 'preco', p.descricao); return; }
    toast(r === 'ok' ? 'Foto com a ficha pronta. Revise e aperte Enviar.' : 'Foto anexada, mas não achei a legenda: cole a ficha à mão.');
    if (r === 'sem-legenda') navigator.clipboard.writeText(text).catch(() => {});
    if (c) { E.logInsert(c, { kind: 'preco', label: `${p.descricao} (${p.msg ? `${p.rotulo || 'item do orçamento'}, ` : ''}com foto)`, text, baseline }); S.commit(c); }
  }

  async function ivRefreshStatus() {
    try { iv.status = await ivCall('status'); } catch (_) { iv.status = { logged: false }; }
    render(true);
  }

  const logged = () => !!(iv.status && iv.status.logged);

  async function busy(label, fn, at) {
    if (iv.busy) return;
    iv.busy = label; iv.err = ''; iv.errAt = at; render(true);
    try { await fn(); } catch (e) { iv.err = e.message; } finally { iv.busy = ''; render(true); }
  }

  // Busca enquanto digita: espera o vendedor parar, descarta resposta atrasada e reaproveita a mesma busca por 2 min.
  const liveSt = {};
  function liveSearch(key, term, { min = 3, delay = 300, scope = '' }, fetcher, apply) {
    const st = liveSt[key] = liveSt[key] || { seq: 0, t: 0, cache: new Map() };
    clearTimeout(st.t);
    const q = term.trim();
    const seq = ++st.seq;
    if (q.length < min) { if (iv.loading === key) iv.loading = ''; apply(null, q); return; }
    const ck = `${scope}|${q.toLowerCase()}`;
    const hit = st.cache.get(ck);
    if (hit && Date.now() - hit.at < 120e3) { apply(hit.list, q); return; }
    st.t = setTimeout(async () => {
      iv.loading = key; render(true);
      let list; let err = '';
      try { list = await fetcher(q); } catch (e) { err = e.message; }
      if (seq !== st.seq) return;
      iv.loading = '';
      if (err) { iv.err = err; iv.errAt = key; render(true); return; }
      st.cache.set(ck, { at: Date.now(), list });
      apply(list, q);
    }, delay);
  }
  const stopLive = (key) => { const st = liveSt[key]; if (st) { st.seq++; clearTimeout(st.t); } if (iv.loading === key) iv.loading = ''; };

  const liveBox = (key, input, onClear) => h('div', { class: 'search' }, icon('search'), input,
    iv.loading === key ? h('span', { class: 'spin' }) : '',
    input.value ? h('button', { class: 'clr', title: 'Limpar (Esc)', onclick: () => { onClear(); } }, icon('x')) : '');

  // Só movimento real do mouse muda a escolha: redesenhar a lista sob o cursor parado não pode trocar o item do Enter.
  function hoverRow(e, key, idx) {
    if (iv[key] === idx) return;
    iv[key] = idx;
    e.currentTarget.parentElement.querySelectorAll('.res.kb').forEach((r) => r.classList.remove('kb'));
    e.currentTarget.classList.add('kb');
    if (key === 'prodIdx' && iv.fillDet) iv.fillDet();
  }

  function kbMove(e, key, len) {
    if (!len) return false;
    e.preventDefault();
    iv[key] = ((iv[key] || 0) + (e.key === 'ArrowDown' ? 1 : -1) + len) % len;
    render(true);
    const row = wrap.querySelector('.res.kb');
    if (row) row.scrollIntoView({ block: 'nearest' });
    return true;
  }

  const errFor = (at) => (iv.err && iv.errAt === at ? h('div', { class: 'err' }, icon('alert'), h('span', {}, iv.err)) : '');
  const busyFor = (at) => (iv.busy && iv.errAt === at ? h('div', { class: 'busy' }, h('span', { class: 'spin' }), iv.busy) : '');

  async function allPages(path, key) {
    const out = [];
    for (let pg = 1; pg <= 10; pg++) {
      const r = await api('GET', `${path}?qtdporpagina=100&pagina=${pg}`).catch(() => null);
      if (!r) break;
      out.push(...(r[key] || []));
      if (pg >= (r.qtd_paginas || 1)) break;
    }
    return out;
  }

  function loadLists() {
    if (!iv.listsP) {
      iv.listsP = Promise.all([
        allPages('formas-pagamento/', 'formas_pagamento'),
        allPages('transportadoras/', 'transportadoras'),
        api('GET', 'empresa/parametros').catch(() => null), // só administrador enxerga; para os demais a API valida na finalização
      ]).then(([formas, transp, params]) => { iv.lists = { formas, transp, params }; })
        .finally(() => { iv.listsP = null; });
    }
    return iv.listsP;
  }

  function cardConta() {
    if (!iv.status) return card('Conta', 'user', '', h('div', { class: 'busy' }, h('span', { class: 'spin' }), 'Verificando conexão…'));
    if (logged()) {
      const u = iv.status.user || {};
      return card('Conta', 'user', tag('conectado', 'ok'),
        h('div', { class: 'row' }, avatar(u.nome || u.email),
          h('div', { class: 'grow' }, h('div', { class: 't1 ellipsis' }, u.nome || u.email || 'Vendedor'), h('div', { class: 'tiny ellipsis' }, [u.empresa, u.email].filter(Boolean).join(' · ')))),
        h('div', { class: 'facts' },
          h('span', { class: 'fact' }, `Desconto até ${IV.pctBr(u.descontoMax)}`),
          h('span', { class: 'fact' }, `Acréscimo até ${IV.pctBr(u.acrescimoMax)}`)),
        h('div', { class: 'row mt' }, h('span', { class: 'tiny grow ellipsis' }, iv.status.base),
          btn('Sair', () => busy('Saindo…', async () => { iv.status = await ivCall('logout'); iv.lists = null; }, 'login'), 'sm', 'logout')),
        errFor('login'));
    }
    const st = S.data.settings;
    const url = h('input', { value: st.ivUrl || IV.DEFAULT_URL, placeholder: 'Endereço da API' });
    const email = h('input', { type: 'email', placeholder: 'E-mail do vendedor', value: st.ivEmail || '', autocomplete: 'username' });
    const senha = h('input', { type: 'password', placeholder: 'Senha', autocomplete: 'current-password' });
    const go = () => busy('Entrando…', async () => {
      st.ivUrl = IV.baseUrl(url.value); st.ivEmail = email.value.trim(); S.save('settings');
      iv.status = await ivCall('login', { base: st.ivUrl, email: st.ivEmail, senha: senha.value });
      iv.lists = null;
      if (!st.vendedor && iv.status.user && iv.status.user.nome) { st.vendedor = iv.status.user.nome.split(' ')[0]; S.save('settings'); }
      toast('Conectado ao Integra Vendas.');
    }, 'login');
    senha.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(); });
    return card('Entrar', 'user', tag('desconectado'),
      h('div', { class: 'stack' }, fld('E-mail', email), fld('Senha', senha),
        state.ui.url ? fld('Endereço da API', url) : link('Alterar endereço da API', () => { state.ui.url = true; render(true); }, '', 'muted')),
      h('div', { class: 'actions' }, btn(iv.busy === 'Entrando…' ? 'Entrando…' : 'Entrar', go, 'pri')),
      errFor('login'),
      h('div', { class: 'tiny mt' }, 'O sistema aceita uma sessão por vendedor: entrar aqui desconecta a web/app aberta com o mesmo usuário. A senha não é guardada.'));
  }

  // ---------- Conversa: cabeçalho ----------

  function hero(c) {
    const lastQ = c.quotes[c.quotes.length - 1];
    const peds = (c.pedidos || []).filter((p) => !p.cancelado).length;
    // Contato sem nome salvo: o WhatsApp mostra o próprio número como nome, e repeti-lo embaixo só polui.
    const semNome = c.phone && IV.samePhone(c.name, c.phone);
    const sub = [
      semNome ? 'sem nome salvo' : c.phone ? IV.fmtPhone(c.phone) : 'salvo pelo nome',
      c.iv && c.iv.clienteId ? c.iv.nome : '',
      F.motoLabel(c.motos[0]),
      lastQ ? `orçado ${F.brl(lastQ.total)}` : '',
      peds ? `${peds} pedido${peds > 1 ? 's' : ''}` : '',
      c.stage !== 'novo' ? `no estágio ${since(c.stageSince)}` : '',
    ].filter(Boolean).join(' · ');
    return h('div', { class: 'hero' }, avatar(c.name, 'sm'),
      h('div', { class: 'grow' }, h('div', { class: 'nm' }, semNome ? IV.fmtPhone(c.phone) : c.name), h('div', { class: 'sub ellipsis', title: sub }, sub)),
      select(c.stage, FU.STAGES, (v) => {
        FU.setStage(c, v, Date.now());
        if (FU.OPEN_STAGES.includes(v) && !pendingOf(c).some((f) => f.kind === 'cadencia')) {
          c.followups.push(...FU.planCadence(Date.now()));
          toast('Cadência de follow-up criada (2h, D+1, D+3, D+7).');
        }
        S.commit(c); render();
      }, `pill stage st-${c.stage}`));
  }

  // Marcar "Perdido" pede o motivo: é o que o funil precisa para dizer onde a venda escapa.
  function perdaBar(c) {
    if (c.stage !== 'perdido') return '';
    const lastQ = c.quotes[c.quotes.length - 1];
    const valor = lastQ ? Number(lastQ.total) || 0 : (c.draft ? F.quoteTotals(c.draft).total : 0);
    const escolhe = (id) => { c.perda = { ...(c.perda || {}), motivo: id, valor: c.perda && c.perda.valor != null ? c.perda.valor : valor, date: Date.now() }; S.commit(c); render(); };
    const p = c.perda && c.perda.motivo ? c.perda : null;
    if (!p || state.ui.perdaTroca === c.key) {
      return h('div', { class: 'perda' }, h('span', { class: 'lbl' }, 'Por que perdeu?'),
        h('div', { class: 'chips fit' }, FU.MOTIVOS_PERDA.map((m) => h('button', { class: `chip ${p && p.motivo === m.id ? 'on' : ''}`,
          onclick: () => { state.ui.perdaTroca = ''; escolhe(m.id); } }, m.label))));
    }
    const m = FU.MOTIVOS_PERDA.find((x) => x.id === p.motivo);
    return h('div', { class: 'perda' },
      h('div', { class: 'row' }, h('span', { class: 'grow' }, 'Perdido por ', h('b', {}, m ? m.label : p.motivo), p.valor ? ` · ${F.brl(p.valor)}` : ''),
        h('button', { class: 'link muted', onclick: () => { state.ui.perdaTroca = c.key; render(); } }, 'trocar')),
      h('input', { placeholder: p.motivo === 'concorrente' ? 'Onde comprou e por quanto (opcional)' : 'Detalhe (opcional)', value: p.nota || '',
        onchange: (e) => { p.nota = e.target.value.trim(); S.commit(c); } }),
      p.motivo === 'estoque' ? h('div', { class: 'tiny muted' }, 'Ponha a peça na lista de espera (aba Retornos) para avisar quando chegar.') : '');
  }

  function seg(c) {
    const now = Date.now();
    const pend = pendingOf(c);
    const late = pend.some((f) => f.due <= now);
    const cart = c.draft ? c.draft.items.filter((i) => i.desc || i.iv).length : 0;
    const opts = [
      { id: 'venda', label: 'Venda', n: cart, cls: 'acc' },
      { id: 'follow', label: 'Retornos', n: pend.length, cls: late ? 'hot' : '' },
      { id: 'envios', label: 'Enviados', n: (c.enviados || []).filter((e) => e.status === 'inserido').length, cls: 'warn' },
      { id: 'ficha', label: 'Ficha', n: 0 },
    ];
    return h('div', { class: 'seg' }, opts.map((o) => h('button', { class: state.sub === o.id ? 'on' : '', onclick: () => { state.sub = o.id; state.confirm = null; render(); } },
      o.label, o.n ? h('span', { class: `cnt ${o.cls}` }, o.n) : '')));
  }

  // ---------- Conversa: Venda ----------

  // Trocar a razão social não pode levar junto o pedido já salvo: ele pertence ao cliente anterior.
  function useCliente(c, r) {
    state.relink = false; iv.cli = []; iv.cliQ = '';
    if (c.iv && c.iv.clienteId === r.clienteId) { render(true); return; }
    const d = c.draft;
    const had = !!(d && d.pedidoId);
    if (had) d.pedidoId = null;
    if (c.iv && c.iv.clienteId) (c.pedidos || []).forEach((p) => { if (!p.clienteId) Object.assign(p, { clienteId: c.iv.clienteId, clienteNome: c.iv.nome }); });
    c.iv = { clienteId: r.clienteId, nome: r.nome, razao: r.razao || '', cnpj: r.cnpj || '', cidade: r.cidade || '', telefone: r.telefone || '' };
    E.noteCliente(c, c.iv);
    iv.compras = null;
    if (iv.prodFor === c.key) { iv.prod = []; iv.prodAll = []; }
    S.commit(c); render(true);
    toast(`Pedido agora sai para ${r.nome}.${had ? ' O orçamento já salvo no sistema continua no cliente anterior.' : ''}`);
  }

  function razoesList(c, onlyOthers) {
    const list = E.razoes(c).filter((r) => !onlyOthers || !c.iv || r.clienteId !== c.iv.clienteId);
    return list.map((r) => {
      const cur = c.iv && c.iv.clienteId === r.clienteId;
      return h('div', { class: 'res' },
        h('div', { class: 'main' }, h('div', { class: 't1 ellipsis' }, r.nome),
          h('div', { class: 'tiny ellipsis' }, [r.pedidos ? `${r.pedidos} pedido${r.pedidos > 1 ? 's' : ''}` : r.fonte === 'telefone' ? 'cadastro com este telefone' : 'sem pedido ainda', r.cnpj, r.cidade].filter(Boolean).join(' · '))),
        cur ? tag('em uso', 'ok') : btn('Usar', () => useCliente(c, r), 'sm pri'));
    });
  }

  // Primeiro a forma comum (9000 0001); se não achar, dígito a dígito pega máscaras tortas como 990.000.001.
  async function findByPhone(phone) {
    const [comum, solto] = IV.phoneQueries(phone);
    if (!comum) return [];
    const seen = new Map();
    const take = (r) => ((r && r.clientes) || []).forEach((x) => { if (IV.samePhone(x.telefone, phone) && !seen.has(x.id)) seen.set(x.id, x); });
    take(await api('GET', `clientes/?pesquisa=${encodeURIComponent(comum)}&qtdporpagina=50&pagina=1`));
    for (let pg = 1; !seen.size && pg <= 3; pg++) {
      const r = await api('GET', `clientes/?pesquisa=${encodeURIComponent(solto)}&qtdporpagina=100&pagina=${pg}`);
      take(r);
      if (!r || pg >= (r.qtd_paginas || 1)) break;
    }
    return [...seen.values()];
  }

  // A API devolve em ordem alfabética e corta: pedindo 100, o cliente certo entra na lista e a ordem é refeita aqui.
  const CLI_QTD = 100;
  const CLI_VER = 20;
  const CLI_PAGINAS = 5;
  async function searchCliNome(q) {
    const prep = BS.prepCliente(q);
    // "joão" casa até endereço: 356 clientes, e os JOÃO vêm depois de todas as razões de A a I.
    const get = async (t) => {
      const pag = (n) => api('GET', `clientes/?pesquisa=${encodeURIComponent(t)}&qtdporpagina=${CLI_QTD}&pagina=${n}`);
      const r = await pag(1);
      const list = (r && r.clientes) || [];
      const paginas = Math.min((r && r.qtd_paginas) || 1, CLI_PAGINAS);
      for (let n = 2; n <= paginas; n++) list.push(...(((await pag(n)) || {}).clientes || []));
      list.total = (r && r.qtd_clientes) || list.length;
      return list;
    };
    if (!prep.envia || prep.envia.replace(/\s/g, '').length < 3) return [];
    const list = await get(prep.envia);
    if (list.length || !prep.termos.length) return list;
    // Junta o que cada tentativa trouxe e para quando algum cliente tem todas as palavras.
    const achados = new Map();
    let relax = '';
    for (const t of BS.afrouxarCliente(prep.termos)) {
      const more = await get(t);
      more.forEach((x) => achados.has(x.id) || achados.set(x.id, x));
      if (more.length && !relax) relax = t;
      const bom = more.find((x) => BS.casaCliente(x, prep.termos));
      if (bom) { relax = t; break; }
    }
    const junto = [...achados.values()];
    junto.relax = relax;
    return junto;
  }

  function phoneRazoes(c) {
    busy('Procurando razões sociais pelo telefone…', async () => {
      let n = 0;
      (await findByPhone(c.phone)).forEach((x) => {
        c.ivClientes = c.ivClientes || [];
        if (c.ivClientes.some((y) => y.clienteId === x.id)) return;
        c.ivClientes.push({ clienteId: x.id, nome: IV.clienteLabel(x), razao: x.razao_social || '', cnpj: x.cnpj || '', cidade: [x.cidade, x.uf].filter(Boolean).join('/'), telefone: x.telefone || '', lastAt: 0, fonte: 'telefone' });
        n++;
      });
      S.commit(c);
      toast(n ? `${n} razão(ões) social(is) nova(s) com este telefone.` : 'Nenhuma outra razão social com este telefone no cadastro.');
    }, 'cli');
  }

  // Ao abrir uma conversa sem vínculo, procura o telefone no cadastro uma vez por sessão, sem travar o painel.
  function autoPhone(c) {
    if (!logged() || !c.phone || (c.iv && c.iv.clienteId)) return null;
    iv.phoneCheck = iv.phoneCheck || {};
    if (iv.phoneCheck[c.key]) return iv.phoneCheck[c.key];
    const st = iv.phoneCheck[c.key] = { status: 'loading', hits: [] };
    (async () => {
      try {
        st.hits = await findByPhone(c.phone);
        st.status = st.hits.length ? 'found' : 'none';
      } catch (e) { st.status = 'error'; st.err = e.message; }
      if (state.chat && state.chat.key === c.key) render(true);
    })();
    return st;
  }

  // clientes/{id} traz o cadastro atual e os produtos que o cliente mais comprou (só pedidos concluídos).
  function cliInfo(c) {
    if (!logged() || !c.iv || !c.iv.clienteId) return null;
    iv.cliInfo = iv.cliInfo || {};
    const id = c.iv.clienteId;
    if (iv.cliInfo[id]) return iv.cliInfo[id];
    const st = iv.cliInfo[id] = { status: 'loading' };
    api('GET', `clientes/${id}`).then((r) => {
      st.status = 'ok';
      st.cliente = (r && r.cliente) || null;
      st.mais = IV.maisComprados(r && r.produtos_mais_comprados);
      if (st.cliente && c.iv && c.iv.clienteId === id && (st.cliente.telefone || '') !== (c.iv.telefone || '')) { c.iv.telefone = st.cliente.telefone || ''; S.commit(c); }
    }).catch((e) => { st.status = 'error'; st.err = e.message; })
      .finally(() => { if (state.chat && state.chat.key === c.key) render(true); });
    return st;
  }

  function pedirCadastro(c) {
    const st = S.data.settings;
    const dest = String(st.cadastroDestino || '').trim();
    if (!dest) { state.ui.cadDest = true; render(true); return; }
    const u = iv.status && iv.status.user;
    const msg = IV.cadastroMsg(c.iv, c.phone, (u && u.nome) || st.vendedor, IV.samePhone(c.iv.telefone, c.phone) ? 'sem9' : '');
    c.cadastroPedido = { at: Date.now(), phone: c.phone, clienteId: c.iv.clienteId };
    S.commit(c); render(true);
    if (dest.includes('@')) {
      window.open(`mailto:${encodeURIComponent(dest)}?subject=${encodeURIComponent(`Atualização de cadastro – ${c.iv.nome}`)}&body=${encodeURIComponent(msg.replace(/\*/g, ''))}`, '_blank');
      toast('E-mail aberto. Revise e envie.');
      return;
    }
    if (/^[+\d\s().-]+$/.test(dest)) {
      // O WhatsApp abre a conversa do número com o texto na caixa; quem envia é o vendedor.
      location.href = `https://web.whatsapp.com/send?phone=${dest.replace(/\D/g, '')}&text=${encodeURIComponent(msg)}`;
      return;
    }
    state.pendingInsert = { name: dest, text: msg };
    Promise.resolve(W.openChat({ name: dest })).then((r) => {
      if (r === 'aberto') { toast(`Abrindo "${dest}"…`); return; }
      state.pendingInsert = null;
      navigator.clipboard.writeText(msg).catch(() => {});
      toast(`Não achei "${dest}" na lista de conversas. Pedido copiado: abra a conversa e cole.`);
    });
  }

  function cadastroAviso(c) {
    if (!c.phone || !c.iv || c.cadastroIgnorar === c.phone) return '';
    const semNove = IV.samePhone(c.iv.telefone, c.phone);
    if (semNove && !IV.sem9(c.iv.telefone, c.phone)) return '';
    const st = S.data.settings;
    const pedido = c.cadastroPedido && c.cadastroPedido.phone === c.phone && c.cadastroPedido.clienteId === c.iv.clienteId ? c.cadastroPedido : null;
    const destIn = h('input', { placeholder: 'Contato/grupo no WhatsApp, número ou e-mail', value: st.cadastroDestino || '' });
    return h('div', { class: `hint ${pedido ? 'ok' : 'warn'}` },
      h('div', { class: 'row', style: 'align-items:flex-start' }, icon(pedido ? 'check' : 'alert'),
        h('div', { class: 'grow' },
          h('b', {}, pedido ? `Atualização do cadastro pedida em ${F.ddmm(pedido.at)}` : semNove ? 'Cadastro com o celular sem o 9' : 'Este WhatsApp não está no cadastro do cliente'),
          h('div', { class: 'tiny' }, `Cadastro: ${c.iv.telefone ? IV.fmtPhone(c.iv.telefone) || c.iv.telefone : 'sem telefone'} · Conversa: ${IV.fmtPhone(c.phone)}`))),
      state.ui.cadDest ? h('div', { class: 'mt' },
        fld('Para quem vai o pedido de atualização (setor de cadastro)?', destIn),
        h('div', { class: 'row mt' }, btn('Salvar e pedir', () => {
          st.cadastroDestino = destIn.value.trim(); S.save('settings');
          if (!st.cadastroDestino) return;
          state.ui.cadDest = false; pedirCadastro(c);
        }, 'sm pri', 'send'), btn('Cancelar', () => { state.ui.cadDest = false; render(true); }, 'sm ghost'))) :
        h('div', { class: 'row mt' },
          btn(pedido ? 'Pedir de novo' : 'Pedir atualização do cadastro', () => pedirCadastro(c), pedido ? 'sm' : 'sm pri', 'send'),
          pedido ? '' : link(semNove ? 'Ignorar' : 'Não é deste cliente', () => { c.cadastroIgnorar = c.phone; S.commit(c); render(true); }, '', 'muted')));
  }

  function maisCompradosRow(c) {
    const info = cliInfo(c);
    if (!info || !info.mais || !info.mais.length) return '';
    const todos = !!state.ui.maisTodos;
    const lista = todos ? info.mais : info.mais.slice(0, 3);
    const noOrc = (p) => ((c.draft && c.draft.items) || []).some((i) => i.iv && (i.iv.id === p.id || i.codigo === p.codigo));
    return h('div', { class: 'mais' },
      h('div', { class: 'mais-h' }, h('span', {}, 'Costuma comprar'),
        info.mais.length > 3 ? link(todos ? 'Mostrar menos' : `Ver as ${info.mais.length}`, () => { state.ui.maisTodos = !todos; render(true); }, '', 'muted') : ''),
      lista.map((p) => h('button', { class: `mais-it ${noOrc(p) ? 'on' : ''}`, title: `Buscar ${p.descricao} (cód. ${p.codigo})`, onclick: () => searchProd(c, p.codigo, true) },
        h('span', { class: 'mais-q', title: 'Unidades compradas' }, `${String(p.qtd).replace('.', ',')}×`),
        h('span', { class: 'mais-n' }, p.descricao),
        noOrc(p) ? h('span', { class: 'mais-ok', title: 'Já está no orçamento' }, icon('check')) : h('span', { class: 'mais-go' }, icon('search')))));
  }

  const VITRINE = [{ id: 'top', label: 'Mais vendidos', path: 'produtos/top-vendidos' }, { id: 'novo', label: 'Chegou agora', path: 'produtos/ultimas-entradas' }];
  const vitrineCache = {};
  function vitrineLista(v) {
    const got = vitrineCache[v.id];
    if (got && (got.loading || Date.now() - got.at < 10 * 60e3)) return got;
    const st = vitrineCache[v.id] = { loading: true, at: 0, list: got ? got.list : [] };
    api('GET', v.path).then((r) => { st.list = IV.vitrine(r); st.err = ''; }).catch((e) => { st.err = e.message; })
      .finally(() => { st.loading = false; st.at = Date.now(); render(true); });
    return st;
  }
  function vitrineRow(c) {
    const aba = VITRINE.find((v) => v.id === state.ui.vitrine);
    const noOrc = (p) => ((c.draft && c.draft.items) || []).some((i) => i.iv && i.iv.id === p.id);
    const st = aba ? vitrineLista(aba) : null;
    return h('div', { class: 'mais vitrine' },
      h('div', { class: 'mais-h' }, h('span', {}, 'Vitrine da loja'),
        h('span', { class: 'vit-tabs' }, VITRINE.map((v) => h('button', { class: `vit-t ${aba === v ? 'on' : ''}`, onclick: () => { state.ui.vitrine = aba === v ? null : v.id; render(true); } }, v.label)))),
      !st ? '' : st.err ? h('div', { class: 'tiny bad-c' }, st.err)
        : !st.list.length ? h('div', { class: 'tiny muted' }, st.loading ? 'Carregando…' : 'Nada com estoque aqui agora.')
        : st.list.map((p) => {
          const t = thumb(p.imagem, 'sm', p);
          return h('div', { class: `mais-it vit-it ${noOrc(p) ? 'on' : ''}`, title: `Buscar ${p.descricao} (cód. ${p.codigo}) com o preço deste cliente`, onclick: (e) => { if (!e.target.closest('.thumb')) searchProd(c, p.codigo, true); } },
            t,
            h('span', { class: 'mais-n' }, p.descricao, h('span', { class: 'vit-m' }, `${F.brl(Number(p.preco_tabela) || 0)} · ${String(p.estoque).replace('.', ',')} em estoque`)),
            noOrc(p) ? h('span', { class: 'mais-ok', title: 'Já está no orçamento' }, icon('check')) : h('span', { class: 'mais-go' }, icon('search')));
        }));
  }

  function cardCliente(c) {
    if (c.iv && c.iv.clienteId && !(c.ivClientes || []).some((r) => r.clienteId === c.iv.clienteId)) { E.noteCliente(c, c.iv, 0); S.commit(c); }
    if (c.iv && c.iv.clienteId && !state.relink) {
      const others = E.razoes(c).filter((r) => r.clienteId !== c.iv.clienteId);
      return h('div', { class: 'card' }, h('div', { class: 'row' },
        h('div', { class: 'ibox ok' }, icon('building')),
        h('div', { class: 'grow' }, h('div', { class: 't1 ellipsis' }, c.iv.nome),
          h('div', { class: 'tiny ellipsis' }, [c.iv.cnpj, c.iv.cidade, c.iv.telefone].filter(Boolean).join(' · ') || 'Cliente do sistema')),
        btn('Trocar', () => { state.relink = true; render(); }, 'sm ghost')),
        others.length ? [
          h('div', { class: 'sub-h', style: 'margin-top:10px' }, `Este WhatsApp também compra como`),
          h('div', { class: 'results', style: 'margin-top:4px' }, razoesList(c, true))] : '',
        cadastroAviso(c),
        c.phone ? h('div', { style: 'margin-top:6px' }, link(others.length ? 'Procurar mais razões pelo telefone' : 'Este WhatsApp compra por outra razão social? Procurar pelo telefone', () => phoneRazoes(c), 'phone', 'muted')) : '',
        busyFor('cli'), errFor('cli'));
    }
    const applyCli = (list, q) => {
      const prep = BS.prepCliente(q || '');
      const conhecidos = new Set(E.razoes(c).map((r) => r.clienteId));
      const todos = list ? BS.ordenaClientes(list, prep.termos, { conhecidos }) : [];
      iv.cli = todos.slice(0, CLI_VER); iv.cliTotal = list ? (list.total || list.length) : 0;
      iv.cliRelax = list && list.relax ? list.relax : ''; iv.cliCortado = !!list && (list.total || 0) > list.length; iv.cliFor = c.key; iv.cliIdx = 0;
      if (iv.errAt === 'cli') iv.err = '';
      if (list && !list.length) { iv.err = IV.looksPhone(q) ? `Nenhum cliente com o telefone ${IV.fmtPhone(q)} (com ou sem o 9).` : `Nenhum cliente com "${q}", nem parecido.`; iv.errAt = 'cli'; }
      render(true);
    };
    const searchCli = (term, now) => {
      iv.cliQ = term;
      const t = term.trim();
      // Número pela metade ainda não dá para buscar: com o 9 ou sem, só os 8 finais identificam.
      const numero = /^[+\d\s().-]+$/.test(t) && t.replace(/\D/g, '').length < 8;
      liveSearch('cli', numero ? '' : term, { min: 3, delay: now ? 0 : 350 },
        // Telefone digitado com o 9 não casa, na busca literal, com cadastro salvo sem ele (e vice-versa).
        (q) => (IV.looksPhone(q) ? findByPhone(q) : searchCliNome(q)),
        applyCli);
    };
    const clearCli = () => { stopLive('cli'); iv.cliQ = ''; iv.cli = []; if (iv.errAt === 'cli') iv.err = ''; render(true); };
    const q = h('input', { placeholder: 'Nome, CNPJ/CPF, cidade ou telefone', value: iv.cliQ, autocomplete: 'off', spellcheck: 'false',
      oninput: (e) => searchCli(e.target.value),
      onkeydown: (e) => {
        const list = iv.cliFor === c.key ? iv.cli : [];
        if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { kbMove(e, 'cliIdx', list.length); return; }
        if (e.key === 'Escape' && e.target.value) { e.preventDefault(); e.stopPropagation(); clearCli(); return; }
        if (e.key !== 'Enter') return;
        e.preventDefault();
        if (list[iv.cliIdx] && !iv.loading) linkTo(list[iv.cliIdx]); else searchCli(e.target.value, true);
      } });
    const byPhone = () => busy('Procurando pelo telefone…', async () => {
      const hits = await findByPhone(c.phone);
      if (hits.length) { iv.cli = hits; iv.cliFor = c.key; return; }
      iv.cli = []; iv.err = 'Este telefone não está no cadastro de nenhum cliente. Busque pelo nome.';
    }, 'cli');
    const linkTo = (x) => useCliente(c, { clienteId: x.id, nome: IV.clienteLabel(x), razao: x.razao_social || '', cnpj: x.cnpj || '', cidade: [x.cidade, x.uf].filter(Boolean).join('/'), telefone: x.telefone || '' });
    const known = E.razoes(c);
    const results = iv.cliFor === c.key ? iv.cli : [];
    const auto = autoPhone(c);
    const autoBox = !auto ? '' : auto.status === 'loading' ? h('div', { class: 'busy' }, h('span', { class: 'spin' }), 'Procurando este telefone no cadastro…')
      : auto.status === 'found' ? [h('div', { class: 'sub-h' }, auto.hits.length > 1 ? `${auto.hits.length} clientes com este telefone` : 'Mesmo telefone no cadastro'),
        h('div', { class: 'results', style: 'margin:4px 0 10px' }, auto.hits.map((x) => h('div', { class: 'res on' },
          h('div', { class: 'main' }, h('div', { class: 't1 ellipsis' }, IV.clienteLabel(x)),
            (() => { const t = [x.razao_social !== x.nome_fantasia ? x.razao_social : '', x.cnpj, [x.cidade, x.uf].filter(Boolean).join('/')].filter(Boolean).join(' · '); return h('div', { class: 'tiny ellipsis', title: t }, t); })()),
          c.iv && c.iv.clienteId === x.id ? tag('em uso', 'ok') : btn('Vincular', () => linkTo(x), 'sm pri'))))]
      : auto.status === 'none' ? h('div', { class: 'hint warn', style: 'margin:0 0 10px' }, h('div', { class: 'row', style: 'align-items:flex-start' }, icon('alert'),
        h('div', { class: 'grow' }, h('b', {}, `${IV.fmtPhone(c.phone)} não está no cadastro do sistema`),
          h('div', { class: 'tiny' }, 'Se já é cliente, busque pelo nome ou CNPJ e vincule: o painel oferece pedir a atualização do cadastro.'))))
      : h('div', { class: 'tiny muted' }, `Não deu para procurar pelo telefone agora (${auto.err}).`);
    return card('Cliente no sistema', 'building',
      state.relink ? btn('Cancelar', () => { state.relink = false; render(); }, 'sm ghost') : tag('não vinculado', 'warn'),
      autoBox,
      known.length ? [h('div', { class: 'sub-h' }, 'Já vendeu para este WhatsApp'), h('div', { class: 'results', style: 'margin:4px 0 10px' }, razoesList(c, false))] : '',
      liveBox('cli', q, clearCli),
      c.phone && (!auto || auto.status === 'error') ? link('Procurar pelo telefone desta conversa', byPhone, 'phone') : '',
      !c.phone ? h('div', { class: 'tiny muted', style: 'margin-top:6px' }, 'Contato salvo pelo nome: o WhatsApp não mostra o número, então busque pelo nome.') : '',
      busyFor('cli'), errFor('cli'),
      results.length && iv.cliRelax ? h('div', { class: 'tiny muted', style: 'margin:4px 0' }, `Nada com "${iv.cliQ.trim()}" exato; parecidos com "${iv.cliRelax}":`) : '',
      results.length && iv.cliCortado ? h('div', { class: 'tiny muted', style: 'margin:4px 0' }, `${iv.cliTotal} clientes com "${iv.cliQ.trim()}": digite mais uma palavra do nome ou a cidade.`) : '',
      results.length ? h('div', { class: 'results' },
        h('div', { class: 'res-h' }, h('span', { class: 'cnt' }, iv.cliTotal > results.length ? `${results.length} mais parecidos de ${iv.cliTotal}` : `${results.length} cliente${results.length > 1 ? 's' : ''}`), h('span', { class: 'keys' }, '↑↓ escolhe · Enter vincula · Esc limpa')),
        results.map((x, idx) => h('div', { class: `res ${idx === iv.cliIdx ? 'kb' : ''}`, onmousemove: (e) => hoverRow(e, 'cliIdx', idx) },
          h('div', { class: 'main' }, h('div', { class: 't1 ellipsis' }, IV.clienteLabel(x)),
            h('div', { class: 'tiny' }, [x.razao_social !== x.nome_fantasia ? x.razao_social : '', x.cnpj, [x.cidade, x.uf].filter(Boolean).join('/'), x.telefone].filter(Boolean).join(' · '))),
          btn('Vincular', () => linkTo(x), 'sm pri')))) : '');
  }

  // A API ordena por nome e corta no limite: pedindo muitos, a relevância daqui acha "OLEO …" depois de todos os "ANEL … OLEO".
  const PROD_QTD = 400;
  const PROD_VER = 30;
  function searchProd(c, term, now) {
    iv.prodQ = term; iv.prodFor = c.key;
    const scope = (c.iv && c.iv.clienteId) || 0;
    const get = (t) => api('GET', `pedidos/produtos?pesquisa=${encodeURIComponent(t)}&qtd=${PROD_QTD}${scope ? `&cliente=${scope}` : ''}`).then((r) => r || []);
    liveSearch('prod', term, { min: 3, delay: now ? 0 : 250, scope },
      async (q) => {
        const prep = prepara(q);
        if (prep.envia.length < 3) return [];
        const list = await get(prep.envia);
        if (list.length) return list;
        for (const t of [...BS.alternativas(prep.envia), ...DZ.afrouxar(prep.envia)]) {
          const more = await get(t);
          if (more.length) { more.relax = t; return more; }
        }
        return list;
      },
      (list, q) => {
        iv.prodPrep = prepara(q || '');
        const ctx = buscaCtx(c, iv.prodPrep);
        iv.prodMoto = ctx.motoNome;
        iv.prodAll = list ? BS.ordena(list, iv.prodPrep, ctx) : [];
        iv.prodCheio = !!list && list.length >= PROD_QTD;
        iv.prodTipo = ''; iv.prodVer = PROD_VER;
        iv.prodShown = list ? q : ''; iv.prodIdx = 0; iv.prodRelax = list && list.relax ? list.relax : '';
        fatiaProd();
        if (iv.errAt === 'prod') iv.err = '';
        if (list && !list.length) { iv.err = iv.prodPrep.fora.length && !iv.prodPrep.envia ? 'Diga o que procurar além do que quer tirar (ex.: oleo -anel).' : `Nada no estoque com "${q}".`; iv.errAt = 'prod'; }
        render(true);
      });
  }
  const prepara = (q) => BS.prepara(q, S.data.settings.buscaGirias);
  function buscaCtx(c, prep) {
    const info = cliInfo(c);
    const esc = S.data.settings.buscaEscolhas || {};
    const modelos = (c.motos || []).map((m) => m.modelo).filter(Boolean);
    const moto = BS.motoCtx(modelos);
    return { costuma: new Set(((info && info.mais) || []).map((p) => p.id)), escolhas: esc[prep.chave] || null, moto, motoNome: moto && !BS.consultaTemMoto(prep) ? modelos.join(', ') : '' };
  }
  function fatiaProd() {
    const all = iv.prodAll || [];
    const f = iv.prodTipo ? all.filter((p) => BS.tipo(p) === iv.prodTipo) : all;
    iv.prodFiltrados = f.length;
    iv.prod = f.slice(0, iv.prodVer || PROD_VER);
    if (iv.prodIdx >= iv.prod.length) iv.prodIdx = 0;
  }
  // O que o vendedor escolhe para uma busca sobe nas próximas vezes que ele digitar a mesma coisa.
  function aprendeBusca(p) {
    const k = iv.prodShown && prepara(iv.prodShown).chave;
    if (!k || !p || !p.id) return;
    S.data.settings.buscaEscolhas = BS.aprende(S.data.settings.buscaEscolhas, k, p.id);
    S.save('settings');
  }

  // Vendedor seleciona a pergunta do cliente na conversa e a busca já roda com o nome da peça.
  let selT = 0;
  let lastSel = '';
  document.addEventListener('selectionchange', () => {
    clearTimeout(selT);
    selT = setTimeout(() => {
      const sel = document.getSelection();
      const text = sel ? String(sel).trim() : '';
      const main = W.q('main');
      if (!text || text.length > 2000 || !main || !sel.anchorNode || !main.contains(sel.anchorNode)) return;
      if (main.querySelector('footer') && main.querySelector('footer').contains(sel.anchorNode)) return;
      if (!state.chat || !logged() || !state.open) return;
      const itens = DZ.parseLista(text);
      if (itens.length >= 2) {
        if (text === lastSel) return;
        lastSel = text;
        cotarLista(S.contact(state.chat), text);
        return;
      }
      if (text.length > 160) return;
      const termo = DZ.termoBusca(text);
      if (termo.length < 3 || termo === lastSel || !state.chat || !logged() || !state.open) return;
      lastSel = termo;
      state.tab = 'cliente'; state.sub = 'venda';
      searchProd(S.contact(state.chat), termo, true);
    }, 400);
  });

  function clearProd() {
    stopLive('prod');
    iv.prodQ = ''; iv.prod = []; iv.prodAll = []; iv.prodTipo = ''; iv.prodShown = ''; iv.prodIdx = 0; iv.prodRelax = '';
    if (iv.errAt === 'prod') iv.err = '';
    render(true);
  }

  // A prazo = tabela; à vista = 5% exato, como a política do orçamento registra na API.
  function precosPeca(c, p) {
    const prazo = Number(p.preco_tabela) || 0;
    const max = (iv.status && iv.status.user && iv.status.user.descontoMax) || 0;
    const pol = c.draft ? polAtual(c, c.draft) : { tipo: 'prazo' };
    return { prazo, vista: IV.precoPol(prazo, 5), pode: prazo > 0 && max >= 5, ativo: pol.tipo === 'av5' ? 'vista' : pol.tipo === 'prazo' ? 'prazo' : '' };
  }

  // produto id -> links das fotos, ou a promessa da busca em andamento.
  const fotos = new Map();
  const fotoPeca = (p, url) => (url === p.imagem ? p : { ...p, imagem: url });
  function fotosDe(p) {
    const got = fotos.get(p.id);
    if (Array.isArray(got)) return got;
    if (!got && logged()) {
      fotos.set(p.id, api('GET', `produtos/${p.id}`).then((r) => IV.fotosProduto(r, p.imagem)).catch(() => IV.fotosProduto(null, p.imagem))
        .then((l) => { fotos.set(p.id, l); if (iv.fillDet) iv.fillDet(); }));
    }
    return IV.fotosProduto(null, p.imagem);
  }
  const fotoSel = (p) => (iv.fotoSel && iv.fotoSel.id === p.id ? iv.fotoSel.url : p.imagem);
  // Foto que não carrega (link do ERP montado errado pela API) some da faixa em vez de virar ícone vazio.
  function galeria(p) {
    const l = fotosDe(p).filter((u) => imgs.get(u) !== '');
    if (l.length < 2) return '';
    const sel = fotoSel(p);
    return h('div', { class: 'galeria' }, l.map((u) => {
      const t = thumb(u, `sm ${u === sel ? 'on' : ''}`, fotoPeca(p, u));
      t.addEventListener('click', () => { iv.fotoSel = { id: p.id, url: u }; iv.fillDet(); });
      const pend = imgs.get(u);
      if (pend && typeof pend.then === 'function') pend.then(() => { if (imgs.get(u) === '' && iv.fillDet) iv.fillDet(); });
      return t;
    }), h('span', { class: 'galeria-n' }, `${l.length} fotos: clique para ver, arraste para mandar`));
  }

  function tiposRow() {
    const all = iv.prodAll || [];
    if (all.length < 6) return '';
    const ts = BS.tipos(all, iv.prodPrep);
    if (ts.length < 2) return '';
    const set = (t) => { iv.prodTipo = iv.prodTipo === t ? '' : t; iv.prodVer = PROD_VER; iv.prodIdx = 0; fatiaProd(); render(true); };
    return h('div', { class: 'chips tipos' }, h('span', { class: 'lead' }, 'Tipo'),
      ts.map((t) => h('button', { class: `chip ${iv.prodTipo === t.id ? 'on' : ''}`, title: iv.prodTipo === t.id ? 'Mostrar todos os tipos' : `Só ${t.id.toUpperCase()}`, onclick: () => set(t.id) },
        t.id.toUpperCase(), h('span', { class: 'chip-n' }, String(t.n)))));
  }

  // Lista colada pelo cliente: cada linha vira uma busca, em sequência (a API recusa rajada), e o vendedor confere antes de pôr no orçamento.
  const LISTA_QTD = 100;
  // "retrovisor dela": a moto citada por último antes da linha (no bloco, depois nas mensagens de antes), senão a da Ficha.
  function resolveRefs(c, itens, texto, antes) {
    const ficha = BS.motoNoTexto(((c.motos || [])[0] || {}).modelo || '');
    let cursor = 0;
    itens.forEach((x) => {
      const at = texto.indexOf(x.linha, cursor);
      const ate = at >= 0 ? at : cursor;
      cursor = at >= 0 ? at + x.linha.length : cursor;
      if (!x.ref || BS.consultaTemMoto(prepara(x.termo))) return;
      const noBloco = BS.motoAntes(texto.slice(0, ate).split('\n'));
      const conversa = noBloco ? '' : BS.motoAntes(antes);
      // Encaminhadas chegam fora de ordem: a moto citada depois no bloco é o último palpite, e vem marcada para conferir.
      // Item com quantidade ("2 kit tração cg 160") traz a moto dele, não a do assunto: só pergunta solta conta.
      const depois = noBloco || conversa || ficha ? '' : BS.motoAntes(itens.slice(itens.indexOf(x) + 1).filter((y) => !y.qtdDita).map((y) => y.linha).reverse());
      const moto = noBloco || conversa || ficha || depois;
      if (!moto) { x.refInfo = `"${x.ref}": não achei de qual moto; complete o nome`; return; }
      x.termo = `${x.termo} ${moto}`;
      x.refInfo = `"${x.ref}" = ${moto} (${noBloco ? 'citada acima' : conversa ? 'citada antes na conversa' : ficha ? 'da Ficha' : 'citada depois; confira'})`;
    });
    return itens;
  }

  function cotarLista(c, texto, antes = []) {
    const itens = resolveRefs(c, DZ.parseLista(texto), texto, antes);
    if (!itens.length) { toast('Não achei peças nessa mensagem.'); return; }
    const lista = { ck: c.key, linhas: itens.map((x, i) => ({ ...x, i, termoOrig: x.termo, status: 'fila', opcoes: [], escolha: 0, certeza: '' })) };
    iv.lista = lista;
    state.open = true; applyOpen();
    state.tab = 'cliente'; state.sub = 'venda';
    render(true);
    (async () => { for (const l of lista.linhas) { if (iv.lista !== lista) return; await buscarLinha(c, lista, l); } })();
  }

  async function buscarLinha(c, lista, l) {
    l.status = 'buscando'; render(true);
    const prep = prepara(l.termo);
    const scope = (c.iv && c.iv.clienteId) || 0;
    const get = (t) => api('GET', `pedidos/produtos?pesquisa=${encodeURIComponent(t)}&qtd=${LISTA_QTD}${scope ? `&cliente=${scope}` : ''}`).then((r) => r || []);
    try {
      let list = prep.envia ? await get(prep.envia) : [];
      if (!list.length && prep.envia) {
        for (const t of [...BS.alternativas(prep.envia), ...DZ.afrouxar(prep.envia)]) { list = await get(t); if (list.length) { l.afrouxou = t; break; } }
      }
      const ctx = buscaCtx(c, prep);
      const ord = BS.ordena(list, prep, ctx);
      l.opcoes = ord.slice(0, 3); l.escolha = 0;
      l.certeza = l.afrouxou && ord.length ? 'confira' : BS.certeza(ord, prep, ctx);
      l.status = ord.length ? 'ok' : 'nada';
    } catch (e) {
      l.status = 'erro'; l.erro = (e && e.message) || 'falhou';
    }
    if (iv.lista === lista) render(true);
  }

  function listaCard(c, d) {
    const L = iv.lista;
    if (!L || L.ck !== c.key) return '';
    const prontas = L.linhas.filter((l) => l.status === 'ok' && l.opcoes[l.escolha]);
    const andando = L.linhas.some((l) => l.status === 'fila' || l.status === 'buscando');
    const fechar = () => { iv.lista = null; render(true); };
    const CERTEZA = { alta: ['ok', 'confere'], confira: ['warn', 'confira'], baixa: ['bad', 'duvidoso'], nada: ['bad', 'não achei'] };
    const pedido = (l) => `${l.qtd}${l.unidade ? ` ${l.unidade}` : ''}`;
    const linha = (l) => {
      const p = l.opcoes[l.escolha];
      const termo = h('input', { class: 'lt-termo', value: l.termo, spellcheck: 'false', title: 'Corrija o nome e tecle Enter para buscar de novo',
        onkeydown: (e) => { if (e.key === 'Enter') { e.preventDefault(); l.termo = e.target.value.trim(); l.afrouxou = ''; buscarLinha(c, L, l); } } });
      const qtd = h('input', { class: 'lt-qtd', value: String(l.qtd), inputmode: 'numeric', title: 'Quantidade',
        oninput: (e) => { l.qtd = Math.max(1, Math.round(num(e.target.value))) || 1; } });
      const cert = l.status === 'ok' ? CERTEZA[l.certeza] || CERTEZA.confira : l.status === 'nada' ? CERTEZA.nada : null;
      const unidadeDif = p && l.unidade && p.unidade && !IV_UNI(l.unidade, p.unidade);
      return h('div', { class: `lt-l ${l.status}` },
        h('div', { class: 'lt-top' }, qtd, termo,
          l.status === 'buscando' || l.status === 'fila' ? h('span', { class: 'tiny muted' }, l.status === 'fila' ? 'na fila' : 'buscando…') : '',
          cert ? tag(cert[1], cert[0]) : '',
          l.status === 'erro' ? tag('erro', 'bad') : '',
          h('button', { class: 'x-btn', title: 'Tirar esta linha', onclick: () => { L.linhas = L.linhas.filter((x) => x !== l); render(true); } }, icon('x'))),
        h('div', { class: 'lt-orig tiny muted ellipsis', title: l.linha }, `cliente: "${l.linha}"`, l.afrouxou ? ` · nada exato, mostrando "${l.afrouxou}"` : ''),
        l.refInfo ? h('div', { class: `lt-orig tiny ${/não achei|confira/.test(l.refInfo) ? 'warn-c' : 'muted'}` }, l.refInfo) : '',
        p ? h('div', { class: 'lt-opcoes' }, l.opcoes.map((o, i) => h('div', { class: `lt-op ${i === l.escolha ? 'on' : ''}`, role: 'button', tabindex: '0', title: `${o.descricao}\ncód. ${o.codigo}`,
          onclick: () => { l.escolha = i; render(true); }, onkeydown: (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); l.escolha = i; render(true); } } },
          // Botão não deixa o filho ser arrastado no Chrome: por isso a opção é div.
          thumb(o.imagem, '', o.imagem ? { descricao: o.descricao, codigo: o.codigo, imagem: o.imagem, rotulo: 'cotação', msg: () => IV.cotacaoMsg([{ p: o, qtd: l.qtd }]) } : null),
          h('span', { class: 'lt-nome' }, o.descricao),
          h('span', { class: Number(o.estoque) > 0 ? 'ok-c' : 'bad-c' }, Number(o.estoque) > 0 ? '●' : '○'),
          h('b', {}, F.brl(Number(o.preco_tabela) || 0))))) : '',
        unidadeDif ? h('div', { class: 'tiny warn-c' }, `Pediu em ${l.unidade}; o produto é vendido em ${p.unidade}. Confira a quantidade.`) : '',
        l.status === 'erro' ? h('div', { class: 'tiny bad-c' }, l.erro) : '');
    };
    const enviarCliente = () => {
      const faltam = L.linhas.filter((l) => l.status === 'nada' || l.status === 'erro').map((l) => l.linha);
      insert(IV.cotacaoMsg(prontas.map((l) => ({ p: l.opcoes[l.escolha], qtd: l.qtd })), faltam), 'preco', `cotação de ${prontas.length} ${prontas.length > 1 ? 'peças' : 'peça'}`);
    };
    // Responde "tem em estoque?" e já põe o que falta na lista de espera: a aba Hoje avisa quando entrar.
    const responderEstoque = () => {
      const faltam = L.linhas.filter((l) => l.status === 'nada' || l.status === 'erro').map((l) => l.linha);
      const itens = prontas.map((l) => ({ p: l.opcoes[l.escolha], qtd: l.qtd }));
      insert(IV.estoqueMsg(itens, faltam), 'preco', `estoque de ${itens.length} ${itens.length > 1 ? 'peças' : 'peça'}`);
      let n = 0;
      itens.forEach(({ p, qtd }) => {
        if (IV.estoqueSituacao(p, qtd).sit === 'tem') return;
        const ja = S.data.waitlist.some((w) => w.status === 'aguardando' && w.contactKey === c.key && (w.produtoId === p.id || w.peca === p.descricao));
        if (ja) return;
        S.data.waitlist.push({ id: crypto.randomUUID(), peca: p.descricao, produtoId: p.id, contactKey: c.key, createdAt: Date.now(), status: 'aguardando' });
        n++;
      });
      if (n) { if (iv.hoje) iv.hoje.at = 0; S.save('waitlist'); S.commit(c); toast(`Resposta na caixa de mensagem. ${n} ${n > 1 ? 'peças entraram' : 'peça entrou'} na lista de espera.`); }
    };
    const porTudo = () => {
      prontas.forEach((l) => {
        const p = l.opcoes[l.escolha];
        addProduto(d, p, l.qtd);
        const k = prepara(l.termo).chave;
        S.data.settings.buscaEscolhas = BS.aprende(S.data.settings.buscaEscolhas, k, p.id);
        if (l.termo !== l.termoOrig) S.data.settings.buscaGirias = BS.aprendeGiria(S.data.settings.buscaGirias, l.termoOrig, l.termo);
      });
      S.save('settings'); S.commit(c);
      const falta = L.linhas.length - prontas.length;
      iv.lista = falta ? { ...L, linhas: L.linhas.filter((l) => !prontas.includes(l)) } : null;
      render(true);
      toast(`${prontas.length} ${prontas.length > 1 ? 'itens' : 'item'} no orçamento.${falta ? ` ${falta} ficaram na lista para você resolver.` : ''}`);
    };
    return card('Cotar lista', 'file', h('button', { class: 'link muted', onclick: fechar }, 'fechar'),
      h('div', { class: 'tiny muted', style: 'margin-bottom:6px' }, `${L.linhas.length} ${L.linhas.length > 1 ? 'peças' : 'peça'} no pedido do cliente. Clique na opção certa; ● tem estoque, ○ sem estoque.`),
      L.linhas.map(linha),
      h('div', { class: 'row', style: 'margin-top:8px;flex-wrap:wrap;justify-content:flex-end' },
        h('span', { class: 'grow tiny muted' }, andando ? 'Buscando as peças…' : `${prontas.length} de ${L.linhas.length} prontas`),
        h('button', { class: 'btn sm', disabled: !prontas.length || andando, title: 'Responde "tem em estoque?" sem preço e sem revelar a quantidade; o que falta entra na lista de espera', onclick: responderEstoque }, icon('box'), 'Responder estoque'),
        h('button', { class: 'btn sm', disabled: !prontas.length || andando, title: 'Põe a cotação na caixa de mensagem para você revisar e enviar', onclick: enviarCliente }, icon('send'), 'Enviar ao cliente'),
        h('button', { class: 'btn sm pri', disabled: !prontas.length, onclick: porTudo }, icon('plus'), prontas.length ? `Pôr ${prontas.length} no orçamento` : 'Pôr no orçamento')),
      prontas.some((l) => l.opcoes[l.escolha].imagem) ? h('div', { class: 'tiny muted', style: 'margin-top:4px' }, 'Arraste a foto de uma opção para a conversa: vai a foto com o preço na legenda.') : '');
  }
  const IV_UNI = (pedido, vende) => {
    const v = BS.norm(vende);
    return pedido === 'par' ? /^(par|pr|jg|jogo|kit)/.test(v) : pedido === 'pc' || pedido === 'un' ? /^(pc|pç|un|und|peca)/.test(v) : true;
  };

  // Sem qtd soma um múltiplo ao que já está lá; com qtd, arredonda para cima no múltiplo do produto.
  function addProduto(d, p, qtd) {
    const had = d.items.find((i) => i.iv && i.iv.id === p.id);
    const mult = (had ? had.iv.multiplo : Number(p.multiplo)) || 1;
    const q = qtd ? Math.ceil(qtd / mult - 1e-9) * mult : mult;
    if (had) {
      had.qtd = Math.round((num(had.qtd) + q) * 1000) / 1000;
      return { item: had, novo: false };
    }
    const blank = d.items.findIndex((i) => !i.desc && !i.iv);
    const item = IV.productToItem(p);
    item.qtd = q;
    if (blank >= 0) d.items[blank] = item; else d.items.push(item);
    return { item, novo: true };
  }

  function prodSearch(c, d) {
    const results = iv.prodFor === c.key ? iv.prod : [];
    const q = h('input', { placeholder: 'Buscar peça (nome ou código)', value: iv.prodQ, autocomplete: 'off', spellcheck: 'false',
      oninput: (e) => searchProd(c, e.target.value),
      onkeydown: (e) => {
        if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { kbMove(e, 'prodIdx', results.length); return; }
        if (e.key === 'Escape' && e.target.value) { e.preventDefault(); e.stopPropagation(); clearProd(); return; }
        if (e.key !== 'Enter') return;
        e.preventDefault();
        const p = iv.prodShown === e.target.value.trim() ? results[iv.prodIdx] : null;
        if (!p) { searchProd(c, e.target.value, true); return; }
        if (e.ctrlKey || e.metaKey) { aprendeBusca(p); insert(IV.precoMsg(p), 'preco', p.descricao); return; }
        add(p); clearProd();
      } });
    const add = (p) => {
      aprendeBusca(p);
      const it = addProduto(d, p);
      S.commit(c); render(true);
      toast(it.novo ? `${it.item.desc} adicionado.` : `${it.item.desc}: ${String(it.item.qtd).replace('.', ',')} no orçamento.`);
    };
    const picked = iv.picked;
    const isPicked = (p) => picked.some((x) => x.id === p.id);
    const toggle = (p) => { iv.picked = isPicked(p) ? picked.filter((x) => x.id !== p.id) : [...picked, p]; render(true); };
    const waiting = (p) => S.data.waitlist.some((w) => w.status === 'aguardando' && w.contactKey === c.key && (w.produtoId === p.id || w.peca === p.descricao));
    const addWait = (p) => {
      if (waiting(p)) return;
      S.data.waitlist.push({ id: crypto.randomUUID(), peca: p.descricao, produtoId: p.id, contactKey: c.key, createdAt: Date.now(), status: 'aguardando' });
      if (iv.hoje) iv.hoje.at = 0;
      S.commit(c); S.save('waitlist'); render(true);
      toast('Anotado. A aba Hoje avisa quando entrar no estoque.');
    };
    const detEl = h('div', {});
    iv.fillDet = () => {
      const p = results[iv.prodIdx];
      if (!p) { detEl.replaceChildren(); return; }
      const inCart = d.items.some((i) => i.iv && i.iv.id === p.id);
      const up = IV.ultimoPedido(p);
      const tem = Number(p.estoque) > 0;
      detEl.replaceChildren(h('div', { class: 'det' },
        h('div', { class: 'det-top' }, (() => {
          const fp = fotoPeca(p, fotoSel(p));
          const t = thumb(fp.imagem, 'lg', fp);
          if (fp.imagem) t.addEventListener('click', () => sendFoto(fp));
          return t;
        })(),
          h('div', { class: 'grow' },
            h('div', { class: 't1' }, p.descricao),
            h('div', { class: 'kv' }, [`cód. ${p.codigo}`, p.unidade, p.multiplo > 1 ? `múltiplo ${p.multiplo}` : ''].filter(Boolean).join(' · ')),
            h('div', { class: 'kv' }, h('span', { class: tem ? 'ok-c' : 'bad-c' }, tem ? `● ${p.estoque} em estoque` : '● sem estoque')))),
        galeria(p),
        (() => {
          const x = precosPeca(c, p);
          const box = (id, lbl, val, sub) => h('div', { class: `pb ${x.ativo === id ? 'on' : ''}` },
            h('div', { class: 'pb-l' }, lbl), h('div', { class: 'pb-v' }, F.brl(val)), h('div', { class: 'pb-s' }, sub));
          return h('div', { class: 'precos' },
            box('prazo', 'A prazo', x.prazo, 'tabela'),
            x.pode ? box('vista', 'À vista 5%', x.vista, `${F.brl(Math.round((x.prazo - x.vista) * 100) / 100)} a menos`) : '');
        })(),
        up ? ultLinha(up, p.id, cur && cur.name ? cur.name.split(' ')[0] : 'Cliente') : '',
        h('div', { class: 'row' },
          h('button', { class: 'btn sm', title: 'Escreve o preço na conversa; você revisa e envia (Ctrl+Enter)', onclick: () => { aprendeBusca(p); insert(IV.precoMsg(p), 'preco', p.descricao); } }, icon('send'), 'Só o preço'),
          h('button', { class: 'btn pri sm', title: 'Pôr no orçamento (Enter)', onclick: () => add(p) }, icon('plus'), inCart ? 'Mais 1' : 'Adicionar'))));
    };
    iv.fillDet();
    return [
      liveBox('prod', q, clearProd),
      picked.length ? h('div', { class: 'picked' },
        h('span', { class: 'grow ellipsis', title: picked.map((p) => p.descricao).join('\n') }, `${picked.length} para cotar: ${picked.map((p) => p.descricao.split(' ').slice(0, 2).join(' ')).join(', ')}`),
        btn(picked.length > 1 ? `Mandar ${picked.length} preços` : 'Mandar preço', () => {
          insert(IV.precosMsg(picked), 'preco', picked.map((p) => p.descricao).join(' + '));
          iv.picked = []; render(true);
        }, 'sm pri', 'send'),
        btn('Limpar', () => { iv.picked = []; render(true); }, 'sm ghost')) : '',
      iv.prodFor === c.key ? errFor('prod') : '',
      results.length ? h('div', { class: `results ${picked.length ? 'picking' : ''}` },
        iv.prodRelax ? h('div', { class: 'tiny muted', style: 'margin-top:6px' }, `Nada com "${iv.prodShown}". Mostrando "${iv.prodRelax}".`) : '',
        iv.prodMoto ? h('div', { class: 'tiny muted', style: 'margin-top:6px', title: 'Peças que citam a moto da Ficha sobem na lista. Digite outra moto na busca para trocar.' }, `Primeiro as da ${iv.prodMoto}`) : '',
        tiposRow(),
      h('div', { class: 'res-h' }, h('span', { class: 'cnt', title: iv.prodCheio ? `A API corta em ${PROD_QTD}: acrescente a moto, a medida ou -palavra para tirar o que não serve` : '' },
        iv.prodFiltrados > results.length || iv.prodCheio ? `${results.length} de ${iv.prodFiltrados}${iv.prodCheio && !iv.prodTipo ? '+' : ''}` : `${results.length} encontrado${results.length > 1 ? 's' : ''}`),
        h('span', { class: 'keys' }, '↑↓ escolhe · Enter põe no orçamento · Ctrl+Enter manda o preço · -palavra tira · Esc limpa')),
        results.map((p, idx) => {
          const inCart = d.items.some((i) => i.iv && i.iv.id === p.id);
          const on = isPicked(p);
          return h('div', { class: `res ${on ? 'on' : ''} ${idx === iv.prodIdx ? 'kb' : ''}`, onmousemove: (e) => hoverRow(e, 'prodIdx', idx) },
            h('div', { class: 'tw' }, thumb(p.imagem, '', p),
              h('button', { class: `pick ${on ? 'on' : ''}`, title: 'Selecionar para mandar vários preços numa mensagem', onclick: () => toggle(p) }, on ? icon('check') : '')),
            h('div', { class: 'main' },
              h('div', { class: 't1' }, p.descricao),
              h('div', { class: 'meta' },
                h('span', { class: Number(p.estoque) > 0 ? 'ok-c' : 'bad-c' }, `● ${p.estoque} em estoque`),
                h('span', {}, `cód. ${p.codigo}`),
                p.multiplo > 1 ? h('span', {}, `múlt. ${p.multiplo}`) : '',
                IV.ultimoPedido(p) ? h('span', { class: 'ult', title: 'Última compra deste cliente' }, `comprou ${IV.ultimoPedido(p).data.slice(0, 5)}`) : '')),
            h('div', { class: 'res-r' },
              (() => {
                const x = precosPeca(c, p);
                return h('div', { class: 'price2' },
                  h('div', { class: `pz ${x.ativo === 'prazo' ? 'on' : ''}`, title: 'A prazo (tabela)' }, h('small', {}, 'prazo'), F.brl(x.prazo)),
                  x.pode ? h('div', { class: `pv ${x.ativo === 'vista' ? 'on' : ''}`, title: 'À vista com 5% de desconto' }, h('small', {}, 'à vista'), F.brl(x.vista)) : '');
              })(),
            h('div', { class: 'res-btns' },
            Number(p.estoque) > 0 ? '' : h('button', { class: `add snd ${waiting(p) ? 'on' : ''}`, title: waiting(p) ? 'Já está na lista de espera' : 'Avisar este cliente quando chegar', onclick: () => addWait(p) }, icon(waiting(p) ? 'check' : 'bell')),
            h('button', { class: 'add snd', title: 'Escrever o preço no chat (você revisa e envia)', onclick: () => { aprendeBusca(p); insert(IV.precoMsg(p), 'preco', p.descricao); } }, icon('send')),
            h('button', { class: 'add', title: inCart ? 'Já está no orçamento: soma mais um' : 'Adicionar ao orçamento', onclick: () => add(p) }, icon(inCart ? 'check' : 'plus')))));
        }),
        iv.prodFiltrados > results.length ? h('button', { class: 'res-mais', onclick: () => { iv.prodVer = (iv.prodVer || PROD_VER) + PROD_VER; fatiaProd(); render(true); } },
          `Mostrar mais ${Math.min(PROD_VER, iv.prodFiltrados - results.length)}`) : '') : '',
      results.length ? detEl : '',
    ];
  }

  // Itens postos no orçamento antes das fotos não guardaram o endereço da imagem.
  const fotoPedida = new Set();
  function fotoDoItem(c, it) {
    if (!logged() || fotoPedida.has(it.iv.id)) return;
    fotoPedida.add(it.iv.id);
    api('GET', `pedidos/produtos/${it.iv.id}`).then((r) => {
      it.iv.imagem = (r && r.imagem) || '';
      S.commit(c);
      if (it.iv.imagem) render(true);
    }).catch(() => {});
  }

  function itemRow(c, d, it, i, refreshTotals) {
    const lineEl = h('span', { class: 'lt' });
    const metaEl = h('div', { class: 'meta' });
    const step = it.iv ? it.iv.multiplo || 1 : 1;
    const paint = () => {
      lineEl.textContent = F.brl(F.linha(it));
      if (!it.iv) return;
      const pct = typeof it.pct === 'number' ? it.pct : it.iv.tabela ? Math.round((1 - num(it.preco) / it.iv.tabela) * 10000) / 100 : 0;
      metaEl.replaceChildren(...[
        h('span', {}, `cód. ${it.codigo}`),
        h('span', {}, `tabela ${F.brl(it.iv.tabela)}`),
        pct > 0 ? tag(`desc. ${IV.pctBr(pct)}`, pct > ((iv.status && iv.status.user && iv.status.user.descontoMax) || 0) ? 'bad' : 'ok') : '',
        pct < 0 ? tag(`acrésc. ${IV.pctBr(-pct)}`, 'info') : '',
        num(it.qtd) > it.iv.estoque ? tag(`só ${it.iv.estoque} em estoque`, 'bad') : h('span', {}, `${it.iv.estoque} em estoque`),
      ].filter(Boolean));
    };
    const changed = () => { paint(); refreshTotals(); S.commit(c); };
    const qtyIn = h('input', { value: it.qtd, inputmode: 'decimal', onchange: (e) => { it.qtd = num(e.target.value); changed(); } });
    const bump = (dir) => {
      it.qtd = Math.max(step, Math.round((num(it.qtd) + dir * step) * 1000) / 1000);
      qtyIn.value = it.qtd; changed();
    };
    const remove = h('button', { class: 'x-btn', title: 'Remover', onclick: (e) => { e.stopPropagation(); d.items.splice(i, 1); state.ui.itOpen = null; S.commit(c); render(true); } }, icon('trash'));
    const key = `${c.key}:${i}`;
    if (it.iv && it.iv.imagem === undefined) fotoDoItem(c, it);
    // A foto arrastada do orçamento leva o preço e a quantidade negociados, não os da tabela.
    const peca = it.iv ? { descricao: it.desc, codigo: it.codigo, imagem: it.iv.imagem, msg: () => IV.itemMsg(it) } : null;
    const toggle = () => { state.ui.itOpen = state.ui.itOpen === key ? null : key; render(true); };
    // Item manual fica sempre aberto: é preenchido campo a campo.
    if (it.iv && state.ui.itOpen !== key) {
      const pct = typeof it.pct === 'number' ? it.pct : it.iv.tabela ? Math.round((1 - num(it.preco) / it.iv.tabela) * 10000) / 100 : 0;
      const maxDesc = (iv.status && iv.status.user && iv.status.user.descontoMax) || 0;
      return h('div', { class: 'it it-c', title: 'Clique para mudar quantidade e preço', onclick: toggle },
        thumb(it.iv.imagem, 'sm', peca),
        h('div', { class: 'grow' },
          h('div', { class: 'it-n' }, it.desc),
          h('div', { class: 'meta' }, `${String(num(it.qtd)).replace('.', ',')} × ${F.brl(num(it.preco))}`,
            pct > 0 ? tag(`−${IV.pctBr(pct)}`, pct > maxDesc ? 'bad' : 'ok') : '',
            it.iv && num(it.qtd) > it.iv.estoque ? tag(`só ${it.iv.estoque} em estoque`, 'bad') : '')),
        h('span', { class: 'lt' }, F.brl(F.linha(it))));
    }
    paint();
    return h('div', { class: `it ${it.iv ? 'open' : ''}` },
      it.iv
        ? h('div', { class: 'it-top', title: 'Fechar', onclick: toggle }, thumb(it.iv.imagem, 'sm', peca), h('div', { class: 'it-d' }, it.desc, metaEl), remove)
        : [h('div', { class: 'it-top' }, input(it.desc, (v) => { it.desc = v; changed(); }, { placeholder: `Peça ${i + 1} (ex.: pastilha dianteira)` }), remove),
          h('div', { class: 'manual-extra' },
            input(it.marca, (v) => { it.marca = v; S.commit(c); }, { placeholder: 'Marca' }),
            select(it.tipo, [{ id: '', label: 'Tipo' }, { id: 'original', label: 'Original' }, { id: 'paralela', label: 'Paralela' }], (v) => { it.tipo = v; S.commit(c); }),
            input(it.codigo, (v) => { it.codigo = v; S.commit(c); }, { placeholder: 'Código' }))],
      h('div', { class: 'it-bottom' },
        h('div', { class: 'stepper' },
          h('button', { title: 'Menos', onclick: () => bump(-1) }, icon('minus')), qtyIn,
          h('button', { title: 'Mais', onclick: () => bump(1) }, icon('plus'))),
        money(it.preco, (v) => {
          if (it.iv && it.iv.tabela > 0) IV.fixaPct(it, IV.pctDoPreco(it, num(v))); else it.preco = num(v);
          it.pol = 'manual'; changed(); render(true);
        }),
        lineEl),
      it.iv && it.iv.tabela > 0 ? h('div', { class: 'it-desc' }, 'Desconto neste item',
        pctInput(Math.max(0, typeof it.pct === 'number' ? it.pct : 0), (v) => {
          IV.fixaPct(it, Math.max(0, Math.min(100, num(v)))); it.pol = 'manual'; changed(); render(true);
        })) : '',
      it.iv && it.ult ? ultLinha(it.ult, it.iv.id, 'Cliente') : '');
  }

  const polAtual = (c, d) => d.pol || c.polPadrao || { tipo: 'prazo' };

  function registraPol(c, pol) {
    c.polHist = [{ date: Date.now(), label: IV.polLabel(pol) }, ...(c.polHist || []).filter((x) => x.label !== IV.polLabel(pol))].slice(0, 5);
  }

  function cardCondicao(c, d) {
    const pol = polAtual(c, d);
    const max = iv.status && iv.status.user ? iv.status.user.descontoMax : null;
    const padrao = c.polPadrao && IV.polKey(c.polPadrao) === IV.polKey(pol);
    const escolhe = (nova) => {
      d.pol = nova;
      const n = IV.aplicaPolitica(d, nova, true);
      const semPct = nova.tipo === 'pers' && !IV.polPct(nova);
      if (!semPct) registraPol(c, nova);
      S.commit(c); render(true);
      toast(semPct ? 'Digite o desconto que vale para todos os itens.' : `Condição ${IV.polLabel(nova)}${n ? ` aplicada em ${n} ${n > 1 ? 'itens' : 'item'}` : ''}.`);
    };
    const ult = (c.polHist || []).filter((x) => x.label !== IV.polLabel(pol)).slice(0, 2);
    return h('div', { class: 'cond' },
      h('div', { class: 'cond-h' }, h('span', {}, 'Condição'),
        h('button', { class: `link ${padrao ? '' : 'muted'}`, title: padrao ? 'Clique para deixar de ser o padrão' : 'Os próximos orçamentos deste cliente já começam nesta condição', onclick: () => {
          c.polPadrao = padrao ? null : Object.assign({}, pol); S.commit(c); render(true);
          toast(padrao ? 'Cliente sem condição padrão.' : `${IV.polLabel(pol)} virou o padrão deste cliente.`);
        } }, icon(padrao ? 'check' : 'user'), padrao ? 'Padrão do cliente' : 'Fixar como padrão')),
      h('div', { class: 'pols' }, IV.POLITICAS.map((b) => {
        const alvo = b.tipo === 'pers' ? { tipo: 'pers', pct: pol.tipo === 'pers' ? pol.pct : ((c.polPadrao && c.polPadrao.tipo === 'pers' && c.polPadrao.pct) || 0) } : { tipo: b.tipo };
        const acima = max != null && b.tipo !== 'pers' && b.pct > max + 1e-9;
        return h('button', { class: `pol ${pol.tipo === b.tipo ? 'on' : ''}`, disabled: acima, title: acima ? `Acima do seu limite de desconto (${IV.pctBr(max)})` : '', onclick: () => escolhe(alvo) }, b.label);
      })),
      pol.tipo === 'pers' ? h('div', { class: 'cond-pers' }, 'Desconto em todos os itens',
        pctInput(pol.pct, (v) => escolhe({ tipo: 'pers', pct: Math.max(0, Math.min(100, num(v))) })),
        max != null && IV.polPct(pol) > max + 1e-9 ? tag(`limite ${IV.pctBr(max)}`, 'bad') : '') : '',
      pol.tipo === 'pers' ? h('div', { class: 'cond-ult' }, 'Ou mude o desconto item a item, abrindo o item acima.') : '',
      ult.length ? h('div', { class: 'cond-ult' }, `Antes: ${ult.map((x) => `${x.label} (${F.ddmm(x.date)})`).join(', ')}`) : '');
  }

  function cardOrcamento(c) {
    const d = c.draft;
    if (IV.aplicaPolitica(d, polAtual(c, d))) S.commit(c);
    const filled = d.items.filter((i) => i.desc || i.iv);
    const subEl = h('span', {});
    const totalEl = h('b', {});
    const ecoEl = h('span', {});
    const ecoRow = h('div', { class: 'tot-row' }, 'Desconto', ecoEl);
    const refreshTotals = () => {
      const t = F.quoteTotals(d);
      const e = IV.economia(d);
      subEl.textContent = F.brl(t.sub + e.valor);
      totalEl.textContent = F.brl(t.total);
      ecoEl.textContent = `− ${F.brl(e.valor)} (${IV.pctBr(e.pct)})`;
      ecoRow.style.display = e.valor > 0 ? '' : 'none';
    };
    refreshTotals();
    const setD = (k) => (v) => { d[k] = num(v); refreshTotals(); S.commit(c); refreshFechar(c); };

    const extTerm = () => `${(filled[0] && filled[0].desc) || ''} ${F.motoLabel(c.motos[0])}`.trim();
    const go = (url) => window.open(url, '_blank', 'noopener');

    const busca = () => [fecharBar(c), motoCitadaBar(c), listaCard(c, d), card('Buscar peça', 'search', '',
      logged() ? prodSearch(c, d) : h('div', { class: 'muted' }, 'Conecte ao Integra Vendas para buscar no estoque. Sem conexão, monte o orçamento com itens manuais.'),
      logged() ? maisCompradosRow(c) : '',
      logged() ? vitrineRow(c) : '',
      (() => {
        if (logged()) queueMicrotask(aprenderJunto);
        const ja = juntoAprendido();
        const sug = DZ.leveJunto(filled, ja.pares);
        const termo = (x) => {
          if (!x.de) return x.busca;
          const fam = (BS.motoNoTexto(x.de) || '').split(' ')[0];
          return fam ? `${x.busca} ${fam}` : x.busca;
        };
        return sug.length ? h('div', { class: 'chips quebra' }, h('span', { class: 'lead', title: ja.pares ? `Aprendido de ${ja.n} pedidos concluídos, mais as regras do balcão` : 'Regras do balcão (aprende com os pedidos concluídos a partir de 20 lidos)' }, 'Leve junto'),
          sug.map((x) => h('button', { class: 'chip', title: x.conf ? `Sai junto em ${Math.round(x.conf * 100)}% dos pedidos com ${x.de.split(' ').slice(0, 3).join(' ').toUpperCase()} (${x.sup} pedidos). Buscar "${termo(x)}"` : logged() ? `Buscar "${x.busca}" no estoque` : 'Adicionar como item manual', onclick: () => {
            if (logged()) { searchProd(c, termo(x), true); return; }
            d.items.push(Object.assign(blankItem(), { desc: x.label })); S.commit(c); render(true);
          } }, icon(logged() ? 'search' : 'plus'), x.label))) : '';
      })(),
      h('div', { class: 'row', style: 'margin-top:6px' },
        link('Item manual', () => { d.items.push(blankItem()); S.commit(c); render(true); }, 'plus'),
        h('span', { class: 'grow' }),
        link('Pesquisar fora', () => { state.ui.ext = !state.ui.ext; render(true); }, 'ext', 'muted')),
      state.ui.ext ? h('div', { class: 'acts' },
        btn('Google', () => go(`https://www.google.com/search?q=${encodeURIComponent(`${extTerm()} aplicação`)}`), 'sm'),
        btn('Mercado Livre', () => go(`https://lista.mercadolivre.com.br/${encodeURIComponent(extTerm().replace(/\s+/g, '-'))}`), 'sm'),
        btn('Riffel', () => go('https://www.riffel.com.br/buscador/'), 'sm'),
        btn('Cofap', () => go('https://mmcofap.com.br/'), 'sm')) : '')];

    const side = () => {
    const sis = logged() && d.items.some((i) => i.iv) ? pedidoSistema(c) : null;
    const list = h('div', { class: 'side-list' },
      h('div', { class: 'side-h' }, h('span', {}, 'Orçamento'), h('span', { class: 'row', style: 'gap:8px;text-transform:none;letter-spacing:0;font-weight:500' },
        filled.length ? `${filled.length} ${filled.length > 1 ? 'itens' : 'item'}` : '',
        d.items.length ? h('button', { class: 'link muted', title: 'Tirar todos os itens do orçamento', onclick: (e) => {
          const b = e.currentTarget;
          // Segundo clique confirma: um clique perdido não apaga o orçamento montado.
          if (!b.dataset.conf) {
            b.dataset.conf = '1'; b.textContent = 'Confirmar: limpar tudo'; b.classList.replace('muted', 'bad-c');
            setTimeout(() => { if (b.isConnected) { delete b.dataset.conf; b.textContent = 'Limpar'; b.classList.replace('bad-c', 'muted'); } }, 3000);
            return;
          }
          const n = d.items.length;
          d.items = []; d.desconto = 0;
          S.commit(c); render(true);
          toast(`${n} ${n > 1 ? 'itens tirados' : 'item tirado'} do orçamento.`);
        } }, 'Limpar') : '')),
      d.items.length ? h('div', {}, d.items.map((it, i) => itemRow(c, d, it, i, refreshTotals)))
        : h('div', { class: 'side-empty' }, logged() ? 'Busque a peça ao lado. Enter põe aqui.' : 'Adicione as peças com "Item manual".'),
      sis ? h('div', { class: 'side-cfg' }, cardCondicao(c, d), sis.campos) : '');
    const enviar = (cls) => btn('Enviar no chat', () => {
          const st = S.data.settings;
          const pol = polAtual(c, d);
          const eco = IV.economia(d);
          const avista = pol.tipo === 'av5' || pol.tipo === 'av3';
          const uniforme = d.items.every((i) => !i.iv || i.pol === IV.polKey(pol));
          const condicao = eco.valor <= 0 ? '' : avista ? (uniforme ? `à vista, ${IV.pctBr(IV.polPct(pol))} de desconto` : 'à vista') : `desconto de ${IV.pctBr(eco.pct)}`;
          insert(F.formatQuote(d, { loja: st.loja, pix: st.pix, validadeDias: Number(st.validadeDias) || 0, now: Date.now(), moto: F.motoLabel(c.motos[0]), condicao, economia: eco.valor }),
            'orcamento', `${filled.length} ${filled.length > 1 ? 'itens' : 'item'} · ${F.brl(F.quoteTotals(d).total)}`);
        }, cls, 'send');
    const jaEnviei = () => h('button', { class: 'btn', title: 'Registra o orçamento no histórico e agenda o follow-up (2h, D+1, D+3, D+7)', onclick: () => {
          const t = F.quoteTotals(d);
          c.quotes.push({ date: Date.now(), items: filled, frete: t.frete, desconto: t.desconto, total: t.total, condicao: IV.polLabel(polAtual(c, d)) });
          registraPol(c, polAtual(c, d));
          FU.cancelCadence(c);
          FU.setStage(c, 'orcamento', Date.now());
          c.stageSince = Date.now();
          c.followups.push(...FU.planCadence(Date.now()));
          c.draft = newDraft();
          S.commit(c); render();
          toast(`Orçamento de ${F.brl(t.total)} registrado. Follow-up agendado.`);
        } }, icon('clock'), 'Já enviei');
    return [list, filled.length ? h('div', { class: 'side-ft' },
      h('div', { class: 'totals' },
        h('div', { class: 'tot-row' }, 'Subtotal', subEl),
        ecoRow,
        h('div', { class: 'tot-row' }, 'Frete', money(d.frete, setD('frete'))),
        num(d.desconto) > 0 ? h('div', { class: 'tot-row' }, 'Desconto extra', money(d.desconto, setD('desconto'))) : '',
        h('div', { class: 'tot-big' }, 'Total', totalEl)),
      sis
        ? [h('div', { class: 'actions' }, sis.acoes, h('div', { class: 'sub-acts' }, enviar('sm'), jaEnviei())), sis.extra]
        : h('div', { class: 'actions' }, enviar('pri'), jaEnviei())) : ''];
    };
    // Cada coluna monta só a sua parte: montar a busca duas vezes trocaria o iv.fillDet por um de fora da tela.
    return { get busca() { return busca(); }, get side() { return side(); } };
  }

  // O que impede finalizar (erros) e o que vale conferir antes (avisos). Precisa de iv.lists carregado.
  function faltasPedido(c, finalizar = true) {
    const d = c.draft;
    const p = d.ped || { formaPagamentoId: '', transportadoraId: '', tipoFrete: 'CIF', observacao: '' };
    const L = iv.lists;
    const erros = [];
    const avisos = [];
    if (!c.iv || !c.iv.clienteId) erros.push('Vincule o cliente do sistema (acima).');
    const built = IV.buildItems(d, iv.status.user);
    erros.push(...built.errors);
    const det = { ...p, frete: d.frete };
    if (finalizar) erros.push(...IV.checkRequired(L.params, det));
    const forma = L.formas.find((f) => String(f.id) === String(p.formaPagamentoId));
    const total = F.quoteTotals(d).total;
    if (forma && forma.valor_minimo && total < forma.valor_minimo) erros.push(`${forma.nome} exige pedido mínimo de ${F.brl(forma.valor_minimo)}.`);
    if (!p.formaPagamentoId && !erros.some((e) => /pagamento/.test(e))) avisos.push('Forma de pagamento não escolhida.');
    if (String(d.frete || '').trim() === '') avisos.push(`Frete sem valor (${p.tipoFrete === 'FOB' ? 'FOB, por conta do cliente' : 'CIF, deixe 0 se for grátis'}).`);
    return { erros, avisos, built, det };
  }

  // Campos e botões do pedido no sistema moram no rodapé do orçamento, junto da condição e do total.
  function pedidoSistema(c) {
    const d = c.draft;
    const cur = d.pedidoId ? (c.pedidos || []).find((x) => x.id === d.pedidoId) : null;
    const head = h('div', { class: 'cond-h' }, h('span', {}, 'Pedido no sistema'), cur ? tag(`nº ${cur.numero}`, 'info') : tag('novo', 'acc'));
    {
      if (!iv.lists) {
        loadLists().then(() => render(true)).catch(() => {});
        return { campos: h('div', { class: 'ped' }, head, h('div', { class: 'busy' }, h('span', { class: 'spin' }), 'Carregando formas de pagamento…')), acoes: '', extra: '' };
      }
      d.ped = d.ped || { formaPagamentoId: '', transportadoraId: '', tipoFrete: 'CIF', observacao: '' };
      const p = d.ped;
      const setP = (k) => (v) => { p[k] = v; S.commit(c); refreshFechar(c); };
      const L = iv.lists;
      const total = F.quoteTotals(d).total;

      const submit = (finalizar, confirmed) => {
        const { erros: errs, built, det } = faltasPedido(c, finalizar);
        if (errs.length) { iv.err = errs.join('\n'); iv.errAt = 'ped'; render(true); return; }
        if (finalizar && !confirmed) { state.confirm = 'fin-draft'; render(true); return; }
        if (!d.pedidoId) {
          const mesmoCliente = (x) => (x.clienteId ? x.clienteId === c.iv.clienteId : (c.ivClientes || []).length <= 1);
          const orphan = (c.pedidos || []).slice().reverse().find((x) => !x.finalizado && !x.cancelado && !(x.itens || []).length && mesmoCliente(x));
          if (orphan) d.pedidoId = orphan.id;
        }
        busy(finalizar ? 'Finalizando pedido…' : 'Salvando orçamento no sistema…', async () => {
          const r = await ivCall('createOrder', { pedidoId: d.pedidoId, clienteId: c.iv.clienteId, items: built.items, detalhes: IV.detalhesPayload(det), finalizar });
          c.pedidos = c.pedidos || [];
          const rec = { id: r.id, numero: r.numero, total: r.total, finalizado: r.finalizado, date: Date.now(), itens: r.itens, clienteId: c.iv.clienteId, clienteNome: c.iv.nome };
          E.noteCliente(c, c.iv);
          const at = c.pedidos.findIndex((x) => x.id === r.id);
          if (at >= 0) c.pedidos[at] = rec; else c.pedidos.push(rec);
          d.pedidoId = r.finalizado ? null : r.id;
          if (!r.errors.length) {
            if (r.finalizado) { FU.setStage(c, 'separando', Date.now()); c.draft = newDraft(); }
            toast(`Pedido nº ${r.numero} ${r.finalizado ? 'finalizado' : 'salvo como orçamento'}${r.total != null ? ` · ${F.brl(r.total)}` : ''}.`);
          } else {
            iv.err = `Pedido nº ${r.numero} foi criado, mas: ${r.errors.join(' ')}\nConfira na web do vendedor.`;
          }
          S.commit(c);
        }, 'ped');
      };

      const razoes = E.razoes(c);
      return {
        campos: h('div', { class: 'ped' }, head,
          razoes.length > 1 && c.iv ? fld('Faturar para', select(String(c.iv.clienteId), razoes.map((r) => ({ id: String(r.clienteId), label: `${r.nome}${r.pedidos ? ` · ${r.pedidos} ped.` : ''}` })),
            (v) => useCliente(c, razoes.find((r) => String(r.clienteId) === v)))) : '',
          h('div', { class: 'two' },
            fld('Pagamento', select(String(p.formaPagamentoId), [{ id: '', label: '—' }, ...L.formas.map((f) => ({ id: String(f.id), label: f.nome }))], setP('formaPagamentoId'))),
            fld('Frete', select(p.tipoFrete, [{ id: 'CIF', label: 'CIF (loja)' }, { id: 'FOB', label: 'FOB (cliente)' }], setP('tipoFrete')))),
          L.transp.length ? fld('Transportadora', select(String(p.transportadoraId), [{ id: '', label: '—' }, ...L.transp.map((t) => ({ id: String(t.id), label: `${t.nome}${t.cidade ? ` – ${t.cidade}` : ''}` }))], setP('transportadoraId'))) : '',
          fld('Observação', h('textarea', { placeholder: 'Vai junto no pedido do sistema', onchange: (e) => setP('observacao')(e.target.value) }, p.observacao || ''))),
        acoes: [
          btn('Finalizar pedido', () => submit(true), fecharAtivo(c) ? 'pri pulse' : 'pri', 'check'),
          btn(cur ? `Atualizar nº ${cur.numero}` : 'Salvar no sistema', () => submit(false), '', 'download')],
        extra: [
          confirmBox('fin-draft', `Finalizar o pedido de ${F.brl(total)} para ${c.iv ? c.iv.nome : ''}? Ele segue para o faturamento e não poderá mais ser alterado daqui.`, 'Sim, finalizar', () => submit(true, true), 'ok'),
          busyFor('ped'), errFor('ped')],
      };
    }
  }

  function loadCompras(c) {
    const filtro = IV.FILTROS_PEDIDO.find((f) => f.id === state.ui.comprasFiltro) || IV.FILTROS_PEDIDO[0];
    iv.compras = { key: c.key, filtro: filtro.id, list: null };
    busy('Buscando compras no sistema…', async () => {
      const r = await api('GET', `pedidos/?pagina=1${filtro.status ? `&status=${filtro.status}` : ''}&pesquisa=${encodeURIComponent(c.iv.nome)}`);
      const list = IV.comprasDoCliente(r && r.pedidos, c.iv.nome);
      iv.compras = { key: c.key, filtro: filtro.id, list };
      let dirty = false;
      (c.pedidos || []).forEach((p) => {
        const m = list.find((x) => x.id === p.id);
        if (!m) return;
        if (m.cancelado && !p.cancelado) { p.cancelado = true; dirty = true; }
        if (m.finalizado && !p.finalizado) { p.finalizado = true; dirty = true; }
        if (m.total && m.total !== p.total) { p.total = m.total; dirty = true; }
      });
      if (dirty) S.commit(c);
    }, 'compras');
  }

  function repetir(c, p) {
    busy('Montando orçamento…', async () => {
      const r = await IV.repetirPedido(api, p.id, c.iv.clienteId, (step) => { iv.busy = step; render(true); });
      const d = c.draft;
      d.items = d.items.filter((i) => i.desc || i.iv);
      let n = 0;
      r.items.forEach((it) => { if (!d.items.some((i) => i.iv && i.iv.id === it.iv.id)) { d.items.push(it); n++; } });
      S.commit(c);
      toast(n ? `${n} ${n > 1 ? 'itens' : 'item'} do nº ${r.numero} no orçamento, com o preço de hoje.` : 'Os itens desse pedido já estão no orçamento.');
      if (r.faltando.length) iv.err = `Saiu de linha e não entrou: ${r.faltando.join(', ')}.`;
    }, 'compras');
  }

  function cardCompras(c) {
    if (!logged() || !c.iv || !c.iv.clienteId) return '';
    const mine = iv.compras && iv.compras.key === c.key ? iv.compras : null;
    const right = mine && mine.list ? tag(String(mine.list.length), 'acc') : '';
    return fold('compras', 'Compras no sistema', 'store', right, () => {
      if (!mine) { if (!iv.busy) queueMicrotask(() => loadCompras(c)); return busyFor('compras') || h('div', { class: 'busy' }, h('span', { class: 'spin' }), 'Buscando compras no sistema…'); }
      const st = (p) => { const x = IV.situacao(p); return tag(x.label, x.cls); };
      const filtro = mine.filtro || 'todos';
      const vazio = { todos: 'Nenhum pedido recente', orc: 'Nenhum pedido em orçamento', conc: 'Nenhum pedido concluído recente', canc: 'Nenhum pedido cancelado recente' }[filtro];
      return [
        h('div', { class: 'chips fit' }, IV.FILTROS_PEDIDO.map((f) => h('button', { class: `chip ${f.id === filtro ? 'on' : ''}`, disabled: !!iv.busy,
          onclick: () => { if (f.id === filtro) return; state.ui.comprasFiltro = f.id; loadCompras(c); } }, f.label))),
        mine.list && !mine.list.length ? h('div', { class: 'muted', style: 'padding:6px 0' }, `${vazio} de ${c.iv.nome}.`) : '',
        mine.list && mine.list.length ? h('div', { class: 'list' }, mine.list.map((p) => h('div', { class: `li ${pedAberto(c, p) ? 'sel' : ''}` },
          h('div', { class: `ibox ${p.cancelado ? '' : 'acc'}` }, icon('box')),
          h('div', { class: 'main click', title: 'Ver os itens ao lado', onclick: () => abrePedido(c, p) },
            h('div', { class: 'row' }, h('span', { class: 't1' }, `nº ${p.numero}`), st(p)),
            h('div', { class: 'tiny' }, `${F.brl(p.total)} · ${String(p.data || '').replace(/-/g, '/')}${p.forma ? ` · ${p.forma}` : ''}`),
            (() => {
              const x = IV.situacao(p);
              const dias = IV.diasDesde(p.data);
              if (!x.orc || dias == null) return '';
              return h('div', { class: `tiny ${dias > 2 ? 'warn-c' : ''}` }, dias > 2 ? `Parado ${IV.idade(dias)}: vale cobrar o cliente` : `Em orçamento ${IV.idade(dias)}`);
            })()),
          btn('Repetir', () => repetir(c, p), 'sm', 'cart')))) : '',
        mine.list ? h('div', { class: 'row', style: 'margin-top:6px' }, h('span', { class: 'tiny grow' }, 'Repetir monta o orçamento com o preço de hoje; nada é criado no sistema.'),
          link('Atualizar', () => loadCompras(c), 'activity', 'muted')) : '',
        busyFor('compras'), errFor('compras'),
        !mine.list && !iv.busy ? btn('Tentar de novo', () => loadCompras(c), 'sm') : '',
      ];
    });
  }

  // A empresa pode exigir forma de pagamento; sem ela a API recusa a finalização. A API só troca os campos enviados.
  function finPagamento(c, p) {
    if (!iv.lists) { loadLists().then(() => render(true)).catch(() => {}); return h('div', { class: 'tiny mt' }, 'Carregando formas de pagamento…'); }
    state.finPag = state.finPag || {};
    const d = c.draft;
    if (state.finPag[p.id] == null) state.finPag[p.id] = d && d.pedidoId === p.id && d.ped ? String(d.ped.formaPagamentoId || '') : '';
    return h('div', { class: 'mt' }, fld('Forma de pagamento', select(state.finPag[p.id], [{ id: '', label: 'Manter a do pedido' }, ...iv.lists.formas.map((f) => ({ id: String(f.id), label: f.nome }))],
      (v) => { state.finPag[p.id] = v; if (d && d.pedidoId === p.id) { d.ped = d.ped || {}; d.ped.formaPagamentoId = v; S.commit(c); } })));
  }

  // Pedido do sistema aberto na coluna do orçamento, só leitura; itens guardados enquanto a aba vive.
  const pedDet = new Map();
  const pedAberto = (c, p) => !!(state.ui.pedView && state.ui.pedView.ck === c.key && state.ui.pedView.id === p.id);
  function abrePedido(c, p, onLoad) {
    if (pedAberto(c, p)) { state.ui.pedView = null; render(true); return; }
    const v = state.ui.pedView = { ck: c.key, id: p.id, p, err: '' };
    render(true);
    if (pedDet.has(p.id) || !logged()) return;
    v.loading = true;
    api('GET', `pedidos/${p.id}`).then((full) => {
      pedDet.set(p.id, full);
      if (onLoad) onLoad(full);
    }).catch((e) => { v.err = e.message; }).finally(() => { v.loading = false; render(true); });
  }

  // Quanto o cliente pagou da última vez: busca o pedido de origem em segundo plano.
  const pedPend = new Set();
  function ultLinha(u, produtoId, quem) {
    if (!u || !u.id) return '';
    const full = pedDet.get(u.id);
    if (!full && logged() && !pedPend.has(u.id)) {
      pedPend.add(u.id);
      api('GET', `pedidos/${u.id}`).then((r) => { pedDet.set(u.id, r); render(true); }).catch(() => {});
    }
    const pg = full && IV.pagoNoPedido(full, produtoId);
    const q = String(pg ? pg.qtd : u.qtd).replace('.', ',');
    const pct = pg && pg.desconto > 0 ? ` (−${String(+pg.desconto.toFixed(2)).replace('.', ',')}%)` : pg && pg.acrescimo > 0 ? ` (+${String(+pg.acrescimo.toFixed(2)).replace('.', ',')}%)` : '';
    return h('div', { class: 'ult-c', title: pg ? `Tabela na época: ${F.brl(pg.tabela)}` : '' }, icon('clock'),
      h('span', {}, `${quem} levou ${q} `, pg ? h('b', {}, `a ${F.brl(pg.unit)}`) : '', pct, ` no nº ${u.numero} em ${u.data}`));
  }

  function sidePedido(c, v) {
    const p = v.p;
    const full = pedDet.get(p.id);
    const fechar = () => { state.ui.pedView = null; render(true); };
    const pctTxt = (n) => String(+Number(n).toFixed(2)).replace('.', ',');
    const st = p.cancelado ? tag('cancelado', 'bad') : full && full.status_pedido ? tag(full.status_pedido, full.finalizado ? 'ok' : 'info') : '';
    const head = h('div', { class: 'side-h' }, h('span', { class: 'row', style: 'gap:6px;white-space:nowrap;min-width:0' }, `Pedido ${p.numero}`, st),
      link('Voltar', fechar, 'x', 'muted'));
    if (!full) {
      return [h('div', { class: 'side-list' }, head, h('div', { class: 'side-empty' },
        v.loading ? [h('span', { class: 'spin' }), ' Buscando itens do pedido…'] : v.err ? `Não deu para abrir o pedido: ${v.err}` : logged() ? '' : 'Conecte ao Integra Vendas para ver os itens.'))];
    }
    const d = full.detalhe || {};
    const itens = full.itens || [];
    const r2 = (n) => Math.round(n * 100) / 100;
    const sub = r2(itens.reduce((a, x) => a + r2((Number(x.valor_unitario) || 0) * (Number(x.quantidade) || 0)), 0));
    const liq = r2(itens.reduce((a, x) => a + (Number(x.preco_liquido) || 0), 0));
    const desc = r2(sub - liq);
    const pcts = [...new Set(itens.map((x) => Number(x.desconto) || 0))];
    const frete = Number(d.valor_frete) || 0;
    const kv = (k, val) => (val || val === 0 ? h('div', { class: 'kv' }, `${k}: `, h('b', {}, val)) : '');
    const list = h('div', { class: 'side-list' }, head,
      itens.length ? h('div', {}, itens.map((x) => {
        const q = Number(x.quantidade) || 0;
        const peca = x.imagem ? { descricao: x.descricao, codigo: x.codigo, imagem: x.imagem, rotulo: `pedido nº ${p.numero}`, msg: () => IV.itemPedidoMsg(x, { numero: p.numero, data: full.data_criacao }) } : null;
        return h('div', { class: 'it it-c ro', title: `Tabela: ${F.brl(x.valor_unitario)}` },
          thumb(x.imagem, 'sm', peca),
          h('div', { class: 'grow' },
            h('div', { class: 'it-n' }, x.descricao || `Produto ${x.produto_id}`),
            h('div', { class: 'meta' }, `${String(q).replace('.', ',')} × ${F.brl(q ? r2(x.preco_liquido / q) : 0)}`,
              x.desconto > 0 ? tag(`−${pctTxt(x.desconto)}%`, 'ok') : '',
              x.acrescimo > 0 ? tag(`+${pctTxt(x.acrescimo)}%`, 'warn') : '',
              x.excluido ? tag('fora de linha', 'bad') : '')),
          h('span', { class: 'lt' }, F.brl(x.preco_liquido)));
      })) : h('div', { class: 'side-empty' }, 'Pedido sem itens.'),
      h('div', { class: 'side-cfg det' },
        h('div', { class: 'cond-h' }, 'Detalhes'),
        kv('Emissão', String(full.data_criacao || '').replace(/-/g, '/')),
        kv('Pagamento', d.forma_pagamento),
        kv('Frete', d.tipo_frete),
        kv('Transportadora', d.transportadora),
        kv('Vendedor', d.vendedor),
        kv('Observação', d.observacao)));
    const pode = logged() && !p.cancelado;
    const ft = h('div', { class: 'side-ft' },
      h('div', { class: 'totals' },
        h('div', { class: 'tot-row' }, 'Subtotal', h('span', {}, F.brl(sub))),
        desc > 0.004 ? h('div', { class: 'tot-row' }, 'Desconto', h('span', {}, `− ${F.brl(desc)}${pcts.length === 1 && pcts[0] > 0 ? ` (${pctTxt(pcts[0])}%)` : ''}`)) : '',
        frete > 0 ? h('div', { class: 'tot-row' }, 'Frete', h('span', {}, F.brl(frete))) : '',
        h('div', { class: 'tot-big' }, 'Total', h('b', {}, F.brl(full.valor_total)))),
      h('div', { class: 'actions' },
        pode ? btn('Pôr no orçamento', () => { state.ui.pedView = null; repetir(c, p); }, 'pri', 'cart') : '',
        h('div', { class: 'sub-acts' },
          btn('Resumo', () => insert(IV.formatPedido(Object.assign({}, p, { itens, total: full.valor_total }), { loja: S.data.settings.loja, pix: S.data.settings.pix }), 'pedido', `nº ${p.numero}`), 'sm', 'send'),
          logged() ? btn('PDF', () => busy('Gerando PDF…', async () => {
            const { dataUrl } = await ivCall('pdf', { id: p.id });
            h('a', { href: dataUrl, download: `pedido-${p.numero}.pdf` }).click();
            toast('PDF baixado. Anexe na conversa pelo clipe 📎.');
          }, 'pedv'), 'sm', 'download') : ''),
        btn('Voltar ao orçamento', fechar, 'sm ghost')),
      busyFor('pedv'), errFor('pedv'));
    return [list, ft];
  }

  function cardHistorico(c) {
    const pedidos = (c.pedidos || []).slice(-5).reverse();
    const quotes = c.quotes.slice(-3).reverse();
    if (!pedidos.length && !quotes.length) return '';
    const status = (p) => (p.cancelado ? tag('cancelado', 'bad') : p.finalizado ? tag('finalizado', 'ok') : tag('orçamento', 'info'));
    return card('Histórico', 'clock', '',
      h('div', { class: 'list' },
        pedidos.map((p) => h('div', { class: `li ${pedAberto(c, p) ? 'sel' : ''}`, style: 'flex-wrap:wrap' },
          h('div', { class: `ibox ${p.cancelado ? '' : 'acc'}` }, icon('box')),
          h('div', { class: 'main click', title: 'Ver os itens ao lado', onclick: () => abrePedido(c, p, (full) => {
            p.itens = full.itens || [];
            if (full.valor_total != null) p.total = full.valor_total;
            S.commit(c);
          }) },
            h('div', { class: 'row' }, h('span', { class: 't1' }, `Pedido nº ${p.numero}`), status(p)),
            h('div', { class: 'tiny' }, `${p.total != null ? F.brl(p.total) : '—'} · ${F.ddmm(p.date)}${p.itens ? ` · ${p.itens.length} ${p.itens.length === 1 ? 'item' : 'itens'}` : ''}`),
            p.clienteNome && (c.ivClientes || []).length > 1 ? h('div', { class: 'tiny ellipsis' }, p.clienteNome) : ''),
          h('span', { class: 'chev-r' }, icon('right')),
          p.cancelado ? '' : h('div', { class: 'acts', style: 'width:100%;padding-left:44px;margin-top:4px' },
            p.itens && p.itens.length ? btn('Resumo', () => insert(IV.formatPedido(p, { loja: S.data.settings.loja, pix: S.data.settings.pix }), 'pedido', `nº ${p.numero}`), 'sm', 'send') : '',
            logged() ? btn('PDF', () => busy('Gerando PDF…', async () => {
              const { dataUrl } = await ivCall('pdf', { id: p.id });
              h('a', { href: dataUrl, download: `pedido-${p.numero}.pdf` }).click();
              toast('PDF baixado. Anexe na conversa pelo clipe 📎.');
            }, 'hist'), 'sm', 'download') : '',
            logged() && !p.finalizado ? btn('Finalizar', ask(`fin:${p.id}`), 'sm', 'check') : '',
            logged() && !p.finalizado ? btn('Cancelar', ask(`cancel:${p.id}`), 'sm danger', 'x') : ''),
          h('div', { style: 'width:100%' },
            confirmBox(`fin:${p.id}`, [`Finalizar o pedido nº ${p.numero}? Ele segue para o faturamento.`, finPagamento(c, p)], 'Sim, finalizar', () => busy('Finalizando pedido…', async () => {
              const forma = (state.finPag || {})[p.id];
              if (forma) await api('PUT', `pedidos/atualizar-detalhes/${p.id}`, { forma_pagamento_id: Number(forma) });
              await api('PUT', `pedidos/finalizar/${p.id}`);
              const full = await api('GET', `pedidos/${p.id}`);
              Object.assign(p, { finalizado: true, total: full.valor_total, itens: (full.itens || []).filter((x) => !x.excluido) });
              if (c.draft && c.draft.pedidoId === p.id) c.draft.pedidoId = null;
              FU.setStage(c, 'separando', Date.now());
              S.commit(c); toast(`Pedido nº ${p.numero} finalizado.`);
            }, 'hist'), 'ok'),
            confirmBox(`cancel:${p.id}`, `Cancelar o pedido nº ${p.numero}? Ele não vai para o faturamento.`, 'Sim, cancelar', () => busy('Cancelando pedido…', async () => {
              await api('PUT', `pedidos/cancelar/${p.id}`);
              p.cancelado = true;
              if (c.draft && c.draft.pedidoId === p.id) c.draft.pedidoId = null;
              S.commit(c); toast(`Pedido nº ${p.numero} cancelado.`);
            }, 'hist'), 'danger fill')))),
        quotes.map((q) => h('div', { class: 'li' },
          h('div', { class: 'ibox' }, icon('file')),
          h('div', { class: 'main' }, h('div', { class: 't1' }, `Orçamento ${F.brl(q.total)}`),
            h('div', { class: 'tiny ellipsis' }, `${F.ddmm(q.date)} · ${(q.items || []).map((i) => i.desc).join(', ')}`))))),
      busyFor('hist'), errFor('hist'));
  }

  function viewVenda(c) {
    const linked = logged() && c.iv && c.iv.clienteId;
    return [
      linked ? cardOrcamento(c).busca : '',
      logged() ? cardCliente(c)
        : iv.status ? h('div', { class: 'banner' }, icon('link'), h('span', { class: 'grow' }, 'Conecte ao Integra Vendas para buscar estoque e tirar pedido daqui.'),
          btn('Conectar', () => { state.tab = 'config'; render(); }, 'sm pri')) : '',
      linked ? '' : cardOrcamento(c).busca,
      cardCompras(c),
      cardHistorico(c),
    ];
  }

  // ---------- Conversa: Follow-up ----------

  function viewFollow(c) {
    const now = Date.now();
    const list = pendingOf(c);
    const mine = S.data.waitlist.filter((w) => w.contactKey === c.key && w.status === 'aguardando');
    const pecaIn = h('input', { placeholder: 'Peça em falta (ex.: coroa CG 160)', onkeydown: (e) => { if (e.key === 'Enter') addWait(); } });
    const addWait = () => {
      const peca = pecaIn.value.trim();
      if (!peca) return;
      S.data.waitlist.push({ id: crypto.randomUUID(), peca, contactKey: c.key, createdAt: Date.now(), status: 'aguardando' });
      S.commit(c); S.save('waitlist'); render();
      toast('Você será lembrado quando marcar a peça como chegou (aba Hoje).');
    };

    return [
      card('Próximos contatos', 'bell',
        list.length ? link('Cliente respondeu', () => { FU.cancelCadence(c); S.commit(c); render(); toast('Cadência parada.'); }, 'pause', 'muted') : '',
        list.length ? list.map((f, idx) => h('div', { class: `fu ${f.due <= now ? 'late' : idx === 0 ? 'next' : ''}` },
          h('span', { class: 'node' }),
          h('div', { class: 'row' }, h('span', { class: 't1' }, f.label), h('span', { class: 'grow' }),
            tag(rel(f.due, now), f.due <= now ? 'bad' : idx === 0 ? 'acc' : '')),
          h('div', { class: 'quote' }, F.fill(f.text, S.vars(c))),
          h('div', { class: 'row' },
            btn('Inserir', () => insert(F.fill(f.text, S.vars(c)), f.kind === 'aviso' ? 'aviso' : 'followup', f.label), 'sm pri', 'send'),
            btn('Feito', () => { f.status = 'feito'; f.doneAt = Date.now(); S.commit(c); render(); }, 'sm', 'check'),
            btn('+1 dia', () => { f.due = Math.max(f.due, now) + FU.DAY; S.commit(c); render(); }, 'sm ghost'))))
          : empty('bell', 'Nenhum follow-up agendado', 'A cadência lembra você de voltar ao cliente em 2h, 1, 3 e 7 dias.',
            btn('Iniciar cadência', () => { c.followups.push(...FU.planCadence(now)); S.commit(c); render(); }, 'pri', 'clock'))),
      card('Avisar quando chegar', 'box', mine.length ? tag(String(mine.length)) : '',
        h('div', { class: 'row' }, pecaIn, btn('Adicionar', addWait, 'sm', 'plus')),
        mine.length ? h('div', { class: 'list mt' }, mine.map((w) => h('div', { class: 'li' },
          h('div', { class: 'main' }, h('div', { class: 't1' }, w.peca), h('div', { class: 'tiny' }, `esperando desde ${F.ddmm(w.createdAt)}`)),
          h('button', { class: 'x-btn', title: 'Remover', onclick: () => { w.status = 'cancelado'; S.save('waitlist'); render(); } }, icon('x'))))) : ''),
    ];
  }

  // ---------- Conversa: Ficha ----------

  function motoCard(c, m, i) {
    const now = Date.now();
    m.maint = m.maint || {};
    return h('div', { class: 'card' },
      h('div', { class: 'card-h' }, h('div', { class: 'ibox acc' }, icon('bike')),
        h('div', { class: 'grow' }, input(m.modelo, (v) => { m.modelo = v; S.commit(c); render(true); }, { list: 'mz-motos', placeholder: 'Modelo da moto (ex.: CG 160 Titan)' })),
        h('button', { class: 'x-btn', title: 'Remover moto', onclick: () => { c.motos.splice(i, 1); S.commit(c); render(); } }, icon('trash'))),
      h('div', { class: 'grid2' },
        fld('Ano', input(m.ano, (v) => { m.ano = v; S.commit(c); }, { inputmode: 'numeric' })),
        fld('Placa', input(m.placa, (v) => { m.placa = v.toUpperCase(); S.commit(c); })),
        fld('Km atual', input(m.km, (v) => { m.km = num(v); S.commit(c); }, { inputmode: 'numeric' })),
        fld('Km por mês', input(m.kmMes, (v) => { m.kmMes = num(v); S.commit(c); render(true); }, { inputmode: 'numeric', placeholder: 'motoboy ~3000' }))),
      h('div', { class: 'sub-h' }, h('span', {}, 'Manutenção'), h('span', { style: 'text-transform:none;letter-spacing:0;font-weight:500' }, 'última troca')),
      FU.MAINT.map((rule) => {
        const rec = m.maint[rule.id];
        const due = FU.nextMaintenance(rec, m.kmMes, rule);
        const soon = due != null && due <= now + 7 * FU.DAY;
        return [
          h('div', { class: 'maint' },
            h('span', {}, rule.label[0].toUpperCase() + rule.label.slice(1)),
            input(toISODate(rec && rec.date), (v) => {
              const date = fromISODate(v);
              if (date) m.maint[rule.id] = { date }; else delete m.maint[rule.id];
              S.commit(c); render(true);
            }, { type: 'date', title: 'Data da última troca' }),
            h('span', { class: `due ${soon ? 'soon' : ''}` }, due ? `próx. ${F.ddmm(due)}` : '—')),
          soon ? h('div', { style: 'text-align:right;margin-bottom:4px' }, btn(`Lembrar ${rule.label}`, () => insert(F.fill(`Oi {nome}! Pelas nossas contas a {moto} já está na hora de ${rule.label}. Quer que eu separe pra você?`, S.vars(c, { moto: F.motoLabel(m) })), 'manutencao', `${rule.label} · ${F.motoLabel(m)}`), 'sm pri', 'send')) : '',
        ];
      }));
  }

  const ENV_IC = { preco: 'store', orcamento: 'cart', pedido: 'file', followup: 'bell', resposta: 'zap', manutencao: 'wrench', aviso: 'box', outro: 'chat' };

  function viewEnvios(c) {
    const all = (c.enviados || []).slice().reverse();
    const kinds = [...new Set(all.map((e) => e.kind))];
    const list = state.envKind ? all.filter((e) => e.kind === state.envKind) : all;
    const st = (e) => (e.status === 'enviado' ? tag(`enviado ${F.ddmm(e.sentAt)} ${new Date(e.sentAt).toTimeString().slice(0, 5)}`, 'ok')
      : e.status === 'inserido' ? tag('na caixa, não enviado', 'warn') : tag('não enviado', ''));
    if (!all.length) {
      return h('div', { class: 'card' }, empty('send', 'Nada enviado ainda', 'Preços, orçamentos, pedidos e respostas que você colocar na conversa pelo painel ficam registrados aqui, com a confirmação de envio.'));
    }
    const sent = all.filter((e) => e.status === 'enviado').length;
    return card('Enviado no chat', 'send', tag(`${sent} de ${all.length} enviados`, 'acc'),
      kinds.length > 1 ? h('div', { class: 'chips' },
        h('button', { class: `chip ${state.envKind ? '' : 'on'}`, onclick: () => { state.envKind = ''; render(true); } }, 'Tudo'),
        kinds.map((k) => h('button', { class: `chip ${state.envKind === k ? 'on' : ''}`, onclick: () => { state.envKind = k; render(true); } }, E.KINDS[k]))) : '',
      h('div', { class: 'list' }, list.map((e) => {
        const open = !!state.ui[`env:${e.id}`];
        return h('div', { class: 'li', style: 'flex-wrap:wrap;align-items:flex-start' },
          h('div', { class: `ibox ${e.status === 'enviado' ? 'ok' : ''}` }, icon(ENV_IC[e.kind] || 'chat')),
          h('div', { class: 'main' },
            h('div', { class: 'row' }, h('span', { class: 't1 ellipsis grow' }, e.label || E.KINDS[e.kind]), st(e)),
            h('div', { class: 'tiny' }, `${E.KINDS[e.kind]} · ${F.ddmm(e.at)} ${new Date(e.at).toTimeString().slice(0, 5)}`),
            h('div', { class: `quote ${open ? '' : 'clamp'}`, style: 'white-space:pre-wrap;cursor:pointer', title: open ? '' : 'Ver a mensagem inteira',
              onclick: () => { state.ui[`env:${e.id}`] = !open; render(true); } }, e.text),
            h('div', { class: 'row' },
              btn('Inserir de novo', () => insert(e.text, e.kind, e.label), 'sm', 'send'),
              btn('Copiar', () => { navigator.clipboard.writeText(e.text).then(() => toast('Mensagem copiada.')).catch(() => {}); }, 'sm ghost'))));
      })),
      h('div', { class: 'row', style: 'margin-top:8px' }, h('span', { class: 'tiny grow' }, 'O envio é confirmado quando a mensagem aparece na conversa.'),
        link('Limpar histórico', ask('env-wipe'), 'trash', 'muted')),
      confirmBox('env-wipe', `Apagar o histórico de mensagens de ${c.name}? Não mexe na conversa do WhatsApp.`, 'Apagar', () => { c.enviados = []; S.commit(c); render(); }, 'danger fill'));
  }

  // Moto que o cliente citou e a Ficha não tem: um clique cadastra; "não é dele" cala a sugestão (lojista encaminha pedido de terceiros).
  let citadas = { chat: '', lista: [], vistas: new Map(), sig: '' };
  function motoCitadaBar(c) {
    if (citadas.chat !== state.chat) return '';
    const novas = BS.motosNovas(citadas.lista, (c.motos || []).map((m) => m.modelo), c.motosIgnoradas);
    if (!novas.length) return '';
    const m = novas[0];
    const nome = BS.nomeMoto(m, MZ.data.MOTOS);
    const fam = m.split(' ')[0].toUpperCase();
    return h('div', { class: 'moto-cit' }, icon('bike'),
      h('span', { class: 'grow' }, 'Cliente citou ', h('b', {}, fam), ', que não está na Ficha.'),
      h('button', { class: 'btn sm', title: `Cadastrar "${nome}" na Ficha (dá para ajustar modelo e ano lá)`, onclick: () => {
        c.motos.push({ modelo: nome, ano: '', placa: '', km: '', kmMes: '', maint: {} });
        S.commit(c); render(true);
        toast(`${nome} na Ficha. Confira modelo e ano na aba Ficha.`);
      } }, icon('plus'), 'Adicionar à Ficha'),
      h('button', { class: 'link muted', title: 'A moto é de outra pessoa: não sugerir de novo para este cliente', onclick: () => {
        c.motosIgnoradas = [...(c.motosIgnoradas || []), m.split(' ')[0]];
        S.commit(c); render(true);
      } }, 'não é dele'));
  }

  // Cliente pediu para fechar: mostra o que falta e destaca "Finalizar pedido". Finalizar continua no clique do vendedor.
  let fechar = { chat: '', hora: 0, texto: '', sig: '' };
  function fecharAtivo(c) {
    if (fechar.chat !== state.chat || !fechar.hora) return false;
    if ((c.fecharVisto || 0) >= fechar.hora) return false;
    return !(c.pedidos || []).some((x) => x.finalizado && (x.date || 0) >= fechar.hora);
  }
  // Pagamento e frete mudam sem render (o foco fica no campo): só a faixa é refeita.
  function refreshFechar(c) {
    const old = shadow && shadow.querySelector('.fechar');
    if (old) old.replaceWith(fecharBar(c) || document.createTextNode(''));
  }
  function fecharBar(c) {
    if (!fecharAtivo(c)) return '';
    const d = c.draft;
    const itens = d.items.filter((i) => i.desc || i.iv);
    let lista;
    if (!logged()) lista = [['bad', 'Conecte ao Integra Vendas para tirar o pedido.']];
    else if (!itens.length) lista = [['bad', 'Orçamento vazio: ponha as peças (Cotar na mensagem do cliente).']];
    else if (!iv.lists) { loadLists().then(() => render(true)).catch(() => {}); lista = [['', 'Carregando formas de pagamento…']]; }
    else {
      const f = faltasPedido(c);
      lista = [...f.erros.map((e) => ['bad', e]), ...f.avisos.map((a) => ['warn', a])];
      if (!lista.length) lista = [['ok', `Tudo pronto: ${itens.length} ${itens.length > 1 ? 'itens' : 'item'}, ${F.brl(F.quoteTotals(d).total)}. Confira e clique Finalizar pedido.`]];
    }
    const pronto = lista.every(([k]) => k !== 'bad');
    return h('div', { class: 'fechar' },
      h('div', { class: 'row' }, icon('check'),
        h('span', { class: 'grow' }, h('b', {}, 'Cliente quer fechar: '), h('span', { class: 'muted' }, `"${fechar.texto.length > 70 ? `${fechar.texto.slice(0, 70)}…` : fechar.texto}"`)),
        h('button', { class: 'link muted', title: 'Já tratei esse pedido: esconder até o cliente pedir de novo', onclick: () => { c.fecharVisto = fechar.hora; S.commit(c); render(true); } }, 'já resolvi')),
      h('ul', {}, lista.map(([k, t]) => h('li', { class: k ? `${k}-c` : '' }, t))),
      pronto && logged() && itens.length ? h('button', { class: 'btn sm', onclick: () => {
        const b = shadow.querySelector('.btn.pulse');
        if (b) b.scrollIntoView({ block: 'center', behavior: 'smooth' });
      } }, icon('check'), 'Ir para Finalizar pedido') : '');
  }

  function viewFicha(c) {
    return [
      motoCitadaBar(c),
      h('div', { class: 'card' }, fld('Tipo de cliente', select(c.tipo, [
        { id: 'particular', label: 'Particular' }, { id: 'motoboy', label: 'Motoboy' },
        { id: 'oficina', label: 'Oficina' }, { id: 'lojista', label: 'Lojista' },
      ], (v) => { c.tipo = v; S.commit(c); }))),
      c.motos.map((m, i) => motoCard(c, m, i)),
      h('button', { class: 'btn dashed', style: 'margin-bottom:10px', onclick: () => { c.motos.push({ modelo: '', ano: '', placa: '', km: '', kmMes: '', maint: {} }); S.commit(c); render(); } },
        icon('plus'), c.motos.length ? 'Adicionar outra moto' : 'Cadastrar a moto do cliente'),
      h('datalist', { id: 'mz-motos' }, MZ.data.MOTOS.map((m) => h('option', { value: m }))),
      card('Notas', 'note', '',
        h('textarea', { placeholder: 'Condição combinada, preferência de marca, oficina que indicou...', onchange: (e) => { c.notes = e.target.value; S.commit(c); } }, c.notes || '')),
    ];
  }

  function renderCliente() {
    if (!state.chat) return h('div', { class: 'empty big' }, h('div', { class: 'ic' }, icon('chat')), h('b', {}, 'Nenhuma conversa aberta'), 'Abra uma conversa no WhatsApp para ver a ficha do cliente, montar orçamento e tirar pedido.');
    const c = cur;
    const views = { venda: viewVenda, follow: viewFollow, envios: viewEnvios, ficha: viewFicha };
    return views[state.sub](c);
  }

  // ---------- Hoje ----------

  function endOfToday() {
    const d = new Date(); d.setHours(23, 59, 59, 999); return d.getTime();
  }

  function contatoDoCliente(nome) {
    if (!nome) return null;
    return Object.values(S.data.contacts).find((c) => (c.iv && IV.mesmoCliente(c.iv.nome, nome)) || (c.ivClientes || []).some((r) => IV.mesmoCliente(r.nome, nome))) || null;
  }

  function personRow(c, subtitle, right) {
    return h('div', { class: 'li click', onclick: () => openContact(c) },
      avatar(c.name, 'sm'),
      h('div', { class: 'main' }, h('div', { class: 't1 ellipsis' }, c.name), h('div', { class: 'tiny ellipsis' }, subtitle)),
      right || '', h('span', { class: 'chev-r' }, icon('right')));
  }

  function waitGroups() {
    const waiting = {};
    S.data.waitlist.filter((w) => w.status === 'aguardando').forEach((w) => {
      const k = w.peca.trim().toLowerCase();
      (waiting[k] = waiting[k] || { key: k, peca: w.peca, list: [] }).list.push(w);
      if (w.produtoId) waiting[k].produtoId = w.produtoId;
    });
    return Object.values(waiting);
  }

  // Uma busca por peça esperada, em sequência (a API limita a 20 req/s); repete no máximo a cada 5 min.
  // Lê aos poucos os pedidos concluídos (a API limita a frequência) e guarda só os tipos de peça de cada um.
  let juntoCache = null;
  function juntoAprendido() {
    if (!juntoCache) {
      const ls = Object.values(S.data.junto.lidos);
      juntoCache = { n: ls.length, pares: ls.length >= 20 ? DZ.aprenderJunto(ls) : null };
    }
    return juntoCache;
  }
  function aprenderJunto() {
    const J = S.data.junto;
    if (!logged() || iv.juntoP || Date.now() - (J.at || 0) < 6 * 36e5) return;
    const LOTE = 60;
    const espera = (ms) => new Promise((r) => setTimeout(r, ms));
    iv.juntoP = (async () => {
      const novos = [];
      for (let pag = 1; pag <= 10 && novos.length < LOTE; pag++) {
        const r = await api('GET', `pedidos/?pagina=${pag}&status=5`).catch(() => null);
        const ps = (r && r.pedidos) || [];
        if (!ps.length) break;
        ps.forEach((p) => { if (p.pedido_id && !J.lidos[p.pedido_id] && !novos.includes(p.pedido_id)) novos.push(p.pedido_id); });
        await espera(400);
      }
      for (const id of novos.slice(0, LOTE)) {
        const ped = await api('GET', `pedidos/${id}`).catch(() => null);
        if (ped) J.lidos[id] = [...new Set((ped.itens || []).filter((i) => !i.excluido).map((i) => DZ.tipoPeca(i.descricao)).filter(Boolean))];
        await espera(500);
      }
      const ids = Object.keys(J.lidos);
      ids.slice(0, Math.max(0, ids.length - 500)).forEach((k) => delete J.lidos[k]);
      // Sobrou pedido por ler: volta em 10 min em vez de 6 h.
      J.at = novos.length >= LOTE ? Date.now() - 6 * 36e5 + 10 * 60e3 : Date.now();
      await S.save('junto');
      juntoCache = null;
      if (novos.length && state.open) render(true);
    })().catch(() => {}).finally(() => { iv.juntoP = null; });
  }

  function loadHoje() {
    if (!logged() || iv.hojeP || (iv.hoje && Date.now() - iv.hoje.at < 5 * 60e3)) return;
    iv.hojeP = (async () => {
      const out = { at: Date.now(), vendas: null, chegou: {}, orc: null };
      // Administrador recebe os pedidos de todos; o vendedor filtra os dele.
      const uid = iv.status && iv.status.user && iv.status.user.id;
      const o = await api('GET', `pedidos/?pagina=1&status=2${uid ? `&vendedor=${encodeURIComponent(uid)}` : ''}`).catch(() => null);
      if (o && Array.isArray(o.pedidos)) out.orc = { total: Number(o.qtd_pedidos) || o.pedidos.length, list: o.pedidos.map(IV.cabecalhoPedido) };
      const r = await api('GET', 'dashboard/evolucao-vendas-mensal').catch(() => null);
      out.vendas = Array.isArray(r) ? r : null;
      for (const g of waitGroups().slice(0, 8)) {
        let p;
        if (g.produtoId) {
          const x = await api('GET', `pedidos/produtos/${g.produtoId}`).catch(() => null);
          p = x && Number(x.estoque) > 0 ? x : null;
        } else {
          const prods = await api('GET', `pedidos/produtos?pesquisa=${encodeURIComponent(g.peca.trim())}&qtd=10`).catch(() => null);
          p = DZ.noEstoque(g.peca, prods);
        }
        if (p) out.chegou[g.key] = p;
      }
      iv.hoje = out;
    })().finally(() => { iv.hojeP = null; if (state.tab === 'hoje') render(true); });
  }

  function cardVendas() {
    const v = iv.hoje && iv.hoje.vendas;
    if (!logged() || !v || !v.some((x) => x.valor > 0)) return '';
    const m = DZ.vendasMes(v);
    const last = v.slice(-6);
    const max = Math.max(1, ...last.map((x) => x.valor));
    const curKey = (() => { const d = new Date(); return `${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}`; })();
    const MES = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];
    return card('Minhas vendas', 'activity', m.variacao == null ? '' : tag(`${m.variacao >= 0 ? '+' : ''}${m.variacao}% vs mês passado`, m.variacao >= 0 ? 'ok' : 'bad'),
      h('div', { class: 'big-n' }, F.brl(m.atual)),
      h('div', { class: 'tiny' }, `concluído este mês · mês passado ${F.brl(m.anterior)}`),
      last.length > 1 ? h('div', { class: 'bars' }, last.map((x) => h('div', { class: x.mes === curKey ? 'cur' : '', title: `${x.mes}: ${F.brl(x.valor)}` },
        h('i', { style: `height:${Math.round((x.valor / max) * 48)}px` }), h('span', {}, MES[Number(x.mes.slice(0, 2)) - 1] || x.mes)))) : '');
  }

  function cardMetricas(contacts, now) {
    const dias = state.ui.metDias || 30;
    const m = FU.metricas(contacts, now, dias);
    const chips = h('div', { class: 'chips fit' }, [7, 30, 90].map((d) => h('button', { class: `chip ${d === dias ? 'on' : ''}`, onclick: () => { state.ui.metDias = d; render(); } }, `${d} dias`)));
    const desde = m.desde && m.desde > now - dias * FU.DAY ? h('div', { class: 'tiny mt muted' }, `O histórico de estágios começou em ${F.ddmm(m.desde)}; antes disso não entra.`) : '';
    if (!m.negs) {
      return card('Resultado', 'activity', '', chips,
        h('div', { class: 'tiny' }, 'Nenhuma negociação no período. Conta quem passou por Orçamento enviado, Aguardando Pix ou venda.'), desde);
    }
    const maxT = Math.max(1, ...m.etapas.map((e) => e.mediana));
    return card('Resultado', 'activity', tag(`${m.conversao}% viraram venda`, m.conversao >= 50 ? 'ok' : m.conversao >= 25 ? 'warn' : 'bad'), chips,
      h('div', { class: 'tiny' }, `${m.ganhos} de ${m.negs} ${m.negs > 1 ? 'negociações viraram' : 'negociação virou'} venda`,
        m.perdidos ? ` · ${m.perdidos} perdida${m.perdidos > 1 ? 's' : ''}${m.valorPerdido ? ` (${F.brl(m.valorPerdido)})` : ''}` : '',
        m.negs - m.ganhos - m.perdidos ? ` · ${m.negs - m.ganhos - m.perdidos} em aberto` : ''),
      m.ateVenda != null ? h('div', { class: 'tiny mt' }, 'Do orçamento à venda: ', h('b', {}, FU.tempo(m.ateVenda)), ' (mediana)') : '',
      m.etapas.length ? [h('div', { class: 'tiny mt muted' }, 'Tempo em cada etapa (mediana)'),
        m.etapas.map((e) => h('div', { class: 'fn', title: `${e.n} passagem(ns)` }, h('span', { class: 'lbl' }, e.label),
          h('span', { class: 'bar' }, h('i', { style: `width:${Math.max(4, Math.round((e.mediana / maxT) * 100))}%` })),
          h('span', { class: 'v' }, FU.tempo(e.mediana))))] : '',
      desde);
  }

  function renderHoje() {
    const now = Date.now();
    const contacts = S.data.contacts;
    const tasks = FU.dueTasks(contacts, now, endOfToday() - now);
    const late = tasks.filter((x) => x.task.due <= now).length;
    const stale = FU.staleQuotes(contacts, now);
    const maint = FU.maintenanceDue(contacts, now);
    const pipe = FU.pipeline(contacts);
    const groups = waitGroups();
    loadHoje();
    const chegou = (iv.hoje && iv.hoje.chegou) || {};
    const nChegou = groups.filter((g) => chegou[g.key]).length;
    const stages = FU.STAGES.filter((s) => s.id !== 'novo' && pipe[s.id].count);
    const max = Math.max(1, ...stages.map((s) => pipe[s.id].count));

    const abertos = [];
    Object.values(contacts).forEach((c) => (c.pedidos || []).forEach((p) => {
      if (!p.finalizado && !p.cancelado && (p.itens || []).length) abertos.push({ c, p });
    }));
    abertos.sort((a, b) => (a.p.date || 0) - (b.p.date || 0));
    const orcSis = logged() && iv.hoje && iv.hoje.orc && iv.hoje.orc.list.length ? iv.hoje.orc : null;
    const kpi = (n, label, ic, hot) => h('div', { class: `kpi ${hot ? 'hot' : ''} ${n ? '' : 'zero'}` }, h('div', { class: 'n' }, n), h('div', { class: 'l' }, icon(ic), label));
    const nothing = !tasks.length && !stale.length && !maint.length && !groups.length && !abertos.length && !orcSis;

    return [
      h('div', { class: 'kpis' },
        kpi(tasks.length, late ? `follow-ups · ${late} atrasado${late > 1 ? 's' : ''}` : 'follow-ups hoje', 'bell', late > 0),
        kpi(stale.length, 'orçamentos parados', 'pause'),
        kpi(maint.length, 'manutenção em 7 dias', 'wrench'),
        kpi(groups.reduce((s, g) => s + g.list.length, 0), 'esperando peça', 'box')),
      cardVendas(),
      nothing ? h('div', { class: 'card' }, empty('check', 'Tudo em dia', 'Nenhum cliente para chamar agora. Os lembretes aparecem aqui conforme vencem.')) : '',
      orcSis ? card('Em orçamento no sistema', 'file', tag(orcSis.total > orcSis.list.length ? `${orcSis.list.length} de ${orcSis.total}` : String(orcSis.list.length), 'info'),
        h('div', { class: 'list' }, orcSis.list.map((p) => {
          const dias = IV.diasDesde(p.data);
          const sub = `nº ${p.numero} · ${F.brl(p.total)} · ${IV.idade(dias) || p.data}${p.forma ? ` · ${p.forma}` : ''}`;
          const right = dias > 2 ? tag('parado', 'warn') : '';
          const c = contatoDoCliente(p.cliente);
          return c ? personRow(c, `${p.cliente} · ${sub}`, right)
            : h('div', { class: 'li', title: 'Nenhuma conversa ligada a este cliente ainda' }, h('div', { class: 'ibox' }, icon('file')),
              h('div', { class: 'main' }, h('div', { class: 't1 ellipsis' }, p.cliente || 'Cliente'), h('div', { class: 'tiny ellipsis' }, sub)), right);
        })),
        h('div', { class: 'tiny mt' }, 'Os mais recentes primeiro. Abra a conversa para cobrar, finalizar ou cancelar.')) : '',
      !orcSis && abertos.length ? card('Salvos no sistema, sem finalizar', 'file', tag(F.brl(abertos.reduce((s, x) => s + (Number(x.p.total) || 0), 0)), 'info'),
        h('div', { class: 'list' }, abertos.map(({ c, p }) => personRow(c, `nº ${p.numero} · ${p.total != null ? F.brl(p.total) : '—'} · salvo ${since(p.date)}${p.clienteNome ? ` · ${p.clienteNome}` : ''}`,
          Date.now() - (p.date || 0) > 2 * FU.DAY ? tag('parado', 'warn') : ''))),
        h('div', { class: 'tiny mt' }, 'Abra a conversa para finalizar (Histórico → Finalizar) ou cancelar.')) : '',
      tasks.length ? card('Follow-ups de hoje', 'bell', '', h('div', { class: 'list' },
        tasks.map(({ contact: c, task: t }) => personRow(c, `${t.label} · ${rel(t.due, now)}`, t.due <= now ? tag('atrasado', 'bad') : '')))) : '',
      stale.length ? card('Orçamentos parados', 'pause', '', h('div', { class: 'list' },
        stale.map((c) => personRow(c, `sem resposta ${since(c.stageSince)}`)))) : '',
      maint.length ? card('Manutenção próxima', 'wrench', '', h('div', { class: 'list' },
        maint.map((m) => personRow(m.contact, `${m.rule.label} · ${F.motoLabel(m.moto)} · ${F.ddmm(m.due)}`)))) : '',
      groups.length ? card('Aguardando peça', 'box', nChegou ? tag(`${nChegou} no estoque`, 'ok') : '', h('div', { class: 'list' },
        groups.map((g) => h('div', { class: 'li' },
          h('div', { class: `ibox ${chegou[g.key] ? 'ok' : ''}` }, icon(chegou[g.key] ? 'check' : 'clock')),
          h('div', { class: 'main' }, h('div', { class: 't1' }, g.peca),
            h('div', { class: 'tiny ellipsis' }, `${g.list.length} cliente(s): ${g.list.map((w) => (S.data.contacts[w.contactKey] || {}).name || '?').join(', ')}`),
            chegou[g.key] ? h('div', { class: 'tiny ellipsis', style: 'color:var(--ok)' }, `Tem no estoque: ${chegou[g.key].descricao}`) : ''),
          btn('Chegou', () => arrived(g), chegou[g.key] ? 'sm ok' : 'sm', 'check')))),
        logged() && iv.hojeP ? h('div', { class: 'busy' }, h('span', { class: 'spin' }), 'Conferindo o estoque…') : '') : '',
      stages.length ? card('Funil', 'funnel', '',
        stages.map((s) => h('div', { class: 'fn' }, h('span', { class: 'lbl' }, s.label),
          h('span', { class: 'bar' }, h('i', { style: `width:${Math.round((pipe[s.id].count / max) * 100)}%` })),
          h('span', { class: 'v' }, pipe[s.id].count))),
        (() => {
          const open = FU.OPEN_STAGES.reduce((sum, id) => sum + pipe[id].total, 0);
          return open ? h('div', { class: 'tiny mt' }, `Em negociação: ${F.brl(open)}`) : '';
        })(),
        (() => {
          const ps = FU.perdas(contacts);
          if (!ps.length) return '';
          return h('div', { class: 'tiny mt' }, 'Perdidos: ', ps.map((g, i) => [i ? ' · ' : '',
            h('span', { class: g.id ? '' : 'warn-c' }, `${g.label} ${g.count}${g.total ? ` (${F.brl(g.total)})` : ''}`)]));
        })()) : '',
      stages.length ? cardMetricas(contacts, now) : '',
    ];
  }

  function arrived(group) {
    const now = Date.now();
    group.list.forEach((w) => {
      w.status = 'chegou';
      const c = S.data.contacts[w.contactKey];
      if (!c) return;
      c.followups.push(FU.makeTask('aviso', 'Chegou peça', `Oi {nome}! Chegou ${w.peca} que você procurou. Quer que eu separe uma pra você?`, now));
      S.commit(c);
    });
    S.save('waitlist');
    render();
    toast(`Aviso criado para ${group.list.length} cliente(s). Abra cada conversa e envie.`);
  }

  // ---------- Respostas ----------

  function renderRespostas() {
    const c = state.chat ? S.contact(state.chat) : null;
    const f = (state.filter || '').toLowerCase();
    const cats = [...new Set(S.data.quickReplies.map((r) => r.cat))];
    const list = S.data.quickReplies.filter((r) => (!state.cat || r.cat === state.cat) && (!f || `${r.cat} ${r.title} ${r.text}`.toLowerCase().includes(f)));

    const cat = h('input', { placeholder: 'Categoria (ex.: Freio)', value: state.cat || '' });
    const title = h('input', { placeholder: 'Título' });
    const text = h('textarea', { placeholder: 'Texto. Variáveis: {nome} {moto} {ano} {total} {peca} {loja} {pix} {vendedor}' });

    return [
      h('div', { class: 'row' },
        searchBox({ placeholder: 'Buscar resposta…', value: state.filter || '', oninput: (e) => { state.filter = e.target.value; render(true); } }),
        h('button', { class: `btn ${state.ui.newReply ? '' : 'pri'}`, title: 'Nova resposta', onclick: () => { state.ui.newReply = !state.ui.newReply; render(true); } }, icon(state.ui.newReply ? 'x' : 'plus'))),
      state.ui.newReply ? h('div', { class: 'card mt' }, h('div', { class: 'card-h' }, h('div', { class: 'ttl' }, icon('zap'), 'Nova resposta')),
        h('div', { class: 'stack' }, h('div', { class: 'grid2' }, cat, title), text),
        h('div', { class: 'actions' }, btn('Salvar resposta', () => {
          if (!text.value.trim()) return;
          S.data.quickReplies.push({ id: crypto.randomUUID(), cat: cat.value.trim() || 'Geral', title: title.value.trim() || text.value.slice(0, 30), text: text.value });
          S.save('quickReplies'); state.ui.newReply = false; render(); toast('Resposta salva.');
        }, 'pri'))) : '',
      h('div', { class: 'chips' },
        h('button', { class: `chip ${state.cat ? '' : 'on'}`, onclick: () => { state.cat = ''; render(true); } }, 'Todas'),
        cats.map((k) => h('button', { class: `chip ${state.cat === k ? 'on' : ''}`, onclick: () => { state.cat = k; render(true); } }, k))),
      list.length ? list.map((r) => h('div', { class: 'card' },
        h('div', { class: 'row' }, h('span', { class: 't1 grow ellipsis' }, r.title), tag(r.cat),
          h('button', { class: 'x-btn', title: 'Apagar', onclick: ask(`del:${r.id}`) }, icon('trash'))),
        h('div', { class: 'quote clamp' }, c ? F.fill(r.text, S.vars(c)) : r.text),
        btn('Inserir na conversa', () => insert(F.fill(r.text, S.vars(c)), 'resposta', r.title), 'sm pri', 'send'),
        confirmBox(`del:${r.id}`, `Apagar a resposta "${r.title}"?`, 'Apagar', () => {
          S.data.quickReplies = S.data.quickReplies.filter((x) => x.id !== r.id); S.save('quickReplies'); render(true);
        }, 'danger fill')))
        : h('div', { class: 'card' }, empty('zap', 'Nenhuma resposta encontrada', 'Crie respostas prontas com o botão +.')),
    ];
  }

  // ---------- Ajustes ----------

  function renderConfig() {
    const st = S.data.settings;
    const setS = (k, parse) => (v) => { st[k] = parse ? parse(v) : v; S.save('settings'); };
    const file = h('input', { type: 'file', accept: 'application/json', style: 'display:none', onchange: async (e) => {
      const f = e.target.files[0];
      if (!f) return;
      try { await S.importJson(await f.text()); toast('Backup importado.'); render(); } catch (err) { toast(`Erro: ${err.message}`); }
    } });
    const health = W.health();
    const allOk = health.every((x) => x.ok && !x.fallback);
    return [
      h('div', { class: 'sec-t' }, 'Integra Vendas'),
      cardConta(),
      h('div', { class: 'sec-t' }, 'Loja'),
      h('div', { class: 'card' }, h('div', { class: 'stack' },
        fld('Nome da loja', input(st.loja, setS('loja'))),
        fld('Seu nome', input(st.vendedor, setS('vendedor'))),
        h('div', { class: 'grid2' },
          fld('Chave Pix', input(st.pix, setS('pix'))),
          fld('Validade do orçamento', input(st.validadeDias, setS('validadeDias', num), { inputmode: 'numeric', placeholder: 'dias' }))),
        fld('Setor de cadastro (recebe pedidos de atualização)', input(st.cadastroDestino, setS('cadastroDestino'), { placeholder: 'Contato/grupo no WhatsApp, número ou e-mail' })))),
      h('div', { class: 'sec-t' }, 'Privacidade e dados'),
      h('div', { class: 'card' },
        h('label', { class: 'switch' },
          h('input', { type: 'checkbox', checked: !!st.blur, onchange: (e) => { st.blur = e.target.checked; S.save('settings'); applyBlur(); } }),
          h('span', { class: 'knob' }),
          h('span', {}, h('div', { class: 't1' }, 'Desfocar conversas'), h('div', { class: 'tiny' }, 'Para atender no balcão com cliente olhando. Passe o mouse para ver.'))),
        h('div', { class: 'tiny mt' }, 'A ficha do cliente fica só neste navegador. Com o Integra Vendas conectado, só pedidos e buscas vão para o sistema da empresa.'),
        h('div', { class: 'acts mt' },
          btn('Exportar backup', () => {
            h('a', { href: URL.createObjectURL(new Blob([S.exportJson()], { type: 'application/json' })), download: `integra-vendas-whatsapp-${new Date().toISOString().slice(0, 10)}.json` }).click();
          }, 'sm', 'download'),
          btn('Importar', () => file.click(), 'sm'),
          btn('Apagar tudo', ask('wipe'), 'sm danger', 'trash')),
        confirmBox('wipe', 'Apagar todos os clientes, orçamentos e respostas deste navegador? Não dá para desfazer.', 'Apagar tudo', async () => {
          await S.wipe(); render(); toast('Dados apagados.');
        }, 'danger fill'),
        file),
      fold('diag', 'Diagnóstico da página', 'activity', tag(allOk ? 'ok' : 'atenção', allOk ? 'ok' : 'warn'), () => [
        health.map((x) => h('div', { class: `health ${x.ok ? (x.fallback ? 'warn-c' : 'ok-c') : 'bad-c'}` },
          `${x.ok ? (x.fallback ? '⚠' : '✓') : '✗'} ${x.name}${x.fallback ? ` (alternativa #${x.index})` : ''}`)),
        h('div', { class: 'tiny mt' }, '✗ ou ⚠ = o WhatsApp mudou a página; a extensão desliga só o recurso afetado.'),
      ]),
    ];
  }

  // ---------- montagem ----------

  const TABS = [
    { id: 'cliente', label: 'Conversa', ic: 'chat', render: renderCliente },
    { id: 'hoje', label: 'Hoje', ic: 'calendar', render: renderHoje },
    { id: 'respostas', label: 'Respostas', ic: 'zap', render: renderRespostas },
    { id: 'config', label: 'Ajustes', ic: 'sliders', render: renderConfig },
  ];

  function renderTop() {
    const on = logged();
    const u = on ? iv.status.user || {} : {};
    const label = !iv.status ? 'verificando…' : on ? [u.nome && u.nome.split(' ')[0], u.empresa].filter(Boolean).join(' · ') || 'conectado' : 'desconectado — entrar';
    const due = FU.dueTasks(S.data.contacts, Date.now()).length;
    const go = (id) => () => { state.tab = id; state.confirm = null; render(); };
    topEl.replaceChildren(
      h('div', { class: 'mark' }, 'IV'),
      h('div', { class: 'brand' }, h('b', {}, NAME),
        h('button', { class: 'conn', title: 'Conta do Integra Vendas', onclick: go('config') },
          h('span', { class: `dot ${on ? 'on' : ''}` }), h('span', {}, label))),
      ...TABS.map((t) => h('button', { class: `icon-btn ${state.tab === t.id ? 'on' : ''}`, title: t.label, onclick: go(t.id) },
        icon(t.ic), t.id === 'hoje' && due ? h('span', { class: 'badge' }, due) : '')),
      h('button', { class: 'icon-btn', title: 'Recolher painel', onclick: () => { state.open = false; applyOpen(); } }, icon('close')));
  }

  function renderSide() {
    if (state.tab !== 'cliente' || !state.chat || state.sub !== 'venda') return [];
    const v = state.ui.pedView;
    if (v && v.ck === cur.key) return sidePedido(cur, v);
    return cardOrcamento(cur).side;
  }

  function render(keepFocus) {
    if (!body) return;
    const scrolls = [...wrap.querySelectorAll('.body, .side-list, .results')].map((el) => [el.className, el.scrollTop]);
    const active = keepFocus && shadow.activeElement;
    const pos = active && active.selectionStart;
    renderTop();
    // Contato ainda não salvo vem como objeto novo a cada S.contact(): todas as partes do painel usam este.
    cur = state.chat ? S.contact(state.chat) : null;
    if (cur && !cur.draft) cur.draft = newDraft();
    const c = state.tab === 'cliente' ? cur : null;
    headEl.replaceChildren(...(c ? [hero(c), perdaBar(c), seg(c)] : []));
    side.replaceChildren();
    const tab = TABS.find((t) => t.id === state.tab);
    body.replaceChildren(...[].concat(tab.render()).flat(Infinity).filter(Boolean));
    const sideNodes = [].concat(renderSide()).flat(Infinity).filter(Boolean);
    side.replaceChildren(...sideNodes);
    wrap.classList.toggle('has-side', sideNodes.length > 0);
    const els = [...wrap.querySelectorAll('.body, .side-list, .results')];
    scrolls.forEach(([cls, top], i) => { if (els[i] && els[i].className === cls && top) els[i].scrollTop = top; });
    if (active && active.placeholder) {
      const again = wrap.querySelector(`${active.tagName.toLowerCase()}[placeholder="${active.placeholder.replace(/"/g, '\\"')}"]`);
      if (again) { again.focus(); if (pos != null && again.setSelectionRange) again.setSelectionRange(pos, pos); }
    }
  }

  function applyWidth(w) {
    const px = `${clampW(w)}px`;
    document.documentElement.style.setProperty('--mz-w', px);
    if (wrap) { wrap.style.setProperty('--mz-w', px); wrap.classList.toggle('narrow', clampW(w) < W_TWO); }
  }

  function grip() {
    const g = h('div', { class: 'grip', title: 'Arraste para alargar o painel (duplo clique volta ao padrão)' });
    g.addEventListener('dblclick', () => { S.data.settings.largura = W_DEF; S.save('settings'); applyWidth(W_DEF); });
    g.addEventListener('pointerdown', (e) => {
      e.preventDefault();
      g.setPointerCapture(e.pointerId);
      g.classList.add('on');
      document.documentElement.classList.add('mz-resizing');
      const move = (ev) => applyWidth(window.innerWidth - ev.clientX);
      const up = (ev) => {
        g.removeEventListener('pointermove', move); g.removeEventListener('pointerup', up);
        g.classList.remove('on'); document.documentElement.classList.remove('mz-resizing');
        S.data.settings.largura = clampW(window.innerWidth - ev.clientX); S.save('settings');
      };
      g.addEventListener('pointermove', move); g.addEventListener('pointerup', up);
    });
    return g;
  }

  function applyOpen() {
    document.documentElement.classList.toggle('mz-open', state.open);
    wrap.classList.toggle('closed', !state.open);
    openBtn.style.display = state.open ? 'none' : 'block';
  }

  function syncTheme() {
    if (wrap) wrap.classList.toggle('dark', document.body.classList.contains('dark'));
  }

  function applyBlur() {
    document.documentElement.classList.toggle('mz-blur', !!S.data.settings.blur);
  }

  function mount() {
    const pageStyle = document.createElement('style');
    pageStyle.id = 'mz-page-style';
    pageStyle.textContent = PAGE_CSS;
    document.head.appendChild(pageStyle);

    const host = document.createElement('div');
    host.id = 'mz-host';
    document.documentElement.appendChild(host);
    shadow = host.attachShadow({ mode: 'open' });
    shadow.appendChild(h('style', {}, CSS));

    topEl = h('div', { class: 'top' });
    headEl = h('div', {});
    body = h('div', { class: 'body' });
    side = h('div', { class: 'side' });
    toastEl = h('div', { class: 'toast' });
    wrap = h('div', { class: 'wrap' }, grip(), topEl, headEl, h('div', { class: 'cols' }, body, side), toastEl);
    applyWidth(S.data.settings.largura || W_DEF);
    openBtn = h('button', { class: 'tab-open', onclick: () => { state.open = true; applyOpen(); render(); } }, NAME);
    shadow.append(wrap, openBtn);
    applyOpen();
    applyBlur();
    syncTheme();
    render();
    ivRefreshStatus();
    chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local' && ch.ivSession) ivRefreshStatus(); });
  }

  function setChat(chat) {
    if (!state.chat || !chat || state.chat.key !== chat.key) {
      iv.err = ''; state.relink = false; state.confirm = null;
      stopLive('prod'); iv.prodQ = ''; iv.prod = []; iv.prodAll = []; iv.prodTipo = ''; iv.prodShown = ''; iv.prodRelax = ''; iv.prodIdx = 0; iv.picked = [];
    }
    state.chat = chat;
    if (state.tab === 'cliente' || state.pendingCliente) { state.pendingCliente = false; state.tab = 'cliente'; }
    render();
    const pend = state.pendingInsert;
    if (pend && chat && chat.name === pend.name) {
      state.pendingInsert = null;
      setTimeout(() => { if (W.insertText(pend.text)) toast('Pedido de atualização na caixa de mensagem. Revise e envie.'); }, 700);
    }
  }

  function openContact(c) {
    if (state.chat && state.chat.key === c.key) { state.tab = 'cliente'; render(); return; }
    state.pendingCliente = true;
    Promise.resolve(W.openChat(c)).then((r) => {
      if (r === 'nao-encontrado') { state.pendingCliente = false; toast(`Não achei "${c.name}" na lista. Procure pelo nome na busca do WhatsApp.`); }
    });
  }

  const STAGE_COR = { orcamento: '#53bdeb', aguardando_pix: '#e2a73f', pago: '#06cf9c', separando: '#a78bfa', enviado: '#25d366', pos_venda: '#8696a0', perdido: '#f15c6d' };
  const STAGE_GLIFO = { orcamento: '$', aguardando_pix: '⧗', pago: '✓', separando: '▦', enviado: '➜', pos_venda: '★', perdido: '✕' };
  const STAGE_COR_CLARO = { orcamento: '#027eb5', aguardando_pix: '#a15c00', pago: '#008069', separando: '#7c5cd6', enviado: '#008069', pos_venda: '#54656f', perdido: '#c62f3c' };

  function contatoDoTitulo(t) {
    const name = (t.getAttribute('title') || '').trim();
    const digits = name.replace(/\D/g, '');
    return S.data.contacts[`n:${name}`] || (digits.length >= 8 ? S.data.contacts[`p:${digits}`] : null);
  }

  function chegouPorContato() {
    const out = new Set();
    const ch = iv.hoje && iv.hoje.chegou;
    if (!ch) return out;
    S.data.waitlist.forEach((w) => { if (w.status === 'aguardando' && ch[w.peca.trim().toLowerCase()]) out.add(w.contactKey); });
    return out;
  }

  // Só escreve no DOM do WhatsApp quando o valor muda: cada escrita dispara o MutationObserver de novo.
  const setAttr = (el, k, v) => { if (el.getAttribute(k) !== v) el.setAttribute(k, v); };
  const setText = (el, v) => { if (el.textContent !== v) el.textContent = v; };
  const setStyle = (el, k, v) => { if (el.style.getPropertyValue(k) !== v) el.style.setProperty(k, v); };
  function marca(parent, cls, tag = 'span') {
    let el = parent.querySelector(`:scope > .${cls}`);
    if (!el) { el = document.createElement(tag); el.className = cls; parent.appendChild(el); }
    return el;
  }
  const tira = (parent, cls) => { const el = parent && parent.querySelector(`:scope > .${cls}`); if (el) el.remove(); };

  function abrirPainel(tab) {
    state.open = true; applyOpen();
    if (tab) { state.tab = tab; state.confirm = null; }
    render();
  }

  function decorateRow(t, c, passo, dark) {
    const row = t.closest('[role="row"]');
    const cell = row && row.querySelector('[role="gridcell"]');
    // Na linha da última mensagem: na do nome, com o painel aberto, nome e pílula não cabem juntos.
    const linha2 = t.closest('[role="gridcell"]');
    const alvo = linha2 && linha2.nextElementSibling;
    let pill = alvo ? alvo.querySelector(':scope > .mz-pill') : null;
    if (!cell || !passo) {
      if (pill) pill.remove();
      ['mz-stripe', 'mz-ring', 'mz-glyph'].forEach((k) => tira(cell, k));
      return;
    }
    const cor = (dark ? STAGE_COR : STAGE_COR_CLARO)[passo.stage] || '#8696a0';
    setStyle(cell, '--mz-c', cor);
    marca(cell, 'mz-stripe');

    const img = row.querySelector('img');
    const av = img && img.parentElement && img.parentElement.offsetWidth >= 36 ? img.parentElement : [...row.querySelectorAll('div')].find((d) => d.offsetWidth >= 36 && d.offsetWidth <= 60 && d.offsetWidth === d.offsetHeight);
    if (av) {
      const cb = cell.getBoundingClientRect(); const ab = av.getBoundingClientRect();
      const x = Math.round(ab.left - cb.left); const y = Math.round(ab.top - cb.top); const w = Math.round(ab.width);
      if (passo.urg) {
        const ring = marca(cell, 'mz-ring');
        setAttr(ring, 'class', `mz-ring mz-${passo.urg}`);
        setAttr(ring, 'style', `left:${x}px;top:${y}px;width:${w}px;height:${w}px`);
      } else tira(cell, 'mz-ring');
      const g = marca(cell, 'mz-glyph');
      setText(g, STAGE_GLIFO[passo.stage] || '•');
      setAttr(g, 'style', `left:${x + w - 14}px;top:${y + w - 14}px`);
    }

    if (!passo.acao) { if (pill) pill.remove(); return; }
    if (!pill) {
      pill = document.createElement('span');
      pill.className = 'mz-pill';
      const para = (e) => e.stopPropagation();
      ['pointerdown', 'mousedown', 'pointerup', 'mouseup'].forEach((ev) => pill.addEventListener(ev, para));
      pill.addEventListener('click', (e) => {
        e.stopPropagation(); e.preventDefault();
        const contato = S.data.contacts[pill.dataset.key];
        if (!contato) return;
        abrirPainel('cliente');
        openContact(contato);
      });
      if (!alvo) return;
      alvo.prepend(pill);
    }
    pill.dataset.key = c.key;
    setAttr(pill, 'class', `mz-pill${passo.urg === 'red' ? ' mz-red' : ''}`);
    setAttr(pill, 'title', `${passo.acao}${passo.tempo ? ` · há ${passo.tempo}` : ''} — abrir no painel`);
    const html = `→ <b>${escHtml(passo.acao)}</b>${passo.tempo ? ` <i>· ${escHtml(passo.tempo)}</i>` : ''}`;
    if (pill.innerHTML !== html) pill.innerHTML = html;
  }

  const escHtml = (t) => String(t).replace(/[&<>"]/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[ch]);

  // Chip na barra de filtros do WhatsApp. A lista dele é virtualizada e não dá para esconder linhas,
  // então o filtro é uma lista nossa por cima; clicar num cliente abre a conversa (pela busca, se estiver fora da tela).
  let filtro = { on: false, lista: [], sig: '' };
  const URG = { red: 0, amber: 1, green: 2, '': 3 };
  function decorateFiltros(n) {
    const bar = document.querySelector('#side [role="tablist"]');
    if (!bar) return;
    let chip = bar.querySelector(':scope > .mz-need');
    if (!chip) {
      chip = document.createElement('button');
      chip.type = 'button';
      chip.className = 'mz-need';
      chip.addEventListener('click', (e) => { e.stopPropagation(); filtro.on = !filtro.on; filtro.sig = ''; decorateList(); });
      // Qualquer outro filtro do WhatsApp (Tudo, Não lidas…) fecha o nosso.
      bar.addEventListener('click', (e) => { if (filtro.on && !e.target.closest('.mz-need')) { filtro.on = false; filtro.sig = ''; decorateList(); } });
      bar.prepend(chip);
    }
    setAttr(chip, 'class', `mz-need${n ? '' : ' mz-zero'}${filtro.on ? ' mz-on' : ''}`);
    setAttr(chip, 'aria-pressed', String(filtro.on));
    setAttr(chip, 'title', 'Clientes com retorno atrasado, orçamento parado ou peça que chegou');
    const html = `Precisa de você <b>${n}</b>`;
    if (chip.innerHTML !== html) chip.innerHTML = html;
    listaFiltro();
  }

  function listaFiltro() {
    const pane = W.q('chatList');
    let box = document.querySelector('body > .mz-fil');
    if (!filtro.on || !pane) { if (box) box.remove(); return; }
    if (!box) {
      box = document.createElement('div');
      box.className = 'mz-fil';
      box.addEventListener('click', (e) => {
        const x = e.target.closest('[data-k]');
        if (x) { const c = S.data.contacts[x.dataset.k]; if (c) { abrirPainel('cliente'); openContact(c); } return; }
        if (e.target.closest('.mz-fil-x')) { filtro.on = false; filtro.sig = ''; decorateList(); }
      });
      document.body.appendChild(box);
    }
    const pr = pane.getBoundingClientRect();
    setAttr(box, 'style', `top:${Math.round(pr.top)}px;left:${Math.round(pr.left)}px;width:${Math.round(pr.width)}px;height:${Math.round(pr.height)}px`);
    const aberto = state.chat && state.chat.key;
    const esc = escHtml;
    const linhas = filtro.lista.map(({ c, p }) => {
      const cor = STAGE_COR[p.stage] || '#8696a0';
      const nome = IV.samePhone(c.name, c.phone) ? IV.fmtPhone(c.phone) : c.name;
      const est = (FU.STAGES.find((s) => s.id === p.stage) || {}).label || '';
      return `<div class="mz-fil-r${c.key === aberto ? ' on' : ''}" data-k="${esc(c.key)}" style="--mz-c:${cor}"><span class="mz-fil-u mz-${p.urg || 'n'}"></span>`
        + `<span class="mz-fil-m"><b>${esc(nome)}</b><small>${esc(est)}</small></span>`
        + `<span class="mz-fil-a">${esc(p.acao)}${p.tempo ? ` <i>· ${esc(p.tempo)}</i>` : ''}</span></div>`;
    }).join('');
    const html = `<div class="mz-fil-h"><span>Precisa de você · ${filtro.lista.length}</span><button type="button" class="mz-fil-x" title="Voltar à lista do WhatsApp">×</button></div>`
      + (linhas || '<div class="mz-fil-v">Ninguém esperando por você agora.</div>');
    if (box.dataset.sig !== html) { box.innerHTML = html; box.dataset.sig = html; }
  }

  function decorateList() {
    const now = Date.now();
    const dark = document.body.classList.contains('dark');
    loadHoje();
    const chegou = chegouPorContato();
    // Mesma régua da aba Hoje: retorno que vence até o fim do dia também conta.
    const quem = new Set(FU.dueTasks(S.data.contacts, now, endOfToday() - now).map((x) => x.contact.key));
    Object.values(S.data.contacts).forEach((c) => {
      const p = FU.proximoPasso(c, now, { chegou: chegou.has(c.key) });
      if (p && p.urg) quem.add(c.key);
    });
    const n = quem.size;
    filtro.lista = [...quem].map((k) => S.data.contacts[k]).filter(Boolean).map((c) => {
      let p = FU.proximoPasso(c, now, { chegou: chegou.has(c.key) }) || { stage: c.stage, acao: '', tempo: '', urg: '' };
      if (!p.urg) {
        const t = FU.dueTasks({ [c.key]: c }, now, endOfToday() - now)[0];
        if (t) p = { ...p, acao: t.task.label === '2h' || /^D\+/.test(t.task.label) ? 'Retorno hoje' : t.task.label, tempo: `às ${new Date(t.task.due).toTimeString().slice(0, 5)}`, urg: '' };
      }
      return { c, p };
    }).sort((a, b) => URG[a.p.urg || ''] - URG[b.p.urg || ''] || (a.c.stageSince || 0) - (b.c.stageSince || 0));
    decorateFiltros(n);
    W.chatRowTitles().forEach((t) => {
      const c = contatoDoTitulo(t);
      const row = c && t.closest('[role="row"]');
      const naoLida = !!row && /não lidas?|unread/i.test([...row.querySelectorAll('[aria-label]')].map((e) => e.getAttribute('aria-label')).join(' '));
      const passo = c ? FU.proximoPasso(c, now, { chegou: chegou.has(c.key), naoLida }) : null;
      decorateRow(t, c, passo, dark);
    });
  }

  // Botão "Cotar" que aparece ao passar o mouse na mensagem. Fica fora do texto da bolha para não entrar no innerText que confere envios.
  // A mesma bolha é lida a cada tick do observador: o resultado fica guardado pelo texto.
  const listaCache = new Map();
  function itensDe(texto) {
    let r = listaCache.get(texto);
    if (!r) { r = DZ.parseLista(texto); if (listaCache.size > 500) listaCache.clear(); listaCache.set(texto, r); }
    return r;
  }
  const motoCache = new Map();
  function motoDe(texto) {
    if (!motoCache.has(texto)) { if (motoCache.size > 500) motoCache.clear(); motoCache.set(texto, BS.motoNoTexto(texto)); }
    return motoCache.get(texto);
  }
  const fecharCache = new Map();
  function fecharDe(texto) {
    if (!fecharCache.has(texto)) { if (fecharCache.size > 500) fecharCache.clear(); fecharCache.set(texto, DZ.querFechar(texto)); }
    return fecharCache.get(texto);
  }
  // O WhatsApp não marca quem enviou: a bolha do vendedor fica à direita. A posição não muda, então vale guardar.
  const ladoCache = new WeakMap();
  function eMeu(row, el, mr) {
    if (ladoCache.has(row)) return ladoCache.get(row);
    const bolha = el || [...row.querySelectorAll('div')].find((d) => { const x = d.getBoundingClientRect(); return x.width > 40 && x.width < mr.width * 0.8 && x.height > 20; });
    const r = bolha && bolha.getBoundingClientRect();
    if (!r || !r.width) return false;
    const meu = r.left + r.width / 2 > mr.left + mr.width / 2;
    ladoCache.set(row, meu);
    return meu;
  }

  function decorateChat() {
    const main = W.q('main');
    if (!main) return;
    const mr = main.getBoundingClientRect();
    // Foto ou áudio do vendedor também fecha o bloco do cliente, por isso a leitura é por linha, não só pelas bolhas com texto.
    const seq = [];
    main.querySelectorAll('[role="row"]').forEach((row) => {
      if (!row.querySelector('[data-id]')) return;
      const el = row.querySelector('[data-pre-plain-text]');
      const texto = el ? el.innerText || '' : '';
      const itens = el ? itensDe(texto) : [];
      seq.push({ el, texto, itens, meu: eMeu(row, el, mr), hora: el ? DZ.horaMsg(el.dataset.prePlainText) : null, peca: itens.some((x) => x.certo) });
    });
    // O WhatsApp tira da página as mensagens longe da rolagem: o que já se viu nesta conversa fica guardado.
    const vistas = citadas.chat === state.chat ? new Map(citadas.vistas) : new Map();
    seq.forEach((m) => { if (m.el && !m.meu) { const x = motoDe(m.texto); if (x) vistas.set(x, Math.max(vistas.get(x) || 0, m.hora || 0)); } });
    const cit = [...vistas].sort((a, b) => a[1] - b[1]).map(([x]) => x);
    const c0 = state.chat ? S.contact(state.chat) : null;
    const top = c0 ? BS.motosNovas(cit, (c0.motos || []).map((m) => m.modelo), c0.motosIgnoradas)[0] || '' : '';
    const sig = `${state.chat}|${top}`;
    const mudou = sig !== citadas.sig;
    citadas = { chat: state.chat, lista: cit, vistas, sig };
    if (mudou && state.open) render(true);
    // Pedido de fechar mais recente do cliente; fica guardado ao rolar, como as motos.
    let fx = fechar.chat === state.chat ? fechar : { chat: state.chat, hora: 0, texto: '', sig: '' };
    seq.forEach((m) => { if (m.el && !m.meu && m.hora && m.hora >= fx.hora && fecharDe(m.texto)) fx = { chat: state.chat, hora: m.hora, texto: m.texto.replace(/\s+/g, ' ').trim(), sig: '' }; });
    fx.sig = `${fx.chat}|${fx.hora}`;
    const fMudou = fx.sig !== fechar.sig;
    fechar = fx;
    if (fMudou && !mudou && state.open) render(true);
    const blocoDe = new Map();
    DZ.blocos(seq.map((m) => ({ meu: m.meu, hora: m.hora, texto: m.peca }))).forEach((bl) => bl.forEach((i) => blocoDe.set(i, bl)));
    seq.forEach((m, i) => {
      if (!m.el) return;
      const host = m.el.parentElement && m.el.parentElement.parentElement;
      if (!host) return;
      let b = host.querySelector(':scope > .mz-cotar');
      if (m.meu || !m.peca) { if (b) b.remove(); return; }
      const bloco = (blocoDe.get(i) || [i]).map((k) => seq[k]);
      if (!b) {
        b = document.createElement('button');
        b.type = 'button';
        b.className = 'mz-cotar';
        ['pointerdown', 'mousedown'].forEach((ev) => b.addEventListener(ev, (e) => e.stopPropagation()));
        b.addEventListener('click', (e) => {
          e.stopPropagation(); e.preventDefault();
          if (!state.chat) return;
          if (!logged()) { abrirPainel('config'); toast('Entre no Integra Vendas para cotar.'); return; }
          cotarLista(S.contact(state.chat), (b.mzBloco || []).map((x) => x.innerText || '').join('\n'), (b.mzAntes || []).map((x) => x.innerText || ''));
        });
        host.classList.add('mz-cotar-host');
        host.appendChild(b);
      }
      b.mzBloco = bloco.map((x) => x.el);
      const ini = seq.indexOf(bloco[0]);
      b.mzAntes = seq.slice(Math.max(0, ini - 20), ini).filter((x) => x.el).map((x) => x.el);
      const n = bloco.reduce((a, x) => a + x.itens.length, 0);
      const junto = bloco.length > 1;
      setAttr(b, 'data-n', `${n > 1 ? `Cotar ${n} peças` : 'Cotar'}${junto ? ` · ${bloco.length} msgs` : ''}`);
      setAttr(b, 'title', junto ? `Junta as ${bloco.length} mensagens seguidas do cliente numa lista só; tire no painel o que não for peça` : 'Buscar o preço das peças desta mensagem no painel');
    });
  }

  MZ.panel = { mount, render, setChat, openContact, decorateList, decorateChat, syncTheme, toast, checkSent };
})(globalThis);

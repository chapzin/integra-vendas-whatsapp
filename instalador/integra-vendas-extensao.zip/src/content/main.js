(async function (root) {
  const MZ = root.MZ;
  await MZ.store.load();
  MZ.panel.mount();

  let lastKey;
  let scheduled = false;

  function tick() {
    scheduled = false;
    const chat = MZ.wa.currentChat();
    const key = chat ? chat.key : null;
    if (key !== lastKey) {
      lastKey = key;
      MZ.panel.setChat(chat);
    }
    MZ.panel.checkSent(chat);
    MZ.panel.decorateList();
    MZ.panel.decorateChat();
    MZ.panel.syncTheme();
  }

  // O WhatsApp Web muta o DOM o tempo todo; agrupa as mutações para não pesar.
  new MutationObserver(() => {
    if (scheduled) return;
    scheduled = true;
    setTimeout(tick, 120);
  }).observe(document.body, { childList: true, subtree: true });
  tick();

  setInterval(() => MZ.panel.decorateList(), 60e3);

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg && msg.type === 'openChat') {
      const c = MZ.store.data.contacts[msg.key];
      if (c) MZ.panel.openContact(c);
    }
  });
})(globalThis);

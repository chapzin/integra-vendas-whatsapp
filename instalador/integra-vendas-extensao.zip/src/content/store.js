(function (root) {
  const MZ = root.MZ;

  const DEFAULT_REPLIES = [
    { id: 'r1', cat: 'Atendimento', title: 'Qual moto?', text: 'Oi {nome}! Pra eu achar a peça certa: qual o modelo e ano da moto? Se tiver, manda uma foto da peça.' },
    { id: 'r2', cat: 'Atendimento', title: 'Confere a aplicação', text: 'Só um minuto, {nome}, vou conferir a aplicação certinha pra {moto}.' },
    { id: 'r3', cat: 'Freio', title: 'Pastilha orig x paralela', text: 'Pra {moto} tenho a pastilha original e a paralela. A original dura mais; a paralela sai mais em conta. Qual prefere?' },
    { id: 'r4', cat: 'Transmissão', title: 'Kit relação completo', text: 'Recomendo trocar o kit relação completo (coroa, pinhão e corrente) — trocar só a corrente gasta a nova rapidinho.' },
    { id: 'r5', cat: 'Óleo', title: 'Óleo recomendado', text: 'Pra {moto} o manual pede óleo 10W30 semissintético. Quer que eu já separe com o filtro?' },
    { id: 'r6', cat: 'Pagamento', title: 'Chave Pix', text: 'Pode fazer o Pix na chave {pix}. Assim que cair eu já separo e te aviso!' },
    { id: 'r7', cat: 'Entrega', title: 'Pronto pra retirar', text: '{nome}, seu pedido está separado e pronto pra retirar aqui na {loja}. 👍' },
  ];

  const data = {
    contacts: {},
    quickReplies: [],
    waitlist: [],
    // Tipos de peça de cada pedido concluído já lido (para o "Leve junto" aprendido).
    junto: { lidos: {}, at: 0 },
    settings: { loja: '', vendedor: '', pix: '', validadeDias: 3, blur: false },
  };

  async function load() {
    const got = await chrome.storage.local.get(['contacts', 'quickReplies', 'waitlist', 'settings', 'junto']);
    data.junto = got.junto || { lidos: {}, at: 0 };
    data.contacts = got.contacts || {};
    data.quickReplies = got.quickReplies || DEFAULT_REPLIES.slice();
    data.waitlist = got.waitlist || [];
    data.settings = Object.assign({}, data.settings, got.settings || {});
    if (!got.quickReplies) await save('quickReplies');
    return data;
  }

  function save(...keys) {
    const payload = {};
    keys.forEach((k) => { payload[k] = data[k]; });
    return chrome.storage.local.set(payload);
  }

  // Só guarda o contato quando o vendedor edita algo (minimização, LGPD): abrir a conversa não grava nada.
  function contact(chat) {
    const c = data.contacts[chat.key];
    if (c) {
      if (chat.name && c.name !== chat.name) c.name = chat.name;
      return c;
    }
    return { key: chat.key, name: chat.name, phone: chat.phone || '', stage: 'novo', stageSince: Date.now(), tipo: 'particular', notes: '', motos: [], quotes: [], followups: [], draft: null };
  }

  let timer = null;
  function commit(c) {
    if (c) { c.updatedAt = Date.now(); data.contacts[c.key] = c; }
    clearTimeout(timer);
    timer = setTimeout(() => save('contacts'), 250);
  }

  function vars(c, extra = {}) {
    const f = MZ.format;
    const moto = (c && c.motos && c.motos[0]) || null;
    const lastQuote = c && c.quotes && c.quotes[c.quotes.length - 1];
    return Object.assign({
      nome: c ? f.firstName(c.name) : '',
      moto: f.motoLabel(moto) || 'sua moto',
      ano: moto ? moto.ano || '' : '',
      total: lastQuote ? f.brl(lastQuote.total) : '',
      peca: lastQuote && lastQuote.items[0] ? lastQuote.items[0].desc : '',
      loja: data.settings.loja,
      vendedor: data.settings.vendedor,
      pix: data.settings.pix,
    }, extra);
  }

  function exportJson() {
    return JSON.stringify({ app: 'integra-vendas-whatsapp', version: 1, exportedAt: new Date().toISOString(), ...data }, null, 2);
  }

  async function importJson(text) {
    const obj = JSON.parse(text);
    if (!['integra-vendas-whatsapp', 'balcao-moto'].includes(obj.app)) throw new Error('Arquivo não é um backup do Integra Vendas para WhatsApp');
    ['contacts', 'quickReplies', 'waitlist', 'settings'].forEach((k) => { if (obj[k]) data[k] = obj[k]; });
    await save('contacts', 'quickReplies', 'waitlist', 'settings');
  }

  async function wipe() {
    await chrome.storage.local.clear();
    data.contacts = {};
    data.waitlist = [];
    data.junto = { lidos: {}, at: 0 };
    data.quickReplies = DEFAULT_REPLIES.slice();
    await save('quickReplies');
  }

  MZ.store = { data, load, save, contact, commit, vars, exportJson, importJson, wipe };
})(globalThis);

(function (root) {
  const MZ = root.MZ;

  // Só role/aria/atributos estáveis — nunca classe ofuscada. Ordem = preferência.
  const SEL = {
    main: ['#main'],
    headerTitle: [
      '#main header [data-testid="conversation-info-header-chat-title"]',
      '#main header span[dir="auto"][title]',
      '#main header span[dir="auto"]',
    ],
    composer: [
      '#main footer div[contenteditable="true"][data-lexical-editor="true"]',
      '#main footer [role="textbox"][contenteditable="true"]',
      '#main footer div[contenteditable="true"]',
    ],
    search: ['#side input[role="textbox"]', '#side input[type="text"]'],
    chatList: ['#pane-side', '[aria-label="Lista de conversas"]', '[aria-label="Chat list"]'],
    chatRow: ['[role="row"]', '[role="listitem"]'],
    rowTitle: ['span[dir="auto"][title]', 'span[title]'],
    caption: [
      '[data-testid="media-caption-input-container"][contenteditable="true"]',
      'div[contenteditable="true"][data-lexical-editor="true"]:not(#main footer *)',
    ],
  };

  const hits = {};

  function q(name, scope = document) {
    const list = SEL[name];
    for (let i = 0; i < list.length; i++) {
      const el = scope.querySelector(list[i]);
      if (el) { hits[name] = i; return el; }
    }
    hits[name] = -1;
    return null;
  }

  function qa(name, scope = document) {
    for (const s of SEL[name]) {
      const els = scope.querySelectorAll(s);
      if (els.length) return Array.from(els);
    }
    return [];
  }

  function health() {
    return ['main', 'headerTitle', 'composer', 'chatList'].map((k) => {
      q(k);
      return { name: k, index: hits[k], ok: hits[k] >= 0, fallback: hits[k] > 0 };
    });
  }

  const onlyDigits = (s) => String(s || '').replace(/\D/g, '');

  // O cabeçalho troca emoji por <img alt>; a lista mantém o emoji no atributo title.
  function nodeText(el) {
    let s = '';
    el.childNodes.forEach((n) => {
      if (n.nodeType === 3) s += n.nodeValue;
      else if (n.tagName === 'IMG') s += n.alt || '';
      else if (n.nodeType === 1) s += nodeText(n);
    });
    return s;
  }

  function currentChat() {
    const el = q('headerTitle');
    if (!el) return null;
    const name = (el.getAttribute('title') || nodeText(el)).trim();
    if (!name) return null;
    const looksPhone = /^\+?[\d\s().-]{8,}$/.test(name);
    const phone = looksPhone ? onlyDigits(name) : '';
    return { key: phone ? `p:${phone}` : `n:${name}`, name, phone };
  }

  function composerText(el) {
    return (el.innerText || el.textContent || '').trim();
  }

  // Lexical ignora mutação direta no DOM; paste sintético e execCommand passam pelos handlers dele.
  function insertText(text) {
    const el = q('composer');
    if (!el) return false;
    el.focus();
    const sel = root.getSelection();
    const range = document.createRange();
    range.selectNodeContents(el);
    range.collapse(false);
    sel.removeAllRanges();
    sel.addRange(range);

    const dt = new DataTransfer();
    dt.setData('text/plain', text);
    const ev = new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true });
    if (!ev.clipboardData) Object.defineProperty(ev, 'clipboardData', { value: dt });
    el.dispatchEvent(ev);
    // O Lexical aplica o paste de forma assíncrona; checar o texto agora daria falso negativo e duplicaria a inserção.
    if (ev.defaultPrevented) return true;

    const before = composerText(el);
    document.execCommand('insertText', false, text);
    return composerText(el) !== before;
  }

  function pasteInto(el, dt) {
    el.focus();
    const ev = new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true });
    if (!ev.clipboardData) Object.defineProperty(ev, 'clipboardData', { value: dt });
    el.dispatchEvent(ev);
    return ev.defaultPrevented;
  }

  // Soltar arquivo por script o WhatsApp ignora; colar a imagem abre a mesma prévia de envio, com legenda.
  // Nada é enviado: a prévia fica aberta esperando o vendedor clicar em enviar.
  async function attachImage(file, caption) {
    // Com uma prévia já aberta, a nova foto entra nela e a legenda cola na da foto anterior.
    if (q('caption')) return 'aberta';
    const el = q('composer');
    if (!el) return 'sem-caixa';
    const dt = new DataTransfer();
    dt.items.add(file);
    if (!pasteInto(el, dt)) return 'recusado';
    let cap = null;
    for (let i = 0; i < 40 && !cap; i++) {
      await new Promise((r) => setTimeout(r, 100));
      cap = q('caption');
    }
    if (!cap) return 'sem-legenda';
    if (caption) {
      const t = new DataTransfer();
      t.setData('text/plain', caption);
      pasteInto(cap, t);
    }
    return 'ok';
  }

  // Texto das últimas bolhas da conversa aberta; serve para confirmar que o vendedor enviou o que o painel inseriu.
  function bubbles(limit = 40) {
    const main = q('main');
    if (!main) return [];
    return Array.from(main.querySelectorAll('[data-pre-plain-text]')).slice(-limit).map((el) => el.innerText || '');
  }

  function findTitleByName(name) {
    return chatRowTitles().find((t) => (t.getAttribute('title') || '').trim() === name) || null;
  }

  // O WhatsApp só reage à sequência completa pointer+mouse no próprio título, não a click isolado na célula.
  function clicaTitulo(t) {
    const b = t.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, composed: true, view: root, clientX: b.left + 5, clientY: b.top + 5, button: 0, buttons: 1, pointerId: 1, pointerType: 'mouse', isPrimary: true };
    [['pointerdown', PointerEvent], ['mousedown', MouseEvent], ['pointerup', PointerEvent], ['mouseup', MouseEvent], ['click', MouseEvent]]
      .forEach(([type, Ctor]) => t.dispatchEvent(new Ctor(type, o)));
  }

  // Input do React: o valor entra pelo setter nativo para o WhatsApp enxergar a mudança.
  function setBusca(el, v) {
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(el, v);
    el.dispatchEvent(new Event('input', { bubbles: true }));
  }

  // Conversa fora da parte visível da lista (virtualizada): procura pela busca do WhatsApp e limpa depois.
  async function openChatBusca(contact) {
    const box = q('search');
    const termo = IVphone(contact) || contact.name;
    if (!box || !termo) return 'nao-encontrado';
    setBusca(box, termo);
    let t = null;
    for (let i = 0; i < 20 && !t; i++) {
      await new Promise((r) => setTimeout(r, 150));
      t = findTitleByName(contact.name) || (contact.phone ? chatRowTitles().find((x) => onlyDigits(x.getAttribute('title')).endsWith(onlyDigits(contact.phone).slice(-8))) : null);
    }
    if (t) clicaTitulo(t);
    setTimeout(() => setBusca(box, ''), t ? 400 : 0);
    return t ? 'aberto' : 'nao-encontrado';
  }
  const IVphone = (c) => (c.phone && onlyDigits(c.name).length >= 8 ? onlyDigits(c.phone).slice(-8) : '');

  function openChat(contact) {
    const t = findTitleByName(contact.name);
    if (t) { clicaTitulo(t); return 'aberto'; }
    if (q('search')) return openChatBusca(contact);
    if (contact.phone) {
      // Recarrega o WhatsApp Web; só como último recurso.
      root.location.href = `https://web.whatsapp.com/send?phone=${onlyDigits(contact.phone)}`;
      return 'recarregando';
    }
    return 'nao-encontrado';
  }

  // Uma linha pode ter mais de um span[title] (etiqueta do Business, remetente no grupo); o nome é sempre o primeiro.
  function chatRowTitles() {
    const list = q('chatList');
    if (!list) return [];
    return qa('chatRow', list).map((row) => q('rowTitle', row)).filter(Boolean);
  }

  MZ.wa = { SEL, q, health, currentChat, insertText, attachImage, bubbles, openChat, chatRowTitles };
})(globalThis);

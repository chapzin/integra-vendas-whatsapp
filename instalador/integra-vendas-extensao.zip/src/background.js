importScripts('core/followup.js', 'core/iv.js');

const FU = globalThis.MZ.followup;
const IV = globalThis.MZ.iv;
const SEP = '|';

function ensureAlarm() {
  chrome.alarms.create('tick', { delayInMinutes: 1, periodInMinutes: 5 });
}
chrome.runtime.onInstalled.addListener(ensureAlarm);
chrome.runtime.onStartup.addListener(ensureAlarm);

// Só avisa; quem envia a mensagem é sempre o vendedor, pelo WhatsApp Web.
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== 'tick') return;
  const { contacts = {}, notified = {} } = await chrome.storage.local.get(['contacts', 'notified']);
  const now = Date.now();
  const due = FU.dueTasks(contacts, now);

  chrome.action.setBadgeText({ text: due.length ? String(due.length) : '' });
  chrome.action.setBadgeBackgroundColor({ color: '#d9480f' });

  const fresh = due.filter(({ task }) => !notified[task.id]);
  for (const { contact, task } of fresh.slice(0, 5)) {
    chrome.notifications.create(`${encodeURIComponent(contact.key)}${SEP}${task.id}`, {
      type: 'basic',
      iconUrl: chrome.runtime.getURL('icons/128.png'),
      title: `Follow-up: ${contact.name}`,
      message: `${task.label} — clique para abrir a conversa`,
      priority: 1,
    });
    notified[task.id] = now;
  }
  if (fresh.length > 5) {
    chrome.notifications.create(`resumo${SEP}${now}`, {
      type: 'basic', iconUrl: chrome.runtime.getURL('icons/128.png'), title: 'Integra Vendas', message: `Mais ${fresh.length - 5} follow-ups na aba "Hoje".`,
    });
    fresh.slice(5).forEach(({ task }) => { notified[task.id] = now; });
  }

  const cutoff = now - 30 * FU.DAY;
  Object.keys(notified).forEach((id) => { if (notified[id] < cutoff) delete notified[id]; });
  await chrome.storage.local.set({ notified });
});

chrome.notifications.onClicked.addListener(async (id) => {
  chrome.notifications.clear(id);
  const [rawKey] = id.split(SEP);
  const tabs = await chrome.tabs.query({ url: 'https://web.whatsapp.com/*' });
  if (!tabs.length) {
    await chrome.tabs.create({ url: 'https://web.whatsapp.com/' });
    return;
  }
  const tab = tabs[0];
  await chrome.tabs.update(tab.id, { active: true });
  await chrome.windows.update(tab.windowId, { focused: true });
  if (rawKey !== 'resumo') chrome.tabs.sendMessage(tab.id, { type: 'openChat', key: decodeURIComponent(rawKey) }).catch(() => {});
});

chrome.action.onClicked.addListener(async () => {
  const tabs = await chrome.tabs.query({ url: 'https://web.whatsapp.com/*' });
  if (tabs.length) {
    await chrome.tabs.update(tabs[0].id, { active: true });
    await chrome.windows.update(tabs[0].windowId, { focused: true });
  } else {
    await chrome.tabs.create({ url: 'https://web.whatsapp.com/' });
  }
});

// ---- IntegraVendas: todo acesso à API passa por aqui, para o token não circular pela página do WhatsApp.

class ApiError extends Error {
  constructor(status, body) { super(IV.errorMessage(status, body)); this.status = status; }
}

async function session() {
  const { ivSession = null } = await chrome.storage.local.get('ivSession');
  return ivSession;
}

async function saveSession(s) {
  if (s) await chrome.storage.local.set({ ivSession: s });
  else await chrome.storage.local.remove('ivSession');
}

async function rawFetch(base, method, path, { body, headers = {} } = {}) {
  const init = { method, headers: { Accept: 'application/json', ...headers } };
  if (body !== undefined) { init.body = JSON.stringify(body); init.headers['Content-Type'] = 'application/json'; }
  let res;
  try {
    res = await fetch(base + path, init);
  } catch (_) {
    throw new ApiError(0, 'Sem conexão com o IntegraVendas.');
  }
  return res;
}

async function readBody(res) {
  const txt = await res.text();
  try { return JSON.parse(txt); } catch (_) { return txt; }
}

let refreshing = null;
async function refresh(s) {
  if (!refreshing) {
    refreshing = (async () => {
      const res = await rawFetch(s.base, 'GET', 'auth/refreshtoken', { headers: { Authorization: `Bearer ${s.access}`, refresh_token: s.refresh } });
      if (!res.ok) { await saveSession(null); throw new ApiError(401); }
      const out = await readBody(res);
      const next = { ...s, access: out.access_token, refresh: out.refresh_token || s.refresh, user: IV.userFromClaims(IV.decodeJwt(out.access_token)) };
      await saveSession(next);
      return next;
    })().finally(() => { refreshing = null; });
  }
  return refreshing;
}

async function call(method, path, body, { binary = false } = {}) {
  let s = await session();
  if (!s) throw new ApiError(401);
  for (let attempt = 0; attempt < 2; attempt++) {
    const res = await rawFetch(s.base, method, path, { body, headers: { Authorization: `Bearer ${s.access}` } });
    if (res.status === 401 && attempt === 0) { s = await refresh(s); continue; }
    if (res.status === 429 && attempt === 0) { await new Promise((r) => setTimeout(r, 1500)); continue; }
    if (!res.ok) throw new ApiError(res.status, await readBody(res));
    if (binary) return res.blob();
    return readBody(res);
  }
  throw new ApiError(401);
}

async function blobToDataUrl(blob) {
  const buf = new Uint8Array(await blob.arrayBuffer());
  let bin = '';
  for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
  return `data:${blob.type || 'application/pdf'};base64,${btoa(bin)}`;
}

const imgCache = new Map();

const ops = {
  async status() {
    const s = await session();
    return s ? { logged: true, base: s.base, user: s.user } : { logged: false };
  },
  // A senha só atravessa esta chamada; nunca é gravada.
  async login({ base, email, senha }) {
    const b = IV.baseUrl(base);
    if (!b.startsWith('https://')) throw new Error('O endereço precisa começar com https:// (a senha não pode ir sem criptografia).');
    const res = await rawFetch(b, 'POST', 'auth/login', { body: { email, senha } });
    const out = await readBody(res);
    if (!res.ok) throw new ApiError(res.status === 401 ? 400 : res.status, out);
    const user = IV.userFromClaims(IV.decodeJwt(out.access_token));
    await saveSession({ base: b, access: out.access_token, refresh: out.refresh_token, user });
    return { logged: true, base: b, user };
  },
  async logout() {
    const s = await session();
    if (s) await rawFetch(s.base, 'DELETE', 'auth/logout', { headers: { Authorization: `Bearer ${s.access}` } }).catch(() => {});
    await saveSession(null);
    return { logged: false };
  },
  call: ({ method, path, body }) => call(method, path, body),
  createOrder: (args) => IV.createOrder((m, p, b) => call(m, p, b), args),
  // O CSP do WhatsApp só aceita imagem data:/blob:, então a foto do produto vem por aqui.
  async img({ url }) {
    if (!/^https:\/\//.test(url || '')) return { dataUrl: '' };
    if (imgCache.has(url)) return { dataUrl: imgCache.get(url) };
    let dataUrl = '';
    try {
      const res = await fetch(url);
      const blob = res.ok ? await res.blob() : null;
      if (blob && /^image\//.test(blob.type) && blob.size < 3e6) dataUrl = await blobToDataUrl(blob);
    } catch (_) { /* sem foto: o painel mostra o ícone */ }
    if (imgCache.size > 300) imgCache.delete(imgCache.keys().next().value);
    imgCache.set(url, dataUrl);
    return { dataUrl };
  },
  async pdf({ id }) {
    return { dataUrl: await blobToDataUrl(await call('GET', `pedidos/pdf/${id}`, undefined, { binary: true })) };
  },
};

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (sender.id !== chrome.runtime.id || !msg || msg.type !== 'iv' || !Object.hasOwn(ops, msg.op)) return false;
  ops[msg.op](msg.args || {})
    .then((data) => reply({ ok: true, data }))
    .catch((e) => reply({ ok: false, error: e.message || String(e), status: e.status || 0 }));
  return true;
});

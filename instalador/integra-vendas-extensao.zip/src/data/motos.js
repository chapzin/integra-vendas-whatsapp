(function (root) {
  // Mais emplacadas no Brasil (Fenabrave 2025) primeiro; o vendedor pode digitar qualquer outro modelo.
  const MOTOS = [
    'Honda CG 160 Titan', 'Honda CG 160 Fan', 'Honda CG 160 Start', 'Honda CG 160 Cargo',
    'Honda Biz 125', 'Honda Biz 110i', 'Honda Pop 110i', 'Honda Bros 160', 'Honda XRE 190', 'Honda XRE 300',
    'Honda CB 300F Twister', 'Honda CB 250F Twister', 'Honda PCX 160', 'Honda Elite 125', 'Honda NXR 150 Bros',
    'Honda CG 150 Titan', 'Honda CG 150 Fan', 'Honda CG 125 Fan',
    'Yamaha Factor 150', 'Yamaha Fazer FZ25', 'Yamaha Fazer 250', 'Yamaha Crosser 150', 'Yamaha Lander 250',
    'Yamaha NMax 160', 'Yamaha Fluo 125', 'Yamaha YBR 125', 'Yamaha XTZ 125',
    'Suzuki Yes 125', 'Haojue DK 150', 'Haojue DR 160', 'Shineray Jet 125', 'Shineray Worker 125', 'Mottu Sport 110i',
  ];

  const api = { MOTOS };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else (root.MZ = root.MZ || {}).data = api;
})(globalThis);
